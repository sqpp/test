<?php

use BitNinja\Framework\TraitAPIhelper;
use BitNinja\Framework\TraitCommandBuilder;

/**
 * Trait for os level helper methods
 *
 * v 2.0 can handle inherited classes.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
trait TraitCommandHelper
{
    use TraitCommandBuilder;
    use TraitAPIhelper;

    /**
     * @return BlueLog
     */
    public function getLog()
    {
        return $this->log;
    }

    /**
     * @param BlueLog $logger
     * @return TraitCommandHelper
     */
    public function setLog($logger)
    {
        return $this->log = $logger;
    }
}
