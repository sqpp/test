<?php

/**
 *  Accessor trait for automatic gettters/setters.
 *
 *  Usage:
 *  use TraitAccessor;
 *
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
trait TraitAccessors
{
    /**
     * @param string $method
     * @param array $args
     * @throws BadMethodCallException|InvalidArgumentException
     * @return TraitAccessors
     */
    public function __call($method, $args)
    {
        if (
            !preg_match('/(?P<accessor>set|get)(?P<property>[A-Z][a-zA-Z0-9]*)/', $method, $match) ||
            !property_exists(__CLASS__, $match['property'] = $this->fromCamelCase($match['property']))
        ) {
            throw new BadMethodCallException(sprintf(
                "'%s' does not exist in '%s'.",
                $method,
                get_class(__CLASS__)
            ));
        }

        switch ($match['accessor']) {
            case 'get':
                return $this->{$match['property']};
            case 'set':
                if (!$args) {
                    throw new InvalidArgumentException(sprintf("'%s' requires an argument value.", $method));
                }
                $this->{$match['property']} = $args[0];
                return $this;
        }
    }

    /**
     * Translates a camel case string into a string with
     * underscores (e.g. firstName -> first_name)
     *
     * @param string $str String in camel case format
     * @return string $str Translated into underscore format
     */
    private function fromCamelCase($str)
    {
        return BlueStringLib::fromCamelCase($str);
    }

    /**
     * Translates a string with underscores
     * into camel case (e.g. first_name -> firstName)
     *
     * @param string $str                   String in underscore format
     * @param bool   $capitalise_first_char If true, capitalise the first char in $str
     * @return string $str translated into camel caps
     */
    private function toCamelCase($str, $capitalise_first_char = false)
    {
        return BlueStringLib::toCamelCase($str, $capitalise_first_char);
    }

    /**
     * @return array
     */
    protected function attributes()
    {
        return [];
    }

    /**
     * @return array
     */
    public function getAttributes()
    {
        $names = $this->attributes();
        if (!is_array($names)) {
            return [];
        }
        $values = [];
        foreach ($names as $name) {
            if (property_exists(static::class, $name)) {
                $values[$name] = $this->$name;
            }
        }
        return $values;
    }

    /**
     * @param array $attributeValues
     * @return void
     */
    public function setAttributes($attributeValues)
    {
        if (!is_array($attributeValues)) {
            return;
        }
        $attribute = $this->attributes();
        foreach ($attributeValues as $name => $value) {
            if (in_array($name, $attribute) && property_exists(static::class, $name)) {
                $this->$name = $value;
            }
        }
    }
}
