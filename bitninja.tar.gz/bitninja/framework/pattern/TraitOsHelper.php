<?php

/**
 * Trait for os level helper methods
 *
 * v 2.0 can handle inherited classes.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
trait TraitOsHelper
{
    /**
     * @param string $str
     * @return string
     */
    public function removeExtraWhitespaces($str)
    {
        return BlueStringLib::removeExtraWhitespaces($str);
    }

    /**
     * Same as base chdir() but this one logs and notify when the folder doesn't exixst.
     * 
     * @param string $dir
     * @return void
     */
    public function chdir($dir)
    {
        if (!is_dir($dir)) {
            $this->log->error('Unable to chdir. No such dir [' . $dir . ']');
        }
        $this->log->debug('cd ' . $dir);
        chdir($dir);
    }

    /**
     * Same as base chmod() but this one logs on debug level.
     * Upon error also logs it as error.
     * If no need for logging, set the third paramater false.
     * 
     * @param string $filename
     * @param string $mode
     * @param boolean $log
     * @return void
     */
    public function chmod($filename, $mode, $log = true)
    {
        if ($log) {
            $this->log->debug('chmod [' . $filename . '] (mode:' . $mode . ')');
        }
        $success = chmod($filename, $mode);
        if ($success === false) {
            $this->log->error('Could not chmod file [' . $filename . ']');
        }
    }

    /**
     *
     * Same as base unlink() but this one logs on debug level.
     * Upon error also logs it as error.
     * If no need for logging, set the second paramater false.
     *
     * @todo refactor this and the other system functions
     *       - throw exception upon error
     *       - logging based on class variable
     *       - logging level based on class variable
     * 
     * @param string $filename
     * @param boolean $log
     * @return void
     */
    public function unlink($filename, $log = true)
    {
        if ($log) {
            $this->log->debug('unlink [' . $filename . ']');
        }
        $success = unlink($filename);
        if ($success === false) {
            $this->log->error('Could not unlink file [' . $filename . ']');
        }
    }

    /**
     * Same as base exec() but this one logs on debug level.
     * Upon error also logs it as error.
     * If no need for logging, set the second paramater false.
     *
     * @param string $cmd
     * @param string $result
     * @param string $return_var
     * @param boolean $log
     * @return void
     */
    public function exec($cmd, &$result = null, &$return_var = null, $log = true)
    {
        if ($log == false) {
            BlueExec::exec($cmd, $result, $return_var, false);
            return;
        }
        BlueExec::exec($cmd, $result, $return_var, $this->log);
    }

    /**
     * Same as $this->exec() but with sudo.
     * Caution! Can only used with commands
     * declared in /etc/sudoers!
     * 
     * @param string $cmd
     * @param string $result
     * @param string $return_var
     * @param boolean $log
     * @return void
     */
    public function suexec($cmd, &$result = null, &$return_var = null, $log = true)
    {
        $this->exec('/usr/bin/sudo ' . $cmd, $result, $return_var, $log);
    }

    /**
     * Run system command.
     *
     *
     * @param string $command
     * @return string
     */
    public function shell_exec($command)
    {
        $this->log->debug('    [# ' . $command . ']');
        return shell_exec($command);
    }

    public function isRelativePath($certFile)
    {
        $firstCharacter = substr($certFile, 0, 1);
        return $firstCharacter != '/';
    }

    /**
     * Returns the number of cores
     * 
     * @return number
     */

    public function getCPUCoresNumber()
    {
        return substr_count((string)@file_get_contents('/proc/cpuinfo'), "\nprocessor") + 1;    
    }

    /**
     * Returns true if the current os is debian based
     * 
     * @return boolean
     */
    protected function isDeb()
    {
        return ServerDataProvider::instance()->isDeb();
    }

    /**
     * Returns true if the current os is Red Hat based
     * 
     * @return boolean
     */
    protected function isRpm()
    {
        return ServerDataProvider::instance()->isRpm();
    }

    /**
     * Returns true if zypper package manager found
     * 
     * @return boolean
     */
    protected function isZypper()
    {
        return ServerDataProvider::instance()->isZypper();
    }

    /**
     * Returns true if apt package manager found
     * 
     * @return boolean
     */
    protected function isApt()
    {
        return ServerDataProvider::instance()->isApt();
    }

    /**
     * Returns true if apt-get package manager found
     * 
     * @return boolean
     */
    protected function isAptGet()
    {
        return ServerDataProvider::instance()->isAptGet();
    }

    /**
     * Returns true if yum package manager found
     * 
     * @return boolean
     */
    protected function isYum()
    {
        return ServerDataProvider::instance()->isYum();
    }

    /**
     * If the os can not be detected, we can use this function to exit with an error message.
     * 
     * @return void
     */
    protected function unknownOs()
    {
        $this->log->error('The OS is not Deb nor Rpm based. Agent got confused.');
        $this->log->backtrace();
    }

    /**
     * @param string $path
     * @return boolean
     */
    protected function isExecutableFileAtPath($path)
    {
        return file_exists(realpath($path)) && is_file($path) && is_executable($path);
    }

    /**
     * @param string $path
     * @return boolean
     */
    protected function isNonExecutableFileAtPath($path)
    {
        return file_exists(realpath($path)) && is_file($path) && !is_executable($path);
    }
}
