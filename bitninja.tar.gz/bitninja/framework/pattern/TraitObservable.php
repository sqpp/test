<?php

/**
 * Trait to easily implement Observer pattern.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
trait TraitObservable
{

    /**
     * @var SplObjectStorage
     */
    protected $observers;
    /**
     * @var boolean
     */
    protected $logMemoryUsage = false;
    /**
     * @param boolean $val
     * @return boolean
     */
    public function shouldLogMemoryUsage($val)
    {
        $this->logMemoryUsage = !!$val;
        return $this;
    }
    /**
     * @param IObserver $observer
     * @throws InvalidArgumentException
     * @return void
     */
    public function registerObserver($observer)
    {
        if ($this->observers == null) {
            $this->observers = new SplObjectStorage();
        }

        if (!$observer instanceof IObserver) {
            throw new InvalidArgumentException('Observers must implement the IObserver interface!');
        }

        $this->observers->attach($observer);
    }

    /**
     * @param IObserver $observer
     * @return void
     */
    public function unregisterObserver($observer)
    {
        $this->observers->detach($observer);
    }

    /**
     * @return void
     */
    public function unregisterAllObservers()
    {
        foreach ($this->observers as $observer) {
            $this->observers->detach($observer);
        }
    }

    /**
     * Notify all observers about an event.
     * If an observer has filter method, get the
     * filter classes names and do the filtration.
     *
     * @param string $eventName
     * @return void
     */
    public function notifyObservers($eventName)
    {
        if ($this->observers == null) {
            return;
        }

        foreach ($this->observers as $observer) {
            // echo $mem_usage;
            // if ($mem_usage > 10){
            //    file_put_contents('/tmp/vars_dumped', var_export(get_defined_vars(), true));
            //    //echo 'Vars dumped to /tmp/vars_dumped';
            //    exit;
            // }
            if (!$this->checkFilters($observer, 'pre')) {
                continue;
            }
            if (!$this->logMemoryUsage) {
                $observer->notify($this, $eventName);
                $this->checkFilters($observer, 'post');
                continue;
            }
            $log = BlueLog::instance($this);
            $mem_before = memory_get_usage();

            $observer->notify($this, $eventName);
            $this->checkFilters($observer, 'post');

            $mem_after = memory_get_usage();
            if ($mem_before !== $mem_after) {
                $log->debug('Memory leak [' . round(($mem_after - $mem_before) / 1024) . ' KB] in ' . get_class($observer));
            }
        }
    }

    /**
     * Do the pre filtration. Returns true if the observer
     * can be notified. False if it can't.
     *
     * @param IObserver $observer
     * @return boolean
     */
    private function checkFilters($observer, $pre_or_post)
    {
        if (method_exists($observer, 'filters')) {
            $filters = $observer->filters();
            if ($this->doFiltration($filters, $pre_or_post) == false) {
                return false;
            }
        }
        return true;
    }

    /**
     * Do the filtration with the filters
     *
     * @param array $filters
     * @param string $pre_or_post
     * @return boolean
     */
    private function doFiltration($filters, $pre_or_post)
    {
        foreach ($filters as $filter) {
            $method_name = $pre_or_post . 'Filter';
            if ($filter->$method_name($this) == false) {
                return false;
            }
        }
        return true;
    }
}
