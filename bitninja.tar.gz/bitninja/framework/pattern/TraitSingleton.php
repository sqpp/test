<?php

/**
 * Singleton Trait. Usage example:
 * use TraitSingleton;
 *
 * v 2.0 can handle inherited classes.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
trait TraitSingleton
{

    /**
     * @var object
     */
    protected static $instance;

    /**
     * @var BlueLog
     */
    protected $log;

    /**
     * Return the instance
     *
     * @return static
     */
    final public static function getInstance()
    {
        $classname = get_called_class();

        return isset(static::$instance[$classname]) ? static::$instance[$classname] : static::$instance[$classname] = new $classname();
    }

    /**
     * Return the instance
     *
     * @return static
     */
    final public static function instance()
    {
        return static::getInstance();
    }

    /**
     * Final constructor.
     *
     * @return void
     */
    final private function __construct()
    {
        $classname = get_called_class();
        $this->log = BlueLog::instance($this);

        $this->init();
    }

    /**
     * Executes the onInit method if it exists in the class.
     *
     * @return void
     */
    protected function init()
    {
        if (method_exists($this, '_inject')) {
            return;
        }
        if (method_exists($this, 'onInit')) {
            $this->onInit();
        }
    }

    /**
     * Reinitialize the singleton's instance.
     *
     * @return void
     */
    final public static function resetInstance()
    {
        $classname = get_called_class();
        unset(static::$instance[$classname]);
        static::$instance[$classname] = new $classname();
    }
}
