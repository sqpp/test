<?php

/**
 * Use http://php-di.org/doc/getting-started.html instead of this!
 * 
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class Registry implements ArrayAccess
{
    use TraitSingleton;

    /**
     * @var array
     */
    private $registry = array();

    /**
     * @param string $key
     * @param string $value
     * @throws Exception
     * @return void
     */
    public function set($key, $value)
    {
        if (isset($this->registry[$key])) {
            throw new Exception("There is already an entry for key " . $key);
        }

        $this->registry[$key] = $value;
    }

    /**
     * @param string $key
     * @throws Exception
     * @return string
     */
    public function get($key)
    {
        if (!isset($this->registry[$key])) {
            throw new Exception("There is no entry for key " . $key);
        }

        return $this->registry[$key];
    }

    /**
     * ArrayAccess implementation
     * 
     * @param string $key
     * @return boolean
     */
    public function offsetExists($key)
    {
        return isset($this->registry[$key]);
    }

    /**
     * @param string $key
     * @return mixed
     */
    public function offsetGet($key)
    {
        if (isset($this->registry[$key])) {
            return $this->registry[$key];
        }

        return null;
    }

    /**
     * @param string $key
     * @param string $value
     * @return string
     */
    public function offsetSet($key, $value)
    {
        return $this->registry[$key] = $value;
    }

    /**
     * @param string $key
     * @return void
     */
    public function offsetUnset($key)
    {
        unset($this->registry[$key]);
    }
}
