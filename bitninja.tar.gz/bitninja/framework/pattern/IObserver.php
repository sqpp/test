<?php

/**
 * Interface for Observer pattern. All Observer have to implement IObserver
 * and every subject have to user the Observable Trait.
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
interface IObserver
{

    /**
     * This method is called by the observable object when it
     * whants to notify its obervers.
     *
     * @param IObservable $observable The observable object you registered to
     * @param string      $eventName  The name of the event raised.
     * @return void
     */
    public function notify($observable, $eventName = '');
}
