<?php

/**
 * This class represent a generic Object Pool pattern.
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     1.20.2
 */
class ObjectPool
{
    /**
     * Array of validator objects. A validator object must have a validate method, which is used to validate items being added to the pool.
     * 
     * @var array
     */
    protected $validators = [];

    /**
     * Array of objects added to the pool
     * 
     * @var array
     */
    protected $pool = [];

    /**
     * If the factory is set, the Object Pool can create objects when an item is not present in the pool
     * 
     * @var IObjectPoolFactory
     */
    protected $factory;

    /**
     * Validates a given item, with all available validators
     *
     * @param object $item
     * @param mixed $id
     * @return boolean true if the item is valid
     */
    protected function validate($item, $id)
    {
        foreach ($this->validators as $validator) {
            if (!$validator->validate($item, $id)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Add a new validation rule to the pool
     *
     * @param object $validator
     * @return boolean true if the validator can be added to the Object pool
     */
    public function addValidator($validator)
    {
        if (!($validator instanceof IObjectPoolValidator)) {
            return false;
        }

        $this->validators[] = $validator;
        return true;
    }

    /**
     * Adds a new item to the pool
     *
     * @param object $item
     * @param mixed $id
     * @return boolean true if the item can be added to the pool
     */
    public function addItem($item, $id = null)
    {
        if (!$this->validate($item, $id)) {
            return false;
        }
        is_null($id) ? $this->pool[] = $item : $this->pool[$id] = $item;
        return true;
    }

    /**
     * Utilizes the factory if it's available and returns null if not
     *
     * @param mixed $id
     * @return object|null
     */
    protected function createItem($id)
    {
        if (is_null($this->factory)) {
            return null;
        }

        return $this->factory->getObject($id);
    }

    /**
     * Retrives an item from the object pool by id
     * 
     * @param mixed $id
     * @return mixed the given item in the pool or null if not found
     */
    public function getItem($id)
    {
        if (!isset($this->pool[$id])) {
            $this->pool[$id] = $this->createItem($id);
        }
        return $this->pool[$id];
    }

    /**
     * Checks if the id exists in the object pool
     *
     * @param mixed $id
     * @return bool
     */
    public function hasItem($id)
    {
        return array_key_exists($id, $this->pool);
    }

    /**
     * Removes an item from the pool by id
     *
     * @param mixed $id
     * @return ObjectPool
     */
    public function removeItem($id)
    {
        unset($this->pool[$id]);
        return $this;
    }

    /**
     * Retrieves the last element from the pool
     *
     * @return mixed
     */
    public function popItem()
    {
        return !empty($this->pool) ? array_pop($this->pool) : $this->createItem(null);
    }

    /**
     * Retrieves the first element from the pool
     *
     * @return mixed
     */
    public function shiftItem()
    {
        return !empty($this->pool) ? array_shift($this->pool) : $this->createItem(null);
    }

    /**
     * Adds an item to the end of the pool
     * 
     * @param mixed $item
     * @return boolean true if the item can be added to the pool
     */
    public function pushItem($item)
    {
        if (!$this->validate($item, null)) {
            return false;
        }
        array_push($this->pool, $item);
        return true;
    }

    /**
     * Removes every element from the pool
     * 
     * @return void
     */
    public function flush()
    {
        $this->pool = [];
    }

    /**
     * Calls the callable on every element of the pool.
     *
     * @param callable $callable
     * @return boolean|array Array of every element after the callback or false on failure
     */
    public function callEach($callable)
    {
        if (!is_callable($callable)) {
            return false;
        }
        return array_map($callable, $this->pool);
    }

    /**
     * Getter for factory
     *
     * @return IObjectPoolFactory
     */
    public function getFactory()
    {
        return $this->factory;
    }

    /**
     * Setter for factory
     *
     * @param IObjectPoolFactory $factory
     * @return bool
     */
    public function setFactory($factory)
    {
        if (!($factory instanceof IObjectPoolFactory)) {
            return false;
        }

        $this->factory = $factory;
        return true;
    }

    /**
     * Retrieves all the elements in the pool
     *
     * @return array
     */
    public function getAll()
    {
        return $this->pool;
    }
}
