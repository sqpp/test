<?php

/**
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
interface IBlueFilter
{

    /**
     * Filtration before an action raise and
     * observers Notify is called
     *
     * @param IObservable $observable
     */
    public function preFilter($observable);

    /**
     * Filtration after an action raise and
     * observers Notify is called
     *
     * @param IObservable $observable
     */
    public function postFilter($observable);
}
