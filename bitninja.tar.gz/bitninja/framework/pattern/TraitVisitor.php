<?php

/**
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
trait TraitVisitor
{
    /**
     * @param IVisitor $visitor
     * @return mixed
     */
    public function accept(IVisitor $visitor)
    {
        return $visitor->visit($this);
    }
}
