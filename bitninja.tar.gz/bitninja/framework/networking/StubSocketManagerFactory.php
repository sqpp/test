<?php

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */


class StubSocketManagerFactory extends \BlueTestCase implements ISocketManagerFactory
{
    /**
     * @param string $socket
     * @param string $socketName
     * @return mixed
     */
    public function getInstance($socket, $socketName)
    {
        $socket_manager = new StubSocketManager($socket, $socketName);
        /*
          $socket_manager = $this->getMockBuilder('\BitNinja\SenseWebHoneypot\AbstractSocketManager')
          ->setConstructorArgs([$socket])
          ->setMethods(['onRead', 'onWrite'])
          ->getMock();

          //$socket_manager->method('getSocket')
          //        ->willReturn($socket);
          $socket_manager->expects($this->once())
          ->method('onRead')
          ->with($this->equalTo('hello'));
          $socket_manager->method('onWrite')
          ->willReturn('hi');

         */
        return $socket_manager;
    }
}
