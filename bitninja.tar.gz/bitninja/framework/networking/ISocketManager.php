<?php

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */

/**
 *
 * @author Zsolt
 */
interface ISocketManager
{
    /**
     * @var int
     */
    const TRANSDIR_PRI_TO_SEC = 0;

    /**
     * @var int
     */
    const TRANSDIR_SEC_TO_PRI = 1;

    /**
     * @return void
     */
    public function getSocket();

    /**
     * @return void
     */
    public function getSecondarySocket();

    /**
     * @param string $message    
     * @return void
     */
    public function onRead($message);

    /**
     * @return void
     */
    public function onWrite();
    //public function onTransmit($message, $direction);

    /**
     * @return void
     */
    public function onTransmit($direction);

    /**
     * @return void
     */
    public function hasDataToTransmit($direction);

    /**
     * @return void
     */
    public function hasDataToWrite();

    /**
     * @return void
     */
    public function isTimedOut();
}
