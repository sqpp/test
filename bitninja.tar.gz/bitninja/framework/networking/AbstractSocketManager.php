<?php

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
abstract class AbstractSocketManager implements ISocketManager
{
    /**
     * @var string
     */
    protected $socket;

    /**
     * @var int
     */
    protected $mode;

    /**
     * @var BlueLog
     */
    protected $log;

    /**
     * @var string
     */
    protected $socketName;

    /**
     * @var string
     */
    protected $socketOpenedTime;

    /**
     * @var int
     */
    const READING_MODE = 0;

    /**
     * @var int
     */
    const WRITEING_MODE = 1;

    /**
     * @var int
     */
    const CLOSING_MODE = 2;

    /**
     * @var int
     */
    const TRANSMITTING_MODE = 3;

    /**
     * @var int
     */
    const TIMEOUT = 3;

    /**
     * @var int
     */
    const MAXOPENTIME = 60;

    /**
     * @var string
     */
    protected $previousCommunication;

    /**
     *
     * @param string $socket
     * @param string $socketName
     * @return void
     */
    public function __construct($socket, $socketName)
    {
        $this->socket = $socket;
        $this->socketName = $socketName;
        $this->previousCommunication = time();
        $this->socketOpenedTime = time();
        $this->setReadingMode();
        $this->log = BlueLog::instance($this);
    }

    /**
     * @return string
     */
    public function getSocket()
    {
        return $this->socket;
    }

    /**
     * @return string
     */
    public function getSecondarySocket()
    {
        return null;
    }

    /**
     * @return boolean
     */
    public function isReading()
    {
        if ($this->mode == self::READING_MODE) {
            return true;
        }
        return false;
    }

    /**
     * @return boolean
     */
    public function isWriting()
    {
        if ($this->mode == self::WRITEING_MODE) {
            return true;
        }
        return false;
    }

    /**
     * @return boolean
     */
    public function isClosing()
    {
        if ($this->mode == self::CLOSING_MODE) {
            return true;
        }
        return false;
    }

    /**
     * @return boolean
     */
    public function isTransmitting()
    {
        if ($this->mode == self::TRANSMITTING_MODE) {
            return true;
        }
        return false;
    }

    /**
     * @return void
     */
    protected function setWritingMode()
    {
        $this->mode = self::WRITEING_MODE;
    }

    /**
     * @return void
     */
    protected function setReadingMode()
    {
        $this->mode = self::READING_MODE;
    }

    /**
     * @return void
     */
    protected function setClosingMode()
    {
        $this->mode = self::CLOSING_MODE;
    }

    /**
     * @return void
     */
    protected function setTransmittingMode()
    {
        $this->mode = self::TRANSMITTING_MODE;
    }

    /**
     * @param string $message
     * @return void
     */
    public function onRead($message)
    {
        $this->previousCommunication = time();
    }

    /**
     * @return void
     */
    public function onWrite()
    {
        $this->previousCommunication = time();
    }

    /**
     * @param string $direction
     * @return void
     */
    public function onTransmit($direction)
    {
        $this->previousCommunication = time();
    }

    /**
     * @param string $direction
     * @return boolean
     */
    public function hasDataToTransmit($direction)
    {
        return false;
    }

    /**
     * @return boolean
     */
    public function hasDataToWrite()
    {
        return false;
    }

    /**
     * @return boolean
     */
    public function isTimedOut()
    {
        return ((time() - $this->previousCommunication) > static::TIMEOUT) || ((time() - $this->socketOpenedTime) > static::MAXOPENTIME);
    }

    /**
     * @return void
     */
    public function onClose()
    {
        $this->previousCommunication = time();
    }
}
