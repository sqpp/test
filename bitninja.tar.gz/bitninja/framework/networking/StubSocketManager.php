<?php

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 * 
 * 
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage main
 * @version    1.0
 */


class StubSocketManager extends AbstractSocketManager
{

    /**
     *
     * @param type $message
     */
    public function onRead($message)
    {
        parent::onRead($message);
        $this->setWritingMode();
    }

    /**
     * @return string The sting to write
     */
    public function onWrite()
    {
        parent::onWrite();
        $this->setClosingMode();
        return 'hi';
    }
}
