<?php

/**
 * Trait for networing methods
 *
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 * 
 * @author     Zoltan Toma <zoli@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
trait TraitNetworkingHelper
{

    // Unforunately you can not use constants in a trait. This is why static variables az used.
    /**
     * Constant for IP version 4
     *
     * @var string
     */
    static $IPV4 = 'ipv4';

    /**
     * Constant for IP version 6
     *
     * @var string
     */
    static $IPV6 = 'ipv6';

    /**
     * Command builder instance to run OS commands
     *
     * @var \BlueCmdBuilder
     */
    protected $commandNH;

    /**
     * Load IPLib composer extension for IPv6 address handling and for IP range checks.
     * @return void
     */
    public function loadIpLib()
    {
        $autoloader = \Autoloader::instance();
        $autoloader->loadContrib();
    }

    /**
     * If the $ip is public return true if it is a private ip, return false.
     *
     * @param string $ip
     * @return boolean
     */
    public function isPublicIp($ip)
    {
        // https://mebsd.com/coding-snipits/check-private-ip-function-php.html
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }

    /**
     * If the $ip is valid IPv4 address return true.
     *
     * @param string $ip
     * @return boolean
     */
    public function isIpv4Address($ip)
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);
    }

    /**
     * If the $ip is valid IPv4 address return true.
     *
     * @param string $ip
     * @return boolean
     */
    public function isIpv6Address($ip)
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6);
    }

    /**
     * Validates if given port number is valid
     *
     * @param int $portNumber
     * @return boolean true if valid
     */
    public function isPortNumberValid($portNumber)
    {
        return is_numeric($portNumber) && $portNumber >= 0 && $portNumber <= 65535;
    }

    public function getInetAddrs(): array
    {
        $ips = $this->getLocalIps(self::$IPV4);
        if (is_null($ips)) {
            $this->log->warning("Could not determine IP address data.");
            return [];
        }
        foreach ($ips as $ip) {
            $this->log->debug("Found IP " . $ip);
        }
        return $ips;
    }

    public function getInetAddrsLogLess(): array
    {
        return $this->getLocalIps(self::$IPV4);
    }

    public function getInet6AddrsLogLess(): array
    {
        return $this->getLocalIps(self::$IPV6);
    }

    private function getLocalInterfaces(string $interface = ''): ?array
    {
        $commandParams = [
            'addr',
            'show'
        ];
        if ($interface != '') {
            $commandParams[] = $interface;
        }
        $res = $this->runCommandNH('ip', $commandParams);
        if ($res->getReturnVar() != 0) {
            return null;
        }
        $interfaces = $res->getResult();

        return $interfaces;
    }

    private function getLocalIps(string $ipversion = 'ipv4', string $exclude = '', array $include = []): array
    {
        $addresses = [];
        $ifaceNeedle = ($ipversion == self::$IPV4 ? 'inet ' : 'inet6 ');
    
        foreach ($this->getLocalInterfaces() as $line) {
            if (strpos($line, $ifaceNeedle) !== false) {
                $arr = explode(' ', trim($line));
                $address = explode('/', $arr[1]);
                $interfaceName = $arr[count($arr) - 1];
                $included = empty($include) || in_array($interfaceName, $include);                
                $excluded = ($exclude != '' && preg_match($exclude, $interfaceName));
                if ($included && !$excluded) {
                    $addresses[] = $address[0];
                }
            }
        }
        return $addresses;
    }
    

    public function getIpv6PublicIps(): array
    {
        $ifaces = $this->getInet6AddrsLogLess();
        $ret = [];
        foreach ($ifaces as $ip) {
            if ($this->isPublicIp($ip)) {
                $ret[] = $ip;
            }
        }
        return $ret;
    }

    public function getPublicAndPrivateIpv4Ips(): array
    {
        $ifaces = $this->getLocalIps(self::$IPV4, '/^docker\d*$/');
        $privateIps = [];
        $publicIps = [];

        foreach ($ifaces as $ip) {

            if ($ip == '127.0.0.1')
                continue;

            if (!$this->isPublicIp($ip)) {
                $privateIps[] = $ip;
            } elseif ($this->isPublicIp($ip)) {
                $publicIps[] = $ip;
            }
        }

        if (count($publicIps) > 0 && count($privateIps) >= 0) {
            return $publicIps;
        } elseif (count($privateIps) > 0 && count($publicIps) == 0) {
            return $privateIps;
        }

        return [];
    }

    // IPLIB
    /**
     * Check if a given ip is in a network
     *
     * @param string $ip IP to check in IPV4 format eg. 127.0.0.1
     * @param string $range IP/CIDR netmask eg. 127.0.0.0/24, also 127.0.0.1 is accepted and /32 assumed
     * @return boolean true if the ip is in this range / false if not.
     * @copyright (c) 2014, tott, GitHub
     */
    public function isIpInRange($ip, $range)
    {
        $address = \IPLib\Factory::addressFromString($ip);
        $range = \IPLib\Factory::rangeFromString($range);
        return is_null($address) || is_null($range) ? false : $range->contains($address);
    }

    /**
     * This function getting the first and last element of cidr
     *
     * @param string $ip The first part of cidr
     * @param int $prefix The second part if cidr
     * @return array
     */
    public function getFirstAndLastElementOfCidr($ip, $prefix)
    {
        $ips = [];
        $ips[] = $this->getFirstElementOfCidr($ip, $prefix);
        $ips[] = $this->getLastElementOfCidr($ip, $prefix);

        return $ips;
    }

    /**
     * This function getting the first element of cidr
     *
     * @param string $ip The first part of cidr
     * @param int $prefix The second part if cidr
     * @return string
     */
    public function getFirstElementOfCidr($ip, $prefix)
    {
        $range = \IPLib\Factory::rangeFromString("$ip/$prefix");
        return (string) $range->getStartAddress();
    }

    /**
     * This function getting the last element of cidr
     *
     * @param string $ip The first part of cidr
     * @param int $prefix The second part if cidr
     * @return string
     */
    public function getLastElementOfCidr($ip, $prefix)
    {
        $range = \IPLib\Factory::rangeFromString("$ip/$prefix");
        return (string) $range->getEndAddress();
    }

    /**
     * This function convert cidr to IPlist
     *
     * @param string $ip The first part of cidr
     * @param int $prefix The second part ff cidr
     * @return array
     */
    public function cidrToIpList($ip, $prefix)
    {
        $range = \IPLib\Factory::rangeFromString("$ip/$prefix");
        $start_ip = $range->getStartAddress();
        $end_ip = $range->getEndAddress()->getNextAddress();
        $ips = [];
        while ($start_ip->getComparableString() != $end_ip->getComparableString()) {
            $ips[] = $start_ip->toString();
            $start_ip = $start_ip->getNextAddress();
        }
        return $ips;
    }

    /**
     * This method should be used, to send commands to OS.
     * It's the same concept as in TraitCommand helper, but this pervents redefining a method or variable.
     *
     * @param string $cmd Os command to execute
     * @param array $params array of parameters that the command should use.
     * @return \BlueCmdResult|BlueCmdResult
     */
    public function runCommandNH($cmd, $params)
    {
        if (!is_string($cmd)) {
            return new \BlueCmdResult('Cmd must be a string!', 1);
        }
        if (!is_array($params)) {
            return new \BlueCmdResult('Params must be an array!', 1);
        }
        if (is_null($this->commandNH)) {
            $this->commandNH = new \BlueCmdBuilder();
        }
        $this->commandNH->setupCommand($cmd, $params);
        return $this->commandNH->execute();
    }

    /**
     * @param string $ipversion
     * @return boolean
     */
    public function getWANAdress($ipversion = 'ipv4')
    {
        if ($ipversion !== self::$IPV4 && $ipversion !== self::$IPV6) {
            $ipversion = self::$IPV4;
        }
        $this->runCommandNH('true', []);
        $ip = $this->getWANAddressByDig($ipversion);
        if ($ip !== false) {
            return $ip;
        }
        $ip = $this->getWANAddressByCurl($ipversion);
        if ($ip !== false) {
            return $ip;
        }
        return false;
    }

    /**
     * @param string $ipversion
     * @return mixed
     */
    protected function getWANAddressByDig($ipversion)
    {
        if ($this->commandNH->locateCommand('dig', false) === false) {
            return false;
        }
        $ipversionParam = ($ipversion == self::$IPV6 ? '-6' : '-4');
        $res = $this->runCommandNH("dig", [
            $ipversionParam,
            "+short",
            "+time=5",
            "+tries=1",
            "myip.opendns.com",
            "@resolver1.opendns.com"
        ]);
        if ($res->getReturnVar() != 0) {
            return false;
        }
        $ip = $res->getLine(0);
        if (!$this->isPublicIp($ip)) {
            return false;
        }
        return $ip;
    }

    /**
     * @param string $ipversion
     * @return mixed
     */
    protected function getWANAddressByCurl($ipversion)
    {
        $curl = curl_init();
        if (!$curl) {
            return false;
        }
        if ($ipversion === self::$IPV4) {
            curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        }
        if ($ipversion === self::$IPV6) {
            curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V6);
        }
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        $wanIpChecker = ConfigManager::instance()->getKey('general', 'WANIpCheckerUris') ?: [];
        foreach ($wanIpChecker as $url) {
            curl_setopt($curl, CURLOPT_URL, $url);
            $ip = trim(curl_exec($curl));
            if ($this->isPublicIp($ip)) {
                curl_close($curl);
                return $ip;
            }
        }
        curl_close($curl);
        return false;
    }
}