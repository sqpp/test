<?php

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class SocketServer
{

    /**
     * IP address to listen on
     * @var string
     */
    protected $address = '127.0.0.1';

    /**
     * TCP port number to listen on
     * @var int
     */
    protected $port = 80;

    /**
     *
     * @var BlueLog
     */
    protected $log;

    /**
     * The server socket
     * @var socket
     */
    protected $server_socket;

    /**
     * The array of clients (client objects created by the $factory)
     * @var array
     */
    protected $clients = array();

    /**
     * The factory object responsible for creating new
     * @var ISocketManagerFactory
     */
    protected $factory;

    /**
     * @var int
     */
    protected $readLenght = 65535000;

    // pem encoded SSL cert
    /**
     * @var string
     */
    protected $ssl_crt;

    // enable TLS by default or let clients request it with STARTTLS
    /**
     * @var string
     */
    protected $default_tls;

    /**
     * @param string $readLenght
     * @return void
     */
    public function setReadLenght($readLenght)
    {
        $this->readLenght = $readLenght;
    }

    /**
     * @var int
     */
    const MAX_CLIENT_COUNT = 60;

    /**
     * @param string $address
     * @param int $port
     * @param factory ISocketManagerFactory
     * @param string $ssl_cert
     * @param boolean $default_tls
     * @return void
     */
    public function __construct($address, $port, ISocketManagerFactory $factory, $ssl_cert = "", $default_tls = false)
    {
        $this->address = $address;
        $this->port = $port;
        $this->factory = $factory;
        $this->ssl_cert = $ssl_cert;
        $this->default_tls = $default_tls;
        $this->log = \BlueLog::instance($this);
        if (!empty($ssl_cert)) {
            $this->log->info("SSL cert $ssl_cert provided, enabling TLS");
        }
    }

    /**
     * @return boolean
     */
    public function bind()
    {
        $address_port = "{$this->address}:{$this->port}";
        if (!empty($this->ssl_cert) && file_exists($this->ssl_cert)) {
            $this->log->info('Enabling TLS using cert ' . $this->ssl_cert);
            $ctx = stream_context_create(['ssl' => [
                'local_cert' => $this->ssl_cert,
                'verify_peer' => false, "SNI_enabled" => false
            ]]);
            $this->server_socket = stream_socket_server("tcp://$address_port", $errno, $errstr, STREAM_SERVER_BIND | STREAM_SERVER_LISTEN, $ctx);
        } else {
            $this->server_socket = stream_socket_server("tcp://$address_port", $errno, $errstr);
        }
        if ($this->server_socket === false) {
            $this->log->warn("Unable to create socket on [$this->port] because it's in use.");
            return false;
        }
        stream_set_blocking($this->server_socket, 0);
    }

    /**
     * @param array $readSockets
     * @param array $writeSockets
     * @param array $transmittingSockets
     * @param array $secondaryToPrimaryMap
     * @return void
     */
    protected function collectSockets(&$readSockets, &$writeSockets, &$transmittingSockets, &$secondaryToPrimaryMap)
    {
        foreach ($this->clients as $key => $client) {
            if ($client->isClosing() || $client->isTimedOut()) {
                fclose($client->getSocket());
                $client->onClose();
                unset($this->clients[(int) $client->getSocket()]);
                continue;
            }

            if ($client->isReading()) {
                $readSockets[] = $client->getSocket();
            }

            if ($client->isWriting()) {
                $writeSockets[] = $client->getSocket();
            }

            if ($client->isTransmitting()) {
                $readSockets[] = $client->getSocket();
                $writeSockets[] = $client->getSocket();
                $readSockets[] = $client->getSecondarySocket();
                $writeSockets[] = $client->getSecondarySocket();
                $transmittingSockets[(int) $client->getSocket()] = array(
                    "primary" => $client->getSocket(),
                    "secondary" => $client->getSecondarySocket(),
                    "priToSecWrite" => 2,
                    "secToPriWrite" => 2
                );
                $secondaryToPrimaryMap[(int) $client->getSecondarySocket()] = $client->getSocket();
            }
        }
    }

    /**
     * @param array $readSockets
     * @param array $writeSockets
     * @param array $transmittingSockets
     * @param array $secondaryToPrimaryMap
     * @param int $sec
     * @param int $usec
     * @return mixed
     */
    protected function selectSockets(&$readSockets, &$writeSockets, &$transmittingSockets, &$secondaryToPrimaryMap, $sec, $usec)
    {
        $except = null;
        $read_sockets_orig = $readSockets;
        $write_sockets_orig = $writeSockets;
        do {
            $readSockets = $read_sockets_orig;
            $writeSockets = $write_sockets_orig;
            $onlyHalfTransmitting = true;
            if (($res = @stream_select($readSockets, $writeSockets, $except, $sec, $usec)) < 1) {
                pcntl_signal_dispatch();
                return false;
            }
            foreach ($this->clients as $client) {
                if ($client->hasDataToTransmit(ISocketManager::TRANSDIR_PRI_TO_SEC) && !in_array($client->getSocket(), $readSockets)) {
                    //$this->log->debug("Adding transmitting primary socket with remaining data");
                    $readSockets[] = $client->getSocket();
                }
                if ($client->hasDataToTransmit(ISocketManager::TRANSDIR_SEC_TO_PRI) && !in_array($client->getSecondarySocket(), $readSockets)) {
                    //$this->log->debug("Adding transmitting secondery socket with remaining data");
                    $readSockets[] = $client->getSecondarySocket();
                }
            }
            foreach ($readSockets as $key => $sock) {    //reading
                if (in_array((int) $sock, $secondaryToPrimaryMap)) {    //transmitting socket, primary half
                    //$this->log->debug("Found reading primary transmitting socket");
                    if (--$transmittingSockets[(int) $sock]["priToSecWrite"] === 0) {
                        $onlyHalfTransmitting = false;
                    }
                    unset($read_sockets_orig[$key]);
                    continue;
                }
                if (array_key_exists((int) $sock, $secondaryToPrimaryMap)) {    //transmitting socket, secondary half
                    //$this->log->debug("Found reading secondary transmitting socket");
                    $tr_sock = $secondaryToPrimaryMap[(int) $sock];
                    if (--$transmittingSockets[(int) $tr_sock]["secToPriWrite"] === 0) {
                        $onlyHalfTransmitting = false;
                    }
                    unset($read_sockets_orig[$key]);
                    continue;
                }
                //$this->log->debug("Non-transmitting reading socket");
                $onlyHalfTransmitting = false;  //it is not a transmitting socket
            }
            foreach ($writeSockets as $key => $sock) {   //writing
                if (in_array((int) $sock, $secondaryToPrimaryMap)) {    //transmitting socket, primary half
                    //$this->log->debug("Found writing primary transmitting socket");
                    if (--$transmittingSockets[(int) $sock]["priToSecWrite"] === 0) {
                        $onlyHalfTransmitting = false;
                    }
                    unset($write_sockets_orig[$key]);
                    continue;
                }
                if (array_key_exists((int) $sock, $secondaryToPrimaryMap)) {    //transmitting socket, secondary half
                    //$this->log->debug("Found writing secondary transmitting socket");
                    $tr_sock = $secondaryToPrimaryMap[(int) $sock];
                    if (--$transmittingSockets[(int) $tr_sock]["secToPriWrite"] === 0) {
                        $onlyHalfTransmitting = false;
                    }
                    unset($write_sockets_orig[$key]);
                    continue;
                }
                //$this->log->debug("Fount non-transmitting writing socket");
                $onlyHalfTransmitting = false;  //it is not a transmitting socket
            }
        } while ($onlyHalfTransmitting == true);
        return $except;
    }

    /**
     * @param array $readSockets
     * @return booean
     */
    protected function acceptNewConnections(&$readSockets)
    {
        if (count($this->clients) >= self::MAX_CLIENT_COUNT) {
            $this->log->warn("Maximum client count reached!");
            $key = array_search($this->server_socket, $readSockets);
            unset($readSockets[$key]);
            return false;
        }
        if (in_array($this->server_socket, $readSockets)) {
            // new client connection
            $socketName = "";
            $client_socket = stream_socket_accept($this->server_socket, ini_get("default_socket_timeout"), $socketName);
            if ($this->default_tls) {
                stream_set_blocking($client_socket, 1);
                stream_socket_enable_crypto($client_socket, true, STREAM_CRYPTO_METHOD_TLS_SERVER);
            }
            stream_set_blocking($client_socket, 0);
            $this->log->info("Accepted connection " . print_r($client_socket));
            $new_client = $this->factory->getInstance($client_socket, $socketName);
            $this->clients[(int) $client_socket] = $new_client;
            if ($new_client->isWriting()) {
                $this->write($client_socket);
            }
            $key = array_search($this->server_socket, $readSockets);
            unset($readSockets[$key]);
        }
        return true;
    }

    /**
     * @param array $readSockets
     * @param array $transmittingSockets
     * @param array $secondaryToPrimaryMap
     * @return void
     */
    protected function doReading($readSockets, $transmittingSockets, $secondaryToPrymaryMap)
    {
        foreach ($readSockets as $read_socket) {
            if (!(array_key_exists((int) $read_socket, $transmittingSockets) || array_key_exists((int) $read_socket, $secondaryToPrymaryMap))) {
                $this->read($read_socket);
            }
        }
    }

    /**
     * @param array $readSockets
     * @param array $transmittingSockets
     * @param array $secondaryToPrimaryMap
     * @return void
     */
    protected function doWriting($writeSockets, $transmittingSockets, $secondaryToPrimaryMap)
    {
        foreach ($writeSockets as $write_socket) {
            if (!(array_key_exists((int) $write_socket, $transmittingSockets) || array_key_exists((int) $write_socket, $secondaryToPrimaryMap))) {
                $this->write($write_socket);
            }
        }
    }

    /**
     * @param array $transmittingSockets
     * @return void
     */
    protected function doTransmission($tramsmittingSockets)
    {
        foreach ($tramsmittingSockets as $sock) {
            if ($sock["priToSecWrite"] === 0) {
                $this->transmit($sock["primary"], $sock["secondary"]);
            }
            if ($sock["secToPriWrite"] === 0) {
                $this->transmit($sock["secondary"], $sock["primary"]);
            }
        }
    }

    /**
     * @param int $sec
     * @param int $usec
     * @return boolean
     */
    public function listen($sec, $usec)
    {
        if ($this->server_socket === false) {
            sleep($sec);
            return false;
        }
        $read_sockets[] = $this->server_socket;
        $write_sockets = array();
        $transmitting_sockets = array();
        $secondaryToPrimaryMap = array();
        //fwrite(STDERR, print_r($this->clients, TRUE));
        $this->collectSockets($read_sockets, $write_sockets, $transmitting_sockets, $secondaryToPrimaryMap);
        $except = $this->selectSockets($read_sockets, $write_sockets, $transmitting_sockets, $secondaryToPrimaryMap, $sec, $usec);
        //$this->log->debug('  - Stats read[' . count($read_sockets) .
        //        '] write[' . count($write_sockets) . ']');
        $this->acceptNewConnections($read_sockets);
        $this->doReading($read_sockets, $transmitting_sockets, $secondaryToPrimaryMap);
        $this->doWriting($write_sockets, $transmitting_sockets, $secondaryToPrimaryMap);
        $this->doTransmission($transmitting_sockets);
    }


    /**
     * @param array $client_socket
     * @return void
     */
    protected function write($client_socket)
    {
        $client = $this->clients[(int) $client_socket];
        $data = $client->onWrite();
        // Suppressing errors. Clients can close there socket whenever they want.
        @fwrite($client_socket, $data);
    }

    /**
     * @param array $client_socket
     * @return void
     */
    protected function read($client_socket)
    {
        $data = fread($client_socket, $this->readLenght);
        $client = $this->clients[(int) $client_socket];
        $client->onRead($data);
    }

    /**
     * @param array $client_socket
     * @param array $to_socket
     * @return void
     */
    protected function transmit($from_socket, $to_socket)
    {
        if (array_key_exists((int) $from_socket, $this->clients)) {    //primary to secondary
            $this->clients[(int) $from_socket]->onTransmit(ISocketManager::TRANSDIR_PRI_TO_SEC);
            return;
        }
        //secondary to primary
        $this->clients[(int) $to_socket]->onTransmit(ISocketManager::TRANSDIR_SEC_TO_PRI);
    }

    /**
     * @return void
     */
    public function runForever()
    {
        while (true) {
            $this->listen(1, 0);
        }
    }
}
