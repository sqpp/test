### Blue Framwork history

Originally Blue Framework was the main repository of the commonly used classes of BitNinja. Previously known as Heimdall.
It was a PHP 5.4 repository, but much have change since then. Now many other repository rely on this repo, which use php 5.6, 7.0 and 7.2.
This make very hard to make any improvements in BitNinja Linux Agent.

BitNinja Linux Agent will use agent_master branch from now on. It may contains code which only acceptable in php 7.2+.

### Testing and errors with update from agent_master

The Blue Framework CI pipeline only serverd to ensure BitNinja Linux Agent releated tests are passing. Use your OWN pipeline.

Issues releated to updating Framework from agent_master must solved by the merger.

### Updating Heimdall folder

Most of the time you only need to update content of heimdall folder. You can do this with:

git checkout agent_master -- heimdall/

Errors may occurre.

### Updating with content of a commit from agent_master

You can use cherry-pick. See: https://git-scm.com/docs/git-cherry-pick

### Reverting mistakely merged commits

Atlassian has a great tutorial. See: https://www.atlassian.com/git/tutorials/undoing-changes/git-revert