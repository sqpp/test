<?php

namespace BitNinja\Framework\Api\Authentication\Login;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class License implements AuthInterface
{
    /**
     * Base64Encoded JWT bearer token
     *
     * @var string
     */
    private $bearerToken;

    /**
     * @var string
     */
    private $licenseKey;

    /**
     * @var mixed
     */
    private $client;

    /**
     * @var string
     */
    private $apiVersion;

    /**
     * @param mixed $container
     * @return void
     */
    public function __construct($container)
    {
        $this->licenseKey = $container['license_key'];
        $this->client = $container['authless_client'];
        $this->apiVersion = $container['api_version'];
    }

    /**
     * @return array
     */
    public function getHeaders(): array
    {
        return [
            'Authorization'   => "bearer  {$this->bearerToken}",
        ];
    }

    /**
     * @return boolean
     */
    public function authenticate()
    {
        $response = $this->client->post($this->apiVersion . '/authentication/login/license', ['licenseKey' => $this->licenseKey]);
        $json = json_decode($response->getBody(), true);
        $this->bearerToken  = $json['token'];
        return true;
    }
}
