<?php

namespace BitNinja\Framework\Api\V2\Patcher;


/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Jancsik Balázs <balazs.jancsik@bitninja.io>
 * @copyright  © 2024 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    3.10
 */
class Patch
{
    /**
     * @var \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param \BitNinja\Framework\Api\V2\DTO\Patcher\PatchIdentifiedRequest $patches
     * @return mixed
     */
    public function newPatchIdentified($patches)
    {
        $params = [];
        $params[] = $patches;
        return $this->client->post("/v2/service/patch/newPatchIdentified", $params);
    }

    /**
     * @param array $backupFiles
     * @return mixed
     */
    public function backupFiles($backupFiles)
    {
        $params = [];
        $params["backupInfo"] = $backupFiles;
        return $this->client->post("/v2/service/patch/backupFile", $params);
    }

    /**
     * @param \BitNinja\Framework\Api\V2\DTO\Patcher\AgentResponseDto $patches
     * @return mixed
     */
    public function agentResponse($patches)
    {
        $params = [];
        $params[] = $patches;
        return $this->client->post("/v2/service/patch/agentResponse", $params);
    }

    /**
     * @param \BitNinja\Framework\Api\V2\DTO\Patcher\AgentSyncDto $patches
     * @return mixed
     */
    public function agentSyncData($patches)
    {
        $params = [];
        $params[] = $patches;
        return $this->client->post("/v2/service/patch/agentSyncData", $params);
    }
}
