<?php

namespace BitNinja\Framework\Api\V2\Agent;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface CheckInInterface
{
    /**
     * @param \BitNinja\Framework\Api\V2\DTO\AgentCheckInRequestDTOInterface $agentCheckInRequestDTO
     * @return void
     */
    public function post(\BitNinja\Framework\Api\V2\DTO\AgentCheckInRequestDTOInterface $agentCheckInRequestDTO);
}
