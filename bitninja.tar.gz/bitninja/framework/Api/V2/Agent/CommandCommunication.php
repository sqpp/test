<?php

namespace BitNinja\Framework\Api\V2\Agent;

use BitNinja\Framework\Api\V2\Adapter\AdapterInterface;
use BitNinja\Framework\Api\V2\DTO\CommandCommunicationDTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Jancsik Balázs <balazs@bitninja.io>
 * @copyright  © 2023 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.38.7
 */
class CommandCommunication
{
    /** @var AdapterInterface */
    private $client;

    public function __construct(AdapterInterface $client)
    {
        $this->client = $client;
    }

    public function post(CommandCommunicationDTO $agentCheckInRequestDTO)
    {
        $params = [];
        $params[] = $agentCheckInRequestDTO;
        return $this->client->post("/v2/agent/commandCommunication", $params);
    }
}
