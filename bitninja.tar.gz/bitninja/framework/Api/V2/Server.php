<?php

namespace BitNinja\Framework\Api\V2;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Server
{
    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     * @return void
     */
    public function __construct(Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param int $page
     * @param int $pageSize
     * @return mixed
     */
    public function get(int $page, int $pageSize)
    {
        $params = [];
        $params['page'] = $page;
        $params['page-size'] = $pageSize;
        return $this->client->get("/v2/server", $params);
    }

    /**
     * @param int $serverId 
     * @return mixed
     */
    public function getById(int $serverId)
    {
        $params = [];
        return $this->client->get("/v2/server/$serverId", $params);
    }
}
