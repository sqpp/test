<?php

namespace BitNinja\Framework\Api\V2\Adapter;

use Psr\Http\Message\ResponseInterface;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface AdapterInterface
{

    /**
     * @param string $uri
     * @param array $data
     * @param array $headers
     * @return mixed
     */
    public function get(string $uri, array $data = [], array $headers = []);
    /**
     * @param string $uri
     * @param array $data
     * @param array $headers
     * @return mixed
     */
    public function post(string $uri, array $data = [], array $headers = []);
    /**
     * @param string $uri
     * @param array $data
     * @param array $headers
     * @return mixed
     */
    public function put(string $uri, array $data = [], array $headers = []);
    /**
     * @param string $uri
     * @param array $data
     * @param array $headers
     * @return mixed
     */
    public function patch(string $uri, array $data = [], array $headers = []);
    /**
     * @param string $uri
     * @param array $data
     * @param array $headers
     * @return mixed
     */
    public function delete(string $uri, array $data = [], array $headers = []);
}
