<?php

namespace BitNinja\Framework\Api\V2\Backup;

use BitNinja\Common\SocketIO\SocketIOMessage;
use BitNinja\Common\SocketIO\TraitSocketIOHelper;
use BitNinja\Framework\Api\Exception\MessageEmptyException;
use BitNinja\modules\Backup\lib\messages\FileChunkMessage;
use BitNinja\modules\Backup\lib\messages\FileMessage;
use ElephantIO\Client;
use Evenement\EventEmitter;
use Exception;
use React\EventLoop\LoopInterface;
use React\Promise\Deferred;
use React\Promise\PromiseInterface;
use React\Stream\DuplexResourceStream;
use React\Stream\ReadableResourceStream;
use React\Stream\ThroughStream;
use React\Stream\WritableResourceStream;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Daniel Bettenbuk <daniel.bettenbuk@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class BackupSocketIO extends EventEmitter
{
    use TraitSocketIOHelper;

    const EVENT_ON_DATA = 'data';
    const EVENT_ON_CLOSE = 'close';

    /**
     * @var mixed
     */
    private $client;

    /**
     * @var LoopInterface
     */
    private $loop;

    /**
     * @var string
     */
    private $messageName;

    /**
     * @var bool
     */
    private $connectionEstablished;

    public function __construct(\ElephantIO\Client $client, LoopInterface $loop, string $messageName)
    {
        $this->client = $client;
        $this->loop = $loop;
        $this->messageName = $messageName;
        $this->connectionEstablished = false;
    }

    /**
     * Initializes the Socket.IO client.
     * 
     * @param boolean $isChunked if set to `true`, the client will use a buffer to chunk data.
     * @return void
     */
    public function init(): void
    {
        $this->client->initialize();
        $this->connectionEstablished = true;
    }

    public function isClosed(): bool
    {
        return $this->client != null && !is_resource($this->client->getEngine()->getStream());
    }

    /**
     * Closes the connection.
     * 
     * @return void
     */
    public function closeConnection(): void
    {
        $this->client->close();
        $this->emit(self::EVENT_ON_CLOSE);
    }

    /**
     * Sends files.
     * 
     * Default implementation is not done yet.
     * 
     * @param mixed $descriptor the file descriptor.
     * @param mixed $filePath the absolute path of the file.
     * @param array $params additional parameters which should be sent.
     * @return PromiseInterface
     */
    public function sendFile($descriptor, $filePath, array $params = []): PromiseInterface
    {
        throw new \BadMethodCallException("Not implemented yet.");
    }

    /**
     * Emits a message through the Socket.IO client.
     * 
     * @param array $params
     * @return void
     */
    public function emitMessage(SocketIOMessage $message): void
    {
        $this->client->emit($this->messageName, $message->getParamsAsArray());
    }

    /**
     * Creates a properly formatted SocketIOMessage with the provided body and sends it.
     * 
     * @param array $params
     * @return void
     */
    public function sendSimpleMessage(array $params): void
    {
        $message = $this->createMessage();
        $message->setAdditionalParams($params);
        $this->emitMessage($message);
    }

    /**
     * Reads a message from the socket.
     * 
     * @return array
     */
    public function readMessage(): array
    {
        $message = @$this->client->getEngine()->read();

        if (!$message) {
            throw new Exception("Could not read from socket.");
        }

        if (empty(trim($message))) {
            throw new MessageEmptyException("Message is empty.");
        }

        $payload = $this->parsePayload($message);
        return $payload;
    }

    public function createMessage($filePath = null, $data = null) 
    {
        if (!is_null($data) && $filePath) {
            return new FileChunkMessage($filePath, $this->messageName, $data);
        }

        if ($filePath) {
            return new FileMessage($filePath, $this->messageName);
        }

        return new SocketIOMessage($this->messageName);
    }

    public function getMessageName()
    {
        return $this->messageName;
    }

    protected function getClient()
    {
        return $this->client;
    }

    protected function getLoop()
    {
        return $this->loop;
    }
}
