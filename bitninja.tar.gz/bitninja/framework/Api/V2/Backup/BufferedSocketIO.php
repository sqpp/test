<?php

namespace BitNinja\Framework\Api\V2\Backup;

use React\EventLoop\LoopInterface;
use React\Promise\Deferred;
use React\Promise\PromiseInterface;
use React\Stream\ReadableResourceStream;
use React\Stream\ThroughStream;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Daniel Bettenbuk <daniel.bettenbuk@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class BufferedSocketIO extends BackupSocketIO
{
    const EVENT_CHUNK_SENT = 'chunk_sent';

    /**
     * @var int
     */
    private $chunkSize;

    /**
     * The stream used by the socket.io connection.
     * 
     * @var resource
     */
    private $stream;

    /**
     * Determines if the socket stream should be in non blocking mode.
     * 
     * This is useful when you don't have to wait for any data from the stream (for example when we are sending only).
     * 
     * @var bool
     */
    private $isNonBlocking;

    public function __construct(\ElephantIO\Client $client, LoopInterface $loop, string $messageName, int $chunkSize = 30000, bool $isNonBlocking = true)
    {
        parent::__construct($client, $loop, $messageName);
        $this->chunkSize = $chunkSize;
        $this->isNonBlocking = $isNonBlocking;
    }

    /**
     * @inheritDoc
     */
    public function init(): void
    {
        parent::init();
        $this->connectionEstablished = true;
        $this->stream = $this->getClient()->getEngine()->getStream();
        \stream_set_blocking($this->stream, $this->isNonBlocking);
    }

    /**
     * @inheritDoc
     */
    public function sendFile($descriptor, $filePath, array $params = []): PromiseInterface
    {
        $deferred = new Deferred();
        $promise = $deferred->promise();
        if (!$descriptor || !is_resource($descriptor)) {
            $deferred->reject(new \InvalidArgumentException("Descriptor must be a resource."));
            return $promise;
        }

        $firstChunkSent = false;

        if (fstat($descriptor)['size'] === 0 && !is_dir($filePath)) {
            try {
                $this->sendChunk($filePath, '', $params, $firstChunkSent);
                $firstChunkSent = true;
                $deferred->resolve(null);
            } catch(\Exception $e) {
                $deferred->reject($e);
            }
            return $promise;
        }

        $handler = new ReadableResourceStream($descriptor, $this->getLoop(), $this->chunkSize);

        $through = new ThroughStream(function ($data) use ($params, $filePath, &$firstChunkSent) {
            $this->sendChunk($filePath, $data, $params, $firstChunkSent);
            $firstChunkSent = true;
        });

        $through
            ->on('error', function($e) use($deferred) {
                $deferred->reject($e);
            });

        $handler
            ->on('close', function() use($deferred) {
                $deferred->resolve(null);
            })
            ->on('error', function($e) use($deferred) {
                $deferred->reject($e);
            });

        $handler->pipe($through);
        return $promise;
    }

    protected function sendChunk(string $filePath, $data, $params, $firstChunkSent = false) {
        $params['isFirstChunk'] = !$firstChunkSent;
        $message = $this->createMessage($filePath, $data);
        $message->setAdditionalParams($params);
        $this->emitMessage($message);
        $this->emit(self::EVENT_CHUNK_SENT, [$data]);
    }
}
