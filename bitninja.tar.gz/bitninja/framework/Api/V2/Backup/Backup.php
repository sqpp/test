<?php

namespace BitNinja\Framework\Api\V2\Backup;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Daniel Bettenbuk <daniel.bettenbuk@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Backup
{
    /**
     * @var \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param int $page
     * @param int $pageSize
     * @return mixed
     */
    public function get($serverId)
    {
        return $this->client->get("/v2/backup/$serverId/path");
    }
}
