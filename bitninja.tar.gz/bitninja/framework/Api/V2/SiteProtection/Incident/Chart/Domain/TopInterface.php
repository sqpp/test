<?php

namespace BitNinja\Framework\Api\V2\SiteProtection\Incident\Chart\Domain;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface TopInterface
{
    /**
     * @param int $limit
     * @param string $time
     * @param string $to
     * @param string $from
     * @return void
     */
    public function get(int $limit, string $time, string $to, string $from);
}
