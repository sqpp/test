<?php

namespace BitNinja\Framework\Api\V2\SiteProtection\Incident\Chart;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface CountryInterface
{
    /**
     * @param string $to
     * @param int $limit
     * @param string $time
     * @param string $from
     * @return void
     */
    public function get(string $to, int $limit, string $time, string $from);
}
