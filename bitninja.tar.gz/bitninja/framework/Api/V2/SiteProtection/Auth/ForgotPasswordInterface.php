<?php

namespace BitNinja\Framework\Api\V2\SiteProtection\Auth;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface ForgotPasswordInterface
{
    /**
     * @param \BitNinja\Framework\Api\V2\DTO\SpUser\forgotPasswordDataInterface $forgotPasswordData
     * @return void
     */
    public function post(\BitNinja\Framework\Api\V2\DTO\SpUser\forgotPasswordDataInterface $forgotPasswordData);
}
