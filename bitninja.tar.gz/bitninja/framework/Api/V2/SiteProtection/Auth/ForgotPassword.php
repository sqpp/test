<?php

namespace BitNinja\Framework\Api\V2\SiteProtection\Auth;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class ForgotPassword
{
    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     * @return void
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param \BitNinja\Framework\Api\V2\DTO\SpUser\forgotPasswordDataInterface $forgotPasswordData
     * @return mixed
     */
    public function post(\BitNinja\Framework\Api\V2\DTO\SpUser\forgotPasswordDataInterface $forgotPasswordData)
    {
        $params = [];
        $params[] = $forgotPasswordData;
        return $this->client->post("/v2/site-protection/auth/forgot-password", $params);
    }
}
