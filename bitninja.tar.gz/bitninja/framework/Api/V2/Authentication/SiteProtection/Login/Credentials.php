<?php

namespace BitNinja\Framework\Api\V2\Authentication\SiteProtection\Login;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Credentials
{
    /**
     * @var \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     * @return void
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param \BitNinja\Framework\Api\V2\DTO\CredentialsDTOInterface $credentialsDTO
     * @return mixed
     */
    public function post(\BitNinja\Framework\Api\V2\DTO\CredentialsDTOInterface $credentialsDTO)
    {
        $params = [];
        $params[] = $credentialsDTO;
        return $this->client->post("/v2/authentication/site-protection/login/credentials", $params);
    }
}
