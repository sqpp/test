<?php

namespace BitNinja\Framework\Api\V2\Firewall\Whitelist;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface CountryInterface
{
    public function get();

    /**
     * @param  $array
     */
    public function post($array);

    /**
     * @param  $array
     */
    public function delete($array);
}
