<?php

namespace BitNinja\Framework\Api\V2\Firewall\Whitelist;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Asn
{
    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @return mixed
     */
    public function get()
    {
        return $this->client->get("/v2/firewall/whitelist/asn");
    }

    /**
     * @param \BitNinja\Framework\Api\V2\DTO\AsnNumberDTOInterface $asnNumberDTO
     * @return mixed
     */
    public function post(\BitNinja\Framework\Api\V2\DTO\AsnNumberDTOInterface $asnNumberDTO)
    {
        $params = [];
        $params[] = $asnNumberDTO;
        return $this->client->post("/v2/firewall/whitelist/asn", $params);
    }

    /**
     * @param \BitNinja\Framework\Api\V2\DTO\AsnNumberDTOInterface $asnNumberDTO
     * @return mixed
     */
    public function delete(\BitNinja\Framework\Api\V2\DTO\AsnNumberDTOInterface $asnNumberDTO)
    {
        $params = [];
        $params[] = $asnNumberDTO;
        return $this->client->delete("/v2/firewall/whitelist/asn", $params);
    }
}
