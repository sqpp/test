<?php

namespace BitNinja\Framework\Api\V2\Firewall\Blacklist;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Country
{
    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     * @return void
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @return mixed
     */
    public function get()
    {
        return $this->client->get("/v2/firewall/blacklist/country");
    }

    /**
     * @param  $array
     * @return mixed
     */
    public function post($array)
    {
        $params = [];
        $params[] = $array;
        return $this->client->post("/v2/firewall/blacklist/country", $params);
    }

    /**
     * @param  $array
     * @return mixed
     */
    public function delete($array)
    {
        $params = [];
        $params[] = $array;
        return $this->client->delete("/v2/firewall/blacklist/country", $params);
    }
}
