<?php

namespace BitNinja\Framework\Api\V2\Firewall;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class TrustedProxy
{
    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param int $page
     * @param int $pageSize
     * @return mixed
     */
    public function get(int $page, int $pageSize)
    {
        $params = [];
        $params['page'] = $page;
        $params['page-size'] = $pageSize;
        return $this->client->get("/v2/firewall/trusted-proxy", $params);
    }

    /**
     * @param  $array
     * @return mixed
     */
    public function post($array)
    {
        $params = [];
        $params[] = $array;
        return $this->client->post("/v2/firewall/trusted-proxy", $params);
    }

    /**
     * @param  $array
     * @return mixed
     */
    public function delete($array)
    {
        $params = [];
        $params[] = $array;
        return $this->client->delete("/v2/firewall/trusted-proxy", $params);
    }
}
