<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface CrashReportDTOInterface
{
    /**
     * Getter for osArch
     *
     * @return string
     */
    public function getOsArch(): string;

    /**
     * Setter for osArch
     *
     * @param string $osArch
     * @return self
     */
    public function setOsArch(string $osArch);

    /**
     * Getter for osVendor
     *
     * @return string
     */
    public function getOsVendor(): string;

    /**
     * Setter for osVendor
     *
     * @param string $osVendor
     * @return self
     */
    public function setOsVendor(string $osVendor);

    /**
     * Getter for osVersion
     *
     * @return string
     */
    public function getOsVersion(): string;

    /**
     * Setter for osVersion
     *
     * @param string $osVersion
     * @return self
     */
    public function setOsVersion(string $osVersion);

    /**
     * Getter for moduleName
     *
     * @return string
     */
    public function getModuleName(): string;

    /**
     * Setter for moduleName
     *
     * @param string $moduleName
     * @return self
     */
    public function setModuleName(string $moduleName);

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string;

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName);

    /**
     * Getter for serverTime
     *
     * @return string
     */
    public function getServerTime(): string;

    /**
     * Setter for serverTime
     *
     * @param string $serverTime
     * @return self
     */
    public function setServerTime(string $serverTime);

    /**
     * Getter for agentVersion
     *
     * @return string
     */
    public function getAgentVersion(): string;

    /**
     * Setter for agentVersion
     *
     * @param string $agentVersion
     * @return self
     */
    public function setAgentVersion(string $agentVersion);
}
