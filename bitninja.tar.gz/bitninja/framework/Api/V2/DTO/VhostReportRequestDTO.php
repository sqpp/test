<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class VhostReportRequestDTO implements VhostReportRequestDTOInterface, \JsonSerializable
{
    /**
     * List of server virtual hosts
     *
     * @var array
     */
    protected $vhosts;

    /**
     * Getter for vhosts
     *
     * @return array
     */
    public function getVhosts(): array
    {
        return $this->vhosts;
    }

    /**
     * Setter for vhosts
     *
     * @param array $vhosts
     * @return self
     */
    public function setVhosts(array $vhosts)
    {
        $this->vhosts = $vhosts;
        return $this;
    }

    /**
     * @param array $vhosts
     * @return void
     */
    public function __construct(array $vhosts)
    {
        $this->vhosts = $vhosts;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
