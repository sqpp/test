<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class PhishingSiteListResponseDTO implements PhishingSiteListResponseDTOInterface, \JsonSerializable
{
    /**
     * Phishing site url
     *
     * @var string
     */
    protected $url;

    /**
     * @var string
     */
    protected $server;

    /**
     * Which phishing provider contains this site
     *
     * @var array
     */
    protected $sources;

    /**
     * @var string
     */
    protected $detectedAt;

    /**
     * Getter for url
     *
     * @return string
     */
    public function getUrl(): string
    {
        return $this->url;
    }

    /**
     * Setter for url
     *
     * @param string $url
     * @return self
     */
    public function setUrl(string $url)
    {
        $this->url = $url;
        return $this;
    }

    /**
     * Getter for server
     *
     * @return string
     */
    public function getServer()
    {
        return $this->server;
    }

    /**
     * Setter for server
     *
     * @param string $server
     * @return self
     */
    public function setServer($server)
    {
        $this->server = $server;
        return $this;
    }

    /**
     * Getter for sources
     *
     * @return array
     */
    public function getSources(): array
    {
        return $this->sources;
    }

    /**
     * Setter for sources
     *
     * @param array $sources
     * @return self
     */
    public function setSources(array $sources)
    {
        $this->sources = $sources;
        return $this;
    }

    /**
     * Getter for detectedAt
     *
     * @return string
     */
    public function getDetectedAt()
    {
        return $this->detectedAt;
    }

    /**
     * Setter for detectedAt
     *
     * @param string $detectedAt
     * @return self
     */
    public function setDetectedAt($detectedAt)
    {
        $this->detectedAt = $detectedAt;
        return $this;
    }

    /**
     * @param string $url
     * @param array $sources
     * @return void
     */
    public function __construct(string $url, $server, array $sources, $detectedAt)
    {
        $this->url = $url;
        $this->server = $server;
        $this->sources = $sources;
        $this->detectedAt = $detectedAt;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
