<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class PaymentMethodAvailableDTO implements PaymentMethodAvailableDTOInterface, \JsonSerializable
{
    /**
     * Is payment method available for the user
     *
     * @var boolean
     */
    protected $available;

    /**
     * Getter for available
     *
     * @return boolean
     */
    public function getAvailable(): \boolean
    {
        return $this->available;
    }

    /**
     * Setter for available
     *
     * @param boolean $available
     * @return self
     */
    public function setAvailable(\boolean $available)
    {
        $this->available = $available;
        return $this;
    }

    /**
     * @param boolean $available
     * @return void
     */
    public function __construct(\boolean $available)
    {
        $this->available = $available;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
