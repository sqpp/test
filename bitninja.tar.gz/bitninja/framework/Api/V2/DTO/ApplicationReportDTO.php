<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class ApplicationReportDTO implements ApplicationReportDTOInterface, \JsonSerializable
{
    /**
     * Pattern which identified the application.
     * Example: WPS-Y19R01
     *
     * @var string
     */
    protected $ruleId;

    /**
     * Application's name.
     * Example: WORDPRESS
     *
     * @var string
     */
    protected $application;

    /**
     * Main server name.
     * Example: mydomain.tld
     *
     * @var string
     */
    protected $domain;

    /**
     * File system document root for the web server.
     * Example: /home/user/www
     *
     * @var string
     */
    protected $documentRoot;

    /**
     * Getter for ruleId
     *
     * @return string
     */
    public function getRuleId(): string
    {
        return $this->ruleId;
    }

    /**
     * Setter for ruleId
     *
     * @param string $ruleId
     * @return self
     */
    public function setRuleId(string $ruleId)
    {
        $this->ruleId = $ruleId;
        return $this;
    }

    /**
     * Getter for application
     *
     * @return string
     */
    public function getApplication(): string
    {
        return $this->application;
    }

    /**
     * Setter for application
     *
     * @param string $application
     * @return self
     */
    public function setApplication(string $application)
    {
        $this->application = $application;
        return $this;
    }

    /**
     * Getter for domain
     *
     * @return string
     */
    public function getDomain(): string
    {
        return $this->domain;
    }

    /**
     * Setter for domain
     *
     * @param string $domain
     * @return self
     */
    public function setDomain(string $domain)
    {
        $this->domain = $domain;
        return $this;
    }

    /**
     * Getter for documentRoot
     *
     * @return string
     */
    public function getDocumentRoot(): string
    {
        return $this->documentRoot;
    }

    /**
     * Setter for documentRoot
     *
     * @param string $documentRoot
     * @return self
     */
    public function setDocumentRoot(string $documentRoot)
    {
        $this->documentRoot = $documentRoot;
        return $this;
    }

    /**
     * @param string $ruleId
     * @param string $application
     * @param string $domain
     * @param string $documentRoot
     * @return void
     */
    public function __construct(string $ruleId, string $application, string $domain, string $documentRoot)
    {
        $this->ruleId = $ruleId;
        $this->application = $application;
        $this->domain = $domain;
        $this->documentRoot = $documentRoot;
    }

    /**
     * @param string $ruleId
     * @param string $application
     * @param string $domain
     * @param string $documentRoot
     * @return void
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
