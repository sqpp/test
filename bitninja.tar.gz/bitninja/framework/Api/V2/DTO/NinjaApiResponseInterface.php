<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface NinjaApiResponseInterface
{
    /**
     * Getter for status
     *
     * @return boolean
     */
    public function getStatus(): \boolean;

    /**
     * Setter for status
     *
     * @param boolean $status
     * @return self
     */
    public function setStatus(\boolean $status);

    /**
     * Getter for message
     *
     * @return object
     */
    public function getMessage(): object;

    /**
     * Setter for message
     *
     * @param object $message
     * @return self
     */
    public function setMessage(object $message);

    /**
     * Getter for id
     *
     * @return object
     */
    public function getId(): object;

    /**
     * Setter for id
     *
     * @param object $id
     * @return self
     */
    public function setId(object $id);
}
