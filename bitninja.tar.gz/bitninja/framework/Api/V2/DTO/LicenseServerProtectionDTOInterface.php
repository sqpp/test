<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface LicenseServerProtectionDTOInterface
{
    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int;

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id);

    /**
     * Getter for license
     *
     * @return string
     */
    public function getLicense(): string;

    /**
     * Setter for license
     *
     * @param string $license
     * @return self
     */
    public function setLicense(string $license);

    /**
     * Getter for status
     *
     * @return string
     */
    public function getStatus(): string;

    /**
     * Setter for status
     *
     * @param string $status
     * @return self
     */
    public function setStatus(string $status);

    /**
     * Getter for subscription
     *
     * @return string
     */
    public function getSubscription();

    /**
     * Setter for subscription
     *
     * @param string $subscription
     * @return self
     */
    public function setSubscription($subscription);

    /**
     * Getter for server
     *
     * @return server
     */
    public function getServer();

    /**
     * Setter for server
     *
     * @param string $server
     * @return self
     */
    public function setServer($server);

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt();

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt($createdAt);

    /**
     * Getter for trialDuration
     *
     * @return int
     */
    public function getTrialDuration(): int;

    /**
     * Setter for trialDuration
     *
     * @param int $trialDuration
     * @return self
     */
    public function setTrialDuration(int $trialDuration);

    /**
     * Getter for trialStarted
     *
     * @return string
     */
    public function getTrialStarted();

    /**
     * Setter for trialStarted
     *
     * @param string $trialStarted
     * @return self
     */
    public function setTrialStarted($trialStarted);
}
