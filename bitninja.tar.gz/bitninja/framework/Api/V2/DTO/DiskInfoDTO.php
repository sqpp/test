<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class DiskInfoDTO implements DiskInfoDTOInterface, \JsonSerializable
{
    /**
     * @var int
     */
    protected $totalCount;

    /**
     * @var int
     */
    protected $totalSize;

    /**
     * @var int
     */
    protected $totalUsed;

    /**
     * @var array
     */
    protected $details;

    /**
     * Getter for totalCount
     *
     * @return int
     */
    public function getTotalCount(): int
    {
        return $this->totalCount;
    }

    /**
     * Setter for totalCount
     *
     * @param int $totalCount
     * @return self
     */
    public function setTotalCount(int $totalCount)
    {
        $this->totalCount = $totalCount;
        return $this;
    }

    /**
     * Getter for totalSize
     *
     * @return int
     */
    public function getTotalSize(): int
    {
        return $this->totalSize;
    }

    /**
     * Setter for totalSize
     *
     * @param int $totalSize
     * @return self
     */
    public function setTotalSize(int $totalSize)
    {
        $this->totalSize = $totalSize;
        return $this;
    }

    /**
     * Getter for totalUsed
     *
     * @return int
     */
    public function getTotalUsed(): int
    {
        return $this->totalUsed;
    }

    /**
     * Setter for totalUsed
     *
     * @param int $totalUsed
     * @return self
     */
    public function setTotalUsed(int $totalUsed)
    {
        $this->totalUsed = $totalUsed;
        return $this;
    }

    /**
     * Getter for details
     *
     * @return array
     */
    public function getDetails(): array
    {
        return $this->details;
    }

    /**
     * Setter for details
     *
     * @param array $details
     * @return self
     */
    public function setDetails(array $details)
    {
        $this->details = $details;
        return $this;
    }

    /**
     * @param int $totalCount
     * @param int $totalSize
     * @param int $totalUsed
     * @param array $details
     * @return void
     */
    public function __construct(int $totalCount, int $totalSize, int $totalUsed, array $details)
    {
        $this->totalCount = $totalCount;
        $this->totalSize = $totalSize;
        $this->totalUsed = $totalUsed;
        $this->details = $details;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
