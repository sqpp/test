<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class FirewallListIpResponseDTO implements FirewallListIpResponseDTOInterface, \JsonSerializable
{
    /**
     * Unique ID for the listed IP range
     *
     * @var string
     */
    protected $id;

    /**
     * IP address long form
     *
     * @var object
     */
    protected $ip;

    /**
     * Comment for the entry
     *
     * @var string
     */
    protected $comment;

    protected $createdAt;

    /**
     * Getter for id
     *
     * @return string
     */
    public function getId(): string
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param string $id
     * @return self
     */
    public function setId(string $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for ip
     *
     * @return object
     */
    public function getIp(): object
    {
        return $this->ip;
    }

    /**
     * Setter for ip
     *
     * @param object $ip
     * @return self
     */
    public function setIp(object $ip)
    {
        $this->ip = $ip;
        return $this;
    }

    /**
     * Getter for comment
     *
     * @return string
     */
    public function getComment(): string
    {
        return $this->comment;
    }

    /**
     * Setter for comment
     *
     * @param string $comment
     * @return self
     */
    public function setComment(string $comment)
    {
        $this->comment = $comment;
        return $this;
    }

    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * @param string $id
     * @param object $ip
     * @param string $comment
     * @return void
     */
    public function __construct(string $id, object $ip, string $comment, $createdAt)
    {
        $this->id = $id;
        $this->ip = $ip;
        $this->comment = $comment;
        $this->createdAt = $createdAt;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
