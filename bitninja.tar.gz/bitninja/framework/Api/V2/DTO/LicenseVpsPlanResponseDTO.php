<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseVpsPlanResponseDTO implements LicenseVpsPlanResponseDTOInterface, \JsonSerializable
{
    /**
     * Plan id
     *
     * @var int
     */
    protected $planId;

    /**
     * Name of plane
     *
     * @var string
     */
    protected $displayName;

    /**
     * Description of plan
     *
     * @var string
     */
    protected $description;

    /**
     * Price of plan
     *
     * @var int
     */
    protected $price;

    /**
     * Number of licenses in this plan
     *
     * @var int
     */
    protected $licenseProvided;

    /**
     * Getter for planId
     *
     * @return int
     */
    public function getPlanId(): int
    {
        return $this->planId;
    }

    /**
     * Setter for planId
     *
     * @param int $planId
     * @return self
     */
    public function setPlanId(int $planId)
    {
        $this->planId = $planId;
        return $this;
    }

    /**
     * Getter for displayName
     *
     * @return string
     */
    public function getDisplayName(): string
    {
        return $this->displayName;
    }

    /**
     * Setter for displayName
     *
     * @param string $displayName
     * @return self
     */
    public function setDisplayName(string $displayName)
    {
        $this->displayName = $displayName;
        return $this;
    }

    /**
     * Getter for description
     *
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * Setter for description
     *
     * @param string $description
     * @return self
     */
    public function setDescription(string $description)
    {
        $this->description = $description;
        return $this;
    }

    /**
     * Getter for price
     *
     * @return int
     */
    public function getPrice(): int
    {
        return $this->price;
    }

    /**
     * Setter for price
     *
     * @param int $price
     * @return self
     */
    public function setPrice(int $price)
    {
        $this->price = $price;
        return $this;
    }

    /**
     * Getter for licenseProvided
     *
     * @return int
     */
    public function getLicenseProvided(): int
    {
        return $this->licenseProvided;
    }

    /**
     * Setter for licenseProvided
     *
     * @param int $licenseProvided
     * @return self
     */
    public function setLicenseProvided(int $licenseProvided)
    {
        $this->licenseProvided = $licenseProvided;
        return $this;
    }

    /**
     * @param int $planId
     * @param string $displayName
     * @param string $description
     * @param int $price
     * @param int $licenseProvided
     * @return void
     */
    public function __construct(int $planId, string $displayName, string $description, int $price, int $licenseProvided)
    {
        $this->planId = $planId;
        $this->displayName = $displayName;
        $this->description = $description;
        $this->price = $price;
        $this->licenseProvided = $licenseProvided;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
