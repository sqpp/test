<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Jancsik Balázs <balazs@bitninja.io>
 * @copyright  © 2023 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.38.7
 */
class CommandCommunicationDTO implements \JsonSerializable
{
    /** @var string */
    private $currentCommunicationChannel = "";

    /** @var int */
    private $reconnectionCount;

    /** @var ?int */
    private $socketConnectionCreatedAt;

    /** @var ?int */
    private $lastReceivedCommandAt;

    /** @var bool */
    private $fallbackHappened;

    public function __construct(string $currentCommunicationChannel, int $reconnectionCount, ?int $socketConnectionCreatedAt, ?int $lastReceivedCommandAt, bool $fallbackHappened)
    {
        $this->setCurrentCommunicationChannel($currentCommunicationChannel);
        $this->setReconnectionCount($reconnectionCount);
        $this->setSocketConnectionCreatedAt($socketConnectionCreatedAt);
        $this->setLastReceivedCommandAt($lastReceivedCommandAt);
        $this->setFallbackHappened($fallbackHappened);
    }

    public function jsonSerialize(): array
    {
        return get_object_vars($this);
    }

    public function getCurrentCommunicationChannel(): string
    {
        return $this->currentCommunicationChannel;
    }

    public function setCurrentCommunicationChannel(string $currentCommunicationChannel): void
    {
        $this->currentCommunicationChannel = $currentCommunicationChannel;
    }

    public function getReconnectionCount(): int
    {
        return $this->reconnectionCount;
    }

    public function setReconnectionCount(int $reconnectionCount): void
    {
        $this->reconnectionCount = $reconnectionCount;
    }

    public function getSocketConnectionCreatedAt(): ?int
    {
        return $this->socketConnectionCreatedAt;
    }

    public function setSocketConnectionCreatedAt(?int $socketConnectionCreatedAt): void
    {
        $this->socketConnectionCreatedAt = $socketConnectionCreatedAt;
    }

    public function getLastReceivedCommandAt(): ?int
    {
        return $this->lastReceivedCommandAt;
    }

    public function setLastReceivedCommandAt(?int $lastReceivedCommandAt): void
    {
        $this->lastReceivedCommandAt = $lastReceivedCommandAt;
    }

    public function setFallbackHappened(bool $fallbackHappened): void
    {
        $this->fallbackHappened = $fallbackHappened;
    }

    public function getFallbackHappened(): bool
    {
        return $this->fallbackHappened;
    }
}
