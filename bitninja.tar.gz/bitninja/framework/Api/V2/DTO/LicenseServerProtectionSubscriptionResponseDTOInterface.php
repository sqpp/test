<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface LicenseServerProtectionSubscriptionResponseDTOInterface
{
    /**
     * Getter for status
     *
     * @return string
     */
    public function getStatus(): string;

    /**
     * Setter for status
     *
     * @param string $status
     * @return self
     */
    public function setStatus(string $status);

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int;

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id);

    /**
     * Getter for planId
     *
     * @return int
     */
    public function getPlanId(): int;

    /**
     * Setter for planId
     *
     * @param int $planId
     * @return self
     */
    public function setPlanId(int $planId);

    /**
     * Getter for discountId
     *
     * @return int
     */
    public function getDiscountId(): int;

    /**
     * Setter for discountId
     *
     * @param int $discountId
     * @return self
     */
    public function setDiscountId(int $discountId);

    /**
     * Getter for serverId
     *
     * @return int
     */
    public function getServerId(): int;

    /**
     * Setter for serverId
     *
     * @param int $serverId
     * @return self
     */
    public function setServerId(int $serverId);

    /**
     * Getter for lastSuccessfulPayment
     *
     * @return void
     */
    public function getLastSuccessfulPayment();

    /**
     * Setter for lastSuccessfulPayment
     *
     * @param int $lastSuccessfulPayment
     * @return void
     */
    public function setLastSuccessfulPayment($lastSuccessfulPayment);

    /**
     * Getter for nextPaymentPeriod
     *
     * @return void
     */
    public function getNextPaymentPeriod();

    /**
     * Setter for nextPaymentPeriod
     *
     * @param int $nextPaymentPeriod
     * @return void
     */
    public function setNextPaymentPeriod($nextPaymentPeriod);

    /**
     * Getter for createdAt
     *
     * @return void
     */
    public function getCreatedAt();

    /**
     * Setter for createdAt
     *
     * @param int $createdAt
     * @return void
     */
    public function setCreatedAt($createdAt);
}
