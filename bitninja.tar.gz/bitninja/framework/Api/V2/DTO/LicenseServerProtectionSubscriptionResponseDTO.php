<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseServerProtectionSubscriptionResponseDTO implements LicenseServerProtectionSubscriptionResponseDTOInterface, \JsonSerializable
{
    /**
     * Subscription status
     *
     * @var string
     */
    protected $status;

    /**
     * @var int
     */
    protected $id;

    /**
     * Plan id
     *
     * @var int
     */
    protected $planId;

    /**
     * Discount id
     *
     * @var int
     */
    protected $discountId;

    /**
     * Which server uses this subscription
     *
     * @var int
     */
    protected $serverId;

    /**
     * @var string
     */
    protected $lastSuccessfulPayment;

    /**
     * @var string
     */
    protected $nextPaymentPeriod;

    /**
     * @var string
     */
    protected $createdAt;

    /**
     * Getter for status
     *
     * @return string
     */
    public function getStatus(): string
    {
        return $this->status;
    }

    /**
     * Setter for status
     *
     * @param string $status
     * @return self
     */
    public function setStatus(string $status)
    {
        $this->status = $status;
        return $this;
    }

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for planId
     *
     * @return int
     */
    public function getPlanId(): int
    {
        return $this->planId;
    }

    /**
     * Setter for planId
     *
     * @param int $planId
     * @return self
     */
    public function setPlanId(int $planId)
    {
        $this->planId = $planId;
        return $this;
    }

    /**
     * Getter for discountId
     *
     * @return int
     */
    public function getDiscountId(): int
    {
        return $this->discountId;
    }

    /**
     * Setter for discountId
     *
     * @param int $discountId
     * @return self
     */
    public function setDiscountId(int $discountId)
    {
        $this->discountId = $discountId;
        return $this;
    }

    /**
     * Getter for serverId
     *
     * @return int
     */
    public function getServerId(): int
    {
        return $this->serverId;
    }

    /**
     * Setter for serverId
     *
     * @param int $serverId
     * @return self
     */
    public function setServerId(int $serverId)
    {
        $this->serverId = $serverId;
        return $this;
    }

    /**
     * Getter for lastSuccessfulPayment
     *
     * @return string
     */
    public function getLastSuccessfulPayment()
    {
        return $this->lastSuccessfulPayment;
    }

    /**
     * Setter for lastSuccessfulPayment
     *
     * @param string $lastSuccessfulPayment
     * @return self
     */
    public function setLastSuccessfulPayment($lastSuccessfulPayment)
    {
        $this->lastSuccessfulPayment = $lastSuccessfulPayment;
        return $this;
    }

    /**
     * Getter for nextPaymentPeriod
     *
     * @return string
     */
    public function getNextPaymentPeriod()
    {
        return $this->nextPaymentPeriod;
    }

    /**
     * Setter for nextPaymentPeriod
     *
     * @param string $nextPaymentPeriod
     * @return self
     */
    public function setNextPaymentPeriod($nextPaymentPeriod)
    {
        $this->nextPaymentPeriod = $nextPaymentPeriod;
        return $this;
    }

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * @param string $status
     * @param int $id
     * @param int $planId
     * @param int $discountId
     * @param int $serverId
     * @return void
     */
    public function __construct(
        string $status,
        int $id,
        int $planId,
        int $discountId,
        int $serverId,
        $lastSuccessfulPayment,
        $nextPaymentPeriod,
        $createdAt
    ) {
        $this->status = $status;
        $this->id = $id;
        $this->planId = $planId;
        $this->discountId = $discountId;
        $this->serverId = $serverId;
        $this->lastSuccessfulPayment = $lastSuccessfulPayment;
        $this->nextPaymentPeriod = $nextPaymentPeriod;
        $this->createdAt = $createdAt;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
