<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseServerProtectionDTO implements LicenseServerProtectionDTOInterface, \JsonSerializable
{
    /**
     * License id
     *
     * @var int
     */
    protected $id;

    /**
     * License key
     *
     * @var string
     */
    protected $license;

    /**
     * License status
     *
     * @var string
     */
    protected $status;

    /**
     * License subscription
     *
     * @var string
     */
    protected $subscription;

    /**
     * License server
     *
     * @var string
     */
    protected $server;

    /**
     * License createdAt
     *
     * @var string
     */
    protected $createdAt;

    /**
     * The trial duration
     *
     * @var int
     */
    protected $trialDuration;

    /**
     * The trial trialStarted
     *
     * @var string
     */
    protected $trialStarted;

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for license
     *
     * @return string
     */
    public function getLicense(): string
    {
        return $this->license;
    }

    /**
     * Setter for license
     *
     * @param string $license
     * @return self
     */
    public function setLicense(string $license)
    {
        $this->license = $license;
        return $this;
    }

    /**
     * Getter for status
     *
     * @return string
     */
    public function getStatus(): string
    {
        return $this->status;
    }

    /**
     * Setter for status
     *
     * @param string $status
     * @return self
     */
    public function setStatus(string $status)
    {
        $this->status = $status;
        return $this;
    }

    /**
     * Setter for subscription
     *
     * @return string
     */
    public function getSubscription()
    {
        return $this->subscription;
    }

    /**
     * Setter for subscription
     *
     * @param string $subscription
     * @return self
     */
    public function setSubscription($subscription)
    {
        $this->subscription = $subscription;
        return $this;
    }

    /**
     * Setter for server
     *
     * @return string
     */
    public function getServer()
    {
        return $this->server;
    }

    /**
     * Setter for server
     *
     * @param string $server
     * @return self
     */
    public function setServer($server)
    {
        $this->server = $server;
        return $this;
    }

    /**
     * Setter for createdAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Getter for trialDuration
     *
     * @return int
     */
    public function getTrialDuration(): int
    {
        return $this->trialDuration;
    }

    /**
     * Setter for trialDuration
     *
     * @param int $trialDuration
     * @return self
     */
    public function setTrialDuration(int $trialDuration)
    {
        $this->trialDuration = $trialDuration;
        return $this;
    }

    /**
     * Setter for trialStarted
     *
     * @return string
     */
    public function getTrialStarted()
    {
        return $this->trialStarted;
    }

    /**
     * Setter for trialStarted
     *
     * @param int $trialStarted
     * @return self
     */
    public function setTrialStarted($trialStarted)
    {
        $this->trialStarted = $trialStarted;
        return $this;
    }

    /**
     * @param int $id
     * @param string $license
     * @param string $status
     * @param int $trialDuration
     * @return void
     */
    public function __construct(
        int $id,
        string $license,
        string $status,
        $subscription,
        $server,
        $createdAt,
        int $trialDuration,
        $trialStarted
    ) {
        $this->id = $id;
        $this->license = $license;
        $this->status = $status;
        $this->subscription = $subscription;
        $this->server = $server;
        $this->createdAt = $createdAt;
        $this->trialDuration = $trialDuration;
        $this->trialStarted = $trialStarted;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
