<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class ServerUpdateNameAndRemoteId implements ServerUpdateNameAndRemoteIdInterface, \JsonSerializable
{
    /**
     * Custom name for server. The hostname is the default
     * Example: myserver.bitninja.io
     *
     * @var string
     */
    protected $displayName;

    /**
     * Unique identifier for the server by the user
     * Example: myhost-srv-1
     *
     * @var string
     */
    protected $remoteId;

    /**
     * Getter for displayName
     *
     * @return string
     */
    public function getDisplayName(): string
    {
        return $this->displayName;
    }

    /**
     * Setter for displayName
     *
     * @param string $displayName
     * @return self
     */
    public function setDisplayName(string $displayName)
    {
        $this->displayName = $displayName;
        return $this;
    }

    /**
     * Getter for remoteId
     *
     * @return string
     */
    public function getRemoteId(): string
    {
        return $this->remoteId;
    }

    /**
     * Setter for remoteId
     *
     * @param string $remoteId
     * @return self
     */
    public function setRemoteId(string $remoteId)
    {
        $this->remoteId = $remoteId;
        return $this;
    }

    /**
     * @param string $displayName
     * @param string $remoteId
     * @return void
     */
    public function __construct(string $displayName, string $remoteId)
    {
        $this->displayName = $displayName;
        $this->remoteId = $remoteId;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
