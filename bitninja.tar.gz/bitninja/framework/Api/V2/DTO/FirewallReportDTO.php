<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class FirewallReportDTO implements FirewallReportDTOInterface, \JsonSerializable
{
    /**
     * @var int
     */
    protected $captchaShown;

    /**
     * @var int
     */
    protected $captchaSolved;

    /**
     * @var int
     */
    protected $connectionBlocked;

    /**
     * Getter for captchaShown
     *
     * @return int
     */
    public function getCaptchaShown(): int
    {
        return $this->captchaShown;
    }

    /**
     * Setter for captchaShown
     *
     * @param int $captchaShown
     * @return self
     */
    public function setCaptchaShown(int $captchaShown)
    {
        $this->captchaShown = $captchaShown;
        return $this;
    }

    /**
     * Getter for captchaSolved
     *
     * @return int
     */
    public function getCaptchaSolved(): int
    {
        return $this->captchaSolved;
    }

    /**
     * Setter for captchaSolved
     *
     * @param int $captchaSolved
     * @return self
     */
    public function setCaptchaSolved(int $captchaSolved)
    {
        $this->captchaSolved = $captchaSolved;
        return $this;
    }

    /**
     * Getter for connectionBlocked
     *
     * @return int
     */
    public function getConnectionBlocked(): int
    {
        return $this->connectionBlocked;
    }

    /**
     * Setter for connectionBlocked
     *
     * @param int $connectionBlocked
     * @return self
     */
    public function setConnectionBlocked(int $connectionBlocked)
    {
        $this->connectionBlocked = $connectionBlocked;
        return $this;
    }

    /**
     * @param int $captchaShown
     * @param int $captchaSolved
     * @param int $connectionBlocked
     * @return void
     */
    public function __construct(int $captchaShown, int $captchaSolved, int $connectionBlocked)
    {
        $this->captchaShown = $captchaShown;
        $this->captchaSolved = $captchaSolved;
        $this->connectionBlocked = $connectionBlocked;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
