<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface PhishingSiteListResponseDTOInterface
{
    /**
     * Getter for url
     *
     * @return string
     */
    public function getUrl(): string;

    /**
     * Setter for url
     *
     * @param string $url
     * @return self
     */
    public function setUrl(string $url);

    /**
     * Getter for server
     *
     * @return string
     */
    public function getServer();

    /**
     * Setter for server
     *
     * @param string $server
     * @return self
     */
    public function setServer($server);

    /**
     * Getter for sources
     *
     * @return array
     */
    public function getSources(): array;

    /**
     * Setter for sources
     *
     * @param array $sources
     * @return self
     */
    public function setSources(array $sources);

    /**
     * Getter for detectedAt
     *
     * @return string
     */
    public function getDetectedAt();

    /**
     * Setter for detectedAt
     *
     * @param string $detectedAt
     * @return self
     */
    public function setDetectedAt($detectedAt);
}
