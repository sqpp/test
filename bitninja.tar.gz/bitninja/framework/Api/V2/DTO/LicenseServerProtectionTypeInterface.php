<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface LicenseServerProtectionTypeInterface
{
    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int;

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id);

    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string;

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name);

    /**
     * Getter for status
     *
     * @return string
     */
    public function getStatus(): string;

    /**
     * Setter for status
     *
     * @param string $status
     * @return self
     */
    public function setStatus(string $status);

    /**
     * Getter for users
     *
     * @return int
     */
    public function getUsers(): int;

    /**
     * Setter for users
     *
     * @param int $users
     * @return self
     */
    public function setUsers(int $users);

    /**
     * Getter for nextPayment
     *
     * @return void
     */
    public function getNextPayment();

    /**
     * Setter for nextPayment
     *
     * @param int $nextPayment
     * @return void
     */
    public function setNextPayment($nextPayment);
}
