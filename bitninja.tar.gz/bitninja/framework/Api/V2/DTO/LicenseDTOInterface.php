<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface LicenseDTOInterface
{
    /**
     * Getter for licenseKey
     *
     * @return string
     */
    public function getLicenseKey(): string;

    /**
     * Setter for licenseKey
     *
     * @param string $licenseKey
     * @return self
     */
    public function setLicenseKey(string $licenseKey);
}
