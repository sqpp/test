<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface GeneralServerInfoDTOInterface
{
    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int;

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id);

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string;

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName);
}
