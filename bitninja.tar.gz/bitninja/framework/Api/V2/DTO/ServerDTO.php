<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class ServerDTO implements ServerDTOInterface, \JsonSerializable
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var int
     */
    protected $userId;

    /**
     * @var string
     */
    protected $agentVersion;

    /**
     * @var string
     */
    protected $agentStatus;

    /**
     * @var string
     */
    protected $hostName;

    /**
     * @var int
     */
    protected $ipReputationSize;

    /**
     * When the record was created
     * Example: 2019-03-05T17:15:12.000Z
     *
     * @var string
     */
    protected $createdAt;

    /**
     * When the record was updated
     * Example: 2019-03-05T17:15:12.000Z
     *
     * @var string
     */
    protected $updatedAt;

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for userId
     *
     * @return int
     */
    public function getUserId(): int
    {
        return $this->userId;
    }

    /**
     * Setter for userId
     *
     * @param int $userId
     * @return self
     */
    public function setUserId(int $userId)
    {
        $this->userId = $userId;
        return $this;
    }

    /**
     * Getter for agentVersion
     *
     * @return string
     */
    public function getAgentVersion(): string
    {
        return $this->agentVersion;
    }

    /**
     * Setter for agentVersion
     *
     * @param string $agentVersion
     * @return self
     */
    public function setAgentVersion(string $agentVersion)
    {
        $this->agentVersion = $agentVersion;
        return $this;
    }

    /**
     * Getter for agentStatus
     *
     * @return string
     */
    public function getAgentStatus(): string
    {
        return $this->agentStatus;
    }

    /**
     * Setter for agentStatus
     *
     * @param string $agentStatus
     * @return self
     */
    public function setAgentStatus(string $agentStatus)
    {
        $this->agentStatus = $agentStatus;
        return $this;
    }

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string
    {
        return $this->hostName;
    }

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName)
    {
        $this->hostName = $hostName;
        return $this;
    }

    /**
     * Getter for ipReputationSize
     *
     * @return int
     */
    public function getIpReputationSize(): int
    {
        return $this->ipReputationSize;
    }

    /**
     * Setter for ipReputationSize
     *
     * @param int $ipReputationSize
     * @return self
     */
    public function setIpReputationSize(int $ipReputationSize)
    {
        $this->ipReputationSize = $ipReputationSize;
        return $this;
    }

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt(): string
    {
        return $this->createdAt;
    }

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt(string $createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Getter for updatedAt
     *
     * @return string
     */
    public function getUpdatedAt(): string
    {
        return $this->updatedAt;
    }

    /**
     * Setter for updatedAt
     *
     * @param string $updatedAt
     * @return self
     */
    public function setUpdatedAt(string $updatedAt)
    {
        $this->updatedAt = $updatedAt;
        return $this;
    }

    /**
     * @param int $id
     * @param int $userId
     * @param string $agentVersion
     * @param string $agentStatus
     * @param string $hostName
     * @param int $ipReputationSize
     * @param string $createdAt
     * @param string $updatedAt
     * @return void
     */
    public function __construct(
        int $id,
        int $userId,
        string $agentVersion,
        string $agentStatus,
        string $hostName,
        int $ipReputationSize,
        string $createdAt,
        string $updatedAt
    ) {
        $this->id = $id;
        $this->userId = $userId;
        $this->agentVersion = $agentVersion;
        $this->agentStatus = $agentStatus;
        $this->hostName = $hostName;
        $this->ipReputationSize = $ipReputationSize;
        $this->createdAt = $createdAt;
        $this->updatedAt = $updatedAt;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
