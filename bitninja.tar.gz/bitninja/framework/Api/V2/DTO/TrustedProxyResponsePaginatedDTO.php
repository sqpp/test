<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class TrustedProxyResponsePaginatedDTO implements TrustedProxyResponsePaginatedDTOInterface, \JsonSerializable
{
    /**
     * @var BitNinja\Framework\Api\V2\DTO\IPaginationMetaInterface
     */
    protected $meta;

    /**
     * @var array
     */
    protected $data;

    /**
     * Getter for meta
     *
     * @return BitNinja\Framework\Api\V2\DTO\IPaginationMetaInterface
     */
    public function getMeta(): IPaginationMetaInterface
    {
        return $this->meta;
    }

    /**
     * Setter for meta
     *
     * @param BitNinja\Framework\Api\V2\DTO\IPaginationMetaInterface $meta
     * @return self
     */
    public function setMeta(IPaginationMetaInterface $meta)
    {
        $this->meta = $meta;
        return $this;
    }

    /**
     * Getter for data
     *
     * @return array
     */
    public function getData(): array
    {
        return $this->data;
    }

    /**
     * Setter for data
     *
     * @param array $data
     * @return self
     */
    public function setData(array $data)
    {
        $this->data = $data;
        return $this;
    }

    /**
     * @param BitNinja\Framework\Api\V2\DTO\IPaginationMetaInterface $meta
     * @param array $data
     * @return void
     */
    public function __construct(IPaginationMetaInterface $meta, array $data)
    {
        $this->meta = $meta;
        $this->data = $data;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
