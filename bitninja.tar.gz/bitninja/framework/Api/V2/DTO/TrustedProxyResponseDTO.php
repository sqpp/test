<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class TrustedProxyResponseDTO implements TrustedProxyResponseDTOInterface, \JsonSerializable
{
    /**
     * Unique ID for the proxy rule
     *
     * @var string
     */
    protected $id;

    /**
     * IP address long form
     *
     * @var string
     */
    protected $ip;

    /**
     * Comment for the entry
     *
     * @var string
     */
    protected $comment;

    /**
     * Creation date
     *
     * @var string
     */
    protected $createdAt;

    /**
     * Which global proxy provider host this IP
     *
     * @var string
     */
    protected $name;

    /**
     * Getter for id
     *
     * @return string
     */
    public function getId(): string
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param string $id
     * @return self
     */
    public function setId(string $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for ip
     *
     * @return string
     */
    public function getIp(): string
    {
        return $this->ip;
    }

    /**
     * Setter for ip
     *
     * @param string $ip
     * @return self
     */
    public function setIp(string $ip)
    {
        $this->ip = $ip;
        return $this;
    }

    /**
     * Getter for comment
     *
     * @return string
     */
    public function getComment(): string
    {
        return $this->comment;
    }

    /**
     * Setter for comment
     *
     * @param string $comment
     * @return self
     */
    public function setComment(string $comment)
    {
        $this->comment = $comment;
        return $this;
    }

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt(): string
    {
        return $this->createdAt;
    }

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt(string $createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * @param string $id
     * @param string $ip
     * @param string $comment
     * @param string $createdAt
     * @param string $name
     * @return void
     */
    public function __construct(string $id, string $ip, string $comment, string $createdAt, string $name)
    {
        $this->id = $id;
        $this->ip = $ip;
        $this->comment = $comment;
        $this->createdAt = $createdAt;
        $this->name = $name;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
