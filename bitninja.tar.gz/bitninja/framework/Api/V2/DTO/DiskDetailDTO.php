<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class DiskDetailDTO implements DiskDetailDTOInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $mountedOn;

    /**
     * @var int
     */
    protected $sizeTotal;

    /**
     * @var int
     */
    protected $sizeUsed;

    /**
     * Getter for mountedOn
     *
     * @return string
     */
    public function getMountedOn(): string
    {
        return $this->mountedOn;
    }

    /**
     * Setter for mountedOn
     *
     * @param string $mountedOn
     * @return self
     */
    public function setMountedOn(string $mountedOn)
    {
        $this->mountedOn = $mountedOn;
        return $this;
    }

    /**
     * Getter for sizeTotal
     *
     * @return int
     */
    public function getSizeTotal(): int
    {
        return $this->sizeTotal;
    }

    /**
     * Setter for sizeTotal
     *
     * @param int $sizeTotal
     * @return self
     */
    public function setSizeTotal(int $sizeTotal)
    {
        $this->sizeTotal = $sizeTotal;
        return $this;
    }

    /**
     * Getter for sizeUsed
     *
     * @return int
     */
    public function getSizeUsed(): int
    {
        return $this->sizeUsed;
    }

    /**
     * Setter for sizeUsed
     *
     * @param int $sizeUsed
     * @return self
     */
    public function setSizeUsed(int $sizeUsed)
    {
        $this->sizeUsed = $sizeUsed;
        return $this;
    }

    /**
     * @param string $mountedOn
     * @param int $sizeTotal
     * @param int $sizeUsed
     * @return void
     */
    public function __construct(string $mountedOn, int $sizeTotal, int $sizeUsed)
    {
        $this->mountedOn = $mountedOn;
        $this->sizeTotal = $sizeTotal;
        $this->sizeUsed = $sizeUsed;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
