<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface NetworkInterfaceDTOInterface
{
    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string;

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name);

    /**
     * Getter for addresses
     *
     * @return array
     */
    public function getAddresses(): array;

    /**
     * Setter for addresses
     *
     * @param array $addresses
     * @return self
     */
    public function setAddresses(array $addresses);
}
