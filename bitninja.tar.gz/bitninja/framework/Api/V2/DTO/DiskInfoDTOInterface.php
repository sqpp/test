<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface DiskInfoDTOInterface
{
    /**
     * Getter for totalCount
     *
     * @return int
     */
    public function getTotalCount(): int;

    /**
     * Setter for totalCount
     *
     * @param int $totalCount
     * @return self
     */
    public function setTotalCount(int $totalCount);

    /**
     * Getter for totalSize
     *
     * @return int
     */
    public function getTotalSize(): int;

    /**
     * Setter for totalSize
     *
     * @param int $totalSize
     * @return self
     */
    public function setTotalSize(int $totalSize);

    /**
     * Getter for totalUsed
     *
     * @return int
     */
    public function getTotalUsed(): int;

    /**
     * Setter for totalUsed
     *
     * @param int $totalUsed
     * @return self
     */
    public function setTotalUsed(int $totalUsed);

    /**
     * Getter for details
     *
     * @return array
     */
    public function getDetails(): array;

    /**
     * Setter for details
     *
     * @param array $details
     * @return self
     */
    public function setDetails(array $details);
}
