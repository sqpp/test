<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class CpanelDomainDTO implements CpanelDomainDTOInterface, \JsonSerializable
{
    /**
     * Domain name
     * Example: example.com
     *
     * @var string
     */
    protected $domain;

    /**
     * Domain's root directory
     * Example: /home/example/example.com
     *
     * @var string
     */
    protected $documentRoot;

    /**
     * Local user name
     * Example: bntest
     *
     * @var string
     */
    protected $user;

    /**
     * Domain admin contact information
     * Example: admin@example.com
     *
     * @var string
     */
    protected $serverAdmin;

    /**
     * Is it a sub or main domain of local user
     * Example: sub
     *
     * @var string
     */
    protected $type;

    /**
     * Getter for domain
     *
     * @return string
     */
    public function getDomain(): string
    {
        return $this->domain;
    }

    /**
     * Setter for domain
     *
     * @param string $domain
     * @return self
     */
    public function setDomain(string $domain)
    {
        $this->domain = $domain;
        return $this;
    }

    /**
     * Getter for documentRoot
     *
     * @return string
     */
    public function getDocumentRoot(): string
    {
        return $this->documentRoot;
    }

    /**
     * Setter for documentRoot
     *
     * @param string $documentRoot
     * @return self
     */
    public function setDocumentRoot(string $documentRoot)
    {
        $this->documentRoot = $documentRoot;
        return $this;
    }

    /**
     * Getter for user
     *
     * @return string
     */
    public function getUser(): string
    {
        return $this->user;
    }

    /**
     * Setter for user
     *
     * @param string $user
     * @return self
     */
    public function setUser(string $user)
    {
        $this->user = $user;
        return $this;
    }

    /**
     * Getter for serverAdmin
     *
     * @return string
     */
    public function getServerAdmin(): string
    {
        return $this->serverAdmin;
    }

    /**
     * Setter for serverAdmin
     *
     * @param string $serverAdmin
     * @return self
     */
    public function setServerAdmin(string $serverAdmin)
    {
        $this->serverAdmin = $serverAdmin;
        return $this;
    }

    /**
     * Getter for type
     *
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * Setter for type
     *
     * @param string $type
     * @return self
     */
    public function setType(string $type)
    {
        $this->type = $type;
        return $this;
    }

    /**
     * @param string $domain
     * @param string $documentRoot
     * @param string $user
     * @param string $serverAdmin
     * @param string $type
     * @return void
     */
    public function __construct(string $domain, string $documentRoot, string $user, string $serverAdmin, string $type)
    {
        $this->domain = $domain;
        $this->documentRoot = $documentRoot;
        $this->user = $user;
        $this->serverAdmin = $serverAdmin;
        $this->type = $type;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
