<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface UserReportDTOInterface
{
    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string;

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name);

    /**
     * Getter for uid
     *
     * @return int
     */
    public function getUid(): int;

    /**
     * Setter for uid
     *
     * @param int $uid
     * @return self
     */
    public function setUid(int $uid);

    /**
     * Getter for home
     *
     * @return string
     */
    public function getHome(): string;

    /**
     * Setter for home
     *
     * @param string $home
     * @return self
     */
    public function setHome(string $home);
}
