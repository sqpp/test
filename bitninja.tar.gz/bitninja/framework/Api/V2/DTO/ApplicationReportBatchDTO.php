<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class ApplicationReportBatchDTO implements ApplicationReportBatchDTOInterface, \JsonSerializable
{
    /**
     * Executed command's ID.
     * Example: 73bbd19b-19db-4002-b2ea-882e21a310c3
     *
     * @var string
     */
    protected $commandId;

    /**
     * BitNinja Agent version.
     * Example: 1.29.12
     *
     * @var string
     */
    protected $agentVersion;

    /**
     * Detected applictions.
     *
     * @var array
     */
    protected $applications;

    /**
     * Getter for commandId
     *
     * @return string
     */
    public function getCommandId(): string
    {
        return $this->commandId;
    }

    /**
     * Setter for commandId
     *
     * @param string $commandId
     * @return self
     */
    public function setCommandId(string $commandId)
    {
        $this->commandId = $commandId;
        return $this;
    }

    /**
     * Getter for agentVersion
     *
     * @return string
     */
    public function getAgentVersion(): string
    {
        return $this->agentVersion;
    }

    /**
     * Setter for agentVersion
     *
     * @param string $agentVersion
     * @return self
     */
    public function setAgentVersion(string $agentVersion)
    {
        $this->agentVersion = $agentVersion;
        return $this;
    }

    /**
     * Getter for applications
     *
     * @return array
     */
    public function getApplications(): array
    {
        return $this->applications;
    }

    /**
     * Setter for applications
     *
     * @param array $applications
     * @return self
     */
    public function setApplications(array $applications)
    {
        $this->applications = $applications;
        return $this;
    }

    /**
     * @param string $commandId
     * @param string $agentVersion
     * @param array $applications
     * @return void
     */
    public function __construct(string $commandId, string $agentVersion, array $applications)
    {
        $this->commandId = $commandId;
        $this->agentVersion = $agentVersion;
        $this->applications = $applications;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
