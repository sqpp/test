<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class VhostReportDTO implements VhostReportDTOInterface, \JsonSerializable
{
    /**
     * domain name for virtual host
     * Example: example.com
     *
     * @var string
     */
    protected $domain;

    /**
     * Root directory for virtual host
     * Example: /var/www/example.com
     *
     * @var string
     */
    protected $documentRoot;

    /**
     * Getter for domain
     *
     * @return string
     */
    public function getDomain(): string
    {
        return $this->domain;
    }

    /**
     * Setter for domain
     *
     * @param string $domain
     * @return self
     */
    public function setDomain(string $domain)
    {
        $this->domain = $domain;
        return $this;
    }

    /**
     * Getter for documentRoot
     *
     * @return string
     */
    public function getDocumentRoot(): string
    {
        return $this->documentRoot;
    }

    /**
     * Setter for documentRoot
     *
     * @param string $documentRoot
     * @return self
     */
    public function setDocumentRoot(string $documentRoot)
    {
        $this->documentRoot = $documentRoot;
        return $this;
    }

    /**
     * @param string $domain
     * @param string $documentRoot
     * @return void
     */
    public function __construct(string $domain, string $documentRoot)
    {
        $this->domain = $domain;
        $this->documentRoot = $documentRoot;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
