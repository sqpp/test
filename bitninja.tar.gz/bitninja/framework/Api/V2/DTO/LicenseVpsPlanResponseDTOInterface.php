<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface LicenseVpsPlanResponseDTOInterface
{
    /**
     * Getter for planId
     *
     * @return int
     */
    public function getPlanId(): int;

    /**
     * Setter for planId
     *
     * @param int $planId
     * @return self
     */
    public function setPlanId(int $planId);

    /**
     * Getter for displayName
     *
     * @return string
     */
    public function getDisplayName(): string;

    /**
     * Setter for displayName
     *
     * @param string $displayName
     * @return self
     */
    public function setDisplayName(string $displayName);

    /**
     * Getter for description
     *
     * @return string
     */
    public function getDescription(): string;

    /**
     * Setter for description
     *
     * @param string $description
     * @return self
     */
    public function setDescription(string $description);

    /**
     * Getter for price
     *
     * @return int
     */
    public function getPrice(): int;

    /**
     * Setter for price
     *
     * @param int $price
     * @return self
     */
    public function setPrice(int $price);

    /**
     * Getter for licenseProvided
     *
     * @return int
     */
    public function getLicenseProvided(): int;

    /**
     * Setter for licenseProvided
     *
     * @param int $licenseProvided
     * @return self
     */
    public function setLicenseProvided(int $licenseProvided);
}
