<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface TrustedProxyResponsePaginatedDTOInterface
{
    /**
     * Getter for meta
     *
     * @return BitNinja\Framework\Api\V2\DTO\IPaginationMetaInterface
     */
    public function getMeta(): IPaginationMetaInterface;

    /**
     * Setter for meta
     *
     * @param BitNinja\Framework\Api\V2\DTO\IPaginationMetaInterface $meta
     * @return self
     */
    public function setMeta(IPaginationMetaInterface $meta);

    /**
     * Getter for data
     *
     * @return array
     */
    public function getData(): array;

    /**
     * Setter for data
     *
     * @param array $data
     * @return self
     */
    public function setData(array $data);
}
