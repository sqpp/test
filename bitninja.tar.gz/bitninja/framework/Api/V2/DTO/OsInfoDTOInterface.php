<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface OsInfoDTOInterface
{
    /**
     * Getter for arch
     *
     * @return string
     */
    public function getArch(): string;

    /**
     * Setter for arch
     *
     * @param string $arch
     * @return self
     */
    public function setArch(string $arch);

    /**
     * Getter for vendor
     *
     * @return string
     */
    public function getVendor(): string;

    /**
     * Setter for vendor
     *
     * @param string $vendor
     * @return self
     */
    public function setVendor(string $vendor);

    /**
     * Getter for version
     *
     * @return string
     */
    public function getVersion(): string;

    /**
     * Setter for version
     *
     * @param string $version
     * @return self
     */
    public function setVersion(string $version);
}
