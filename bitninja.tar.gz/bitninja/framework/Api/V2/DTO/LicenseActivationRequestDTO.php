<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseActivationRequestDTO implements LicenseActivationRequestDTOInterface, \JsonSerializable
{
    /**
     * The acquired license key
     *
     * @var string
     */
    protected $license;

    /**
     * Product type
     * Example: vps
     * 
     * @var string
     */
    protected $type;

    /**
     * BitNinja Agent unique generated ID
     *
     * @var string
     */
    protected $appId;

    /**
     * Server hostname
     *
     * @var string
     */
    protected $hostName;

    /**
     * Getter for license
     *
     * @return string
     */
    public function getLicense(): string
    {
        return $this->license;
    }

    /**
     * Setter for license
     *
     * @param string $license
     * @return self
     */
    public function setLicense(string $license)
    {
        $this->license = $license;
        return $this;
    }

    /**
     * Getter for getType
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Setter for type
     *
     * @param string $type
     * @return self
     */
    public function setType($type)
    {
        $this->type = $type;
        return $this;
    }

    /**
     * Getter for appId
     *
     * @return string
     */
    public function getAppId(): string
    {
        return $this->appId;
    }

    /**
     * Setter for appId
     *
     * @param string $appId
     * @return self
     */
    public function setAppId(string $appId)
    {
        $this->appId = $appId;
        return $this;
    }

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string
    {
        return $this->hostName;
    }

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName)
    {
        $this->hostName = $hostName;
        return $this;
    }

    /**
     * @param string $license
     * @param string $appId
     * @param string $hostName
     * @return void
     */
    public function __construct(string $license, $type, string $appId, string $hostName)
    {
        $this->license = $license;
        $this->type = $type;
        $this->appId = $appId;
        $this->hostName = $hostName;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
