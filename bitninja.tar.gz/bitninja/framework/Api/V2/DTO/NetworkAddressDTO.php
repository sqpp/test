<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class NetworkAddressDTO implements NetworkAddressDTOInterface, \JsonSerializable
{
    /**
     * @var int
     */
    protected $ipVersion;

    /**
     * @var string
     */
    protected $ipAddress;

    /**
     * @var string
     */
    protected $broadcastAddress;

    /**
     * @var string
     */
    protected $netmaskAddress;

    /**
     * Getter for ipVersion
     *
     * @return int
     */
    public function getIpVersion(): int
    {
        return $this->ipVersion;
    }

    /**
     * Setter for ipVersion
     *
     * @param int $ipVersion
     * @return self
     */
    public function setIpVersion(int $ipVersion)
    {
        $this->ipVersion = $ipVersion;
        return $this;
    }

    /**
     * Getter for ipAddress
     *
     * @return string
     */
    public function getIpAddress(): string
    {
        return $this->ipAddress;
    }

    /**
     * Setter for ipAddress
     *
     * @param string $ipAddress
     * @return self
     */
    public function setIpAddress(string $ipAddress)
    {
        $this->ipAddress = $ipAddress;
        return $this;
    }

    /**
     * Getter for broadcastAddress
     *
     * @return string
     */
    public function getBroadcastAddress(): string
    {
        return $this->broadcastAddress;
    }

    /**
     * Setter for broadcastAddress
     *
     * @param string $broadcastAddress
     * @return self
     */
    public function setBroadcastAddress(string $broadcastAddress)
    {
        $this->broadcastAddress = $broadcastAddress;
        return $this;
    }

    /**
     * Getter for netmaskAddress
     *
     * @return string
     */
    public function getNetmaskAddress(): string
    {
        return $this->netmaskAddress;
    }

    /**
     * Setter for netmaskAddress
     *
     * @param string $netmaskAddress
     * @return self
     */
    public function setNetmaskAddress(string $netmaskAddress)
    {
        $this->netmaskAddress = $netmaskAddress;
        return $this;
    }

    /**
     * @param int $ipVersion
     * @param string $ipAddress
     * @param string $broadcastAddress
     * @param string $netmaskAddress
     * @return void
     */
    public function __construct(int $ipVersion, string $ipAddress, string $broadcastAddress, string $netmaskAddress)
    {
        $this->ipVersion = $ipVersion;
        $this->ipAddress = $ipAddress;
        $this->broadcastAddress = $broadcastAddress;
        $this->netmaskAddress = $netmaskAddress;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
