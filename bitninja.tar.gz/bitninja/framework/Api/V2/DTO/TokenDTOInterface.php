<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface TokenDTOInterface
{
    /**
     * Getter for token
     *
     * @return string
     */
    public function getToken(): string;

    /**
     * Setter for token
     *
     * @param string $token
     * @return self
     */
    public function setToken(string $token);
}
