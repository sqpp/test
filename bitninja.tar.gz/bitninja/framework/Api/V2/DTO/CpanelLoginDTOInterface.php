<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface CpanelLoginDTOInterface
{
    /**
     * Getter for userName
     *
     * @return string
     */
    public function getUserName(): string;

    /**
     * Setter for userName
     *
     * @param string $userName
     * @return self
     */
    public function setUserName(string $userName);

    /**
     * Getter for emailAddress
     *
     * @return string
     */
    public function getEmailAddress(): string;

    /**
     * Setter for emailAddress
     *
     * @param string $emailAddress
     * @return self
     */
    public function setEmailAddress(string $emailAddress);

    /**
     * Getter for serverId
     *
     * @return int
     */
    public function getServerId(): int;

    /**
     * Setter for serverId
     *
     * @param int $serverId
     * @return self
     */
    public function setServerId(int $serverId);

    /**
     * Getter for domains
     *
     * @return array
     */
    public function getDomains(): array;

    /**
     * Setter for domains
     *
     * @param array $domains
     * @return self
     */
    public function setDomains(array $domains);
}
