<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface MemoryInfoDTOInterface
{
    /**
     * Getter for total
     *
     * @return int
     */
    public function getTotal(): int;

    /**
     * Setter for total
     *
     * @param int $total
     * @return self
     */
    public function setTotal(int $total);

    /**
     * Getter for used
     *
     * @return int
     */
    public function getUsed(): int;

    /**
     * Setter for used
     *
     * @param int $used
     * @return self
     */
    public function setUsed(int $used);

    /**
     * Getter for free
     *
     * @return int
     */
    public function getFree(): int;

    /**
     * Setter for free
     *
     * @param int $free
     * @return self
     */
    public function setFree(int $free);

    /**
     * Getter for shared
     *
     * @return int
     */
    public function getShared(): int;

    /**
     * Setter for shared
     *
     * @param int $shared
     * @return self
     */
    public function setShared(int $shared);

    /**
     * Getter for available
     *
     * @return int
     */
    public function getAvailable(): int;

    /**
     * Setter for available
     *
     * @param int $available
     * @return self
     */
    public function setAvailable(int $available);
}
