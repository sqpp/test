<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface ServerDTOInterface
{
    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int;

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id);

    /**
     * Getter for userId
     *
     * @return int
     */
    public function getUserId(): int;

    /**
     * Setter for userId
     *
     * @param int $userId
     * @return self
     */
    public function setUserId(int $userId);

    /**
     * Getter for agentVersion
     *
     * @return string
     */
    public function getAgentVersion(): string;

    /**
     * Setter for agentVersion
     *
     * @param string $agentVersion
     * @return self
     */
    public function setAgentVersion(string $agentVersion);

    /**
     * Getter for agentStatus
     *
     * @return string
     */
    public function getAgentStatus(): string;

    /**
     * Setter for agentStatus
     *
     * @param string $agentStatus
     * @return self
     */
    public function setAgentStatus(string $agentStatus);

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string;

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName);

    /**
     * Getter for ipReputationSize
     *
     * @return int
     */
    public function getIpReputationSize(): int;

    /**
     * Setter for ipReputationSize
     *
     * @param int $ipReputationSize
     * @return self
     */
    public function setIpReputationSize(int $ipReputationSize);

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt(): string;

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt(string $createdAt);

    /**
     * Getter for updatedAt
     *
     * @return string
     */
    public function getUpdatedAt(): string;

    /**
     * Setter for updatedAt
     *
     * @param string $updatedAt
     * @return self
     */
    public function setUpdatedAt(string $updatedAt);
}
