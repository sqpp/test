<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class CrashReportDTO implements CrashReportDTOInterface, \JsonSerializable
{
    /**
     * CPU Architecture.
     * Example: i386
     *
     * @var string
     */
    protected $osArch;

    /**
     * Operating system vendor.
     * Example: ubuntu
     *
     * @var string
     */
    protected $osVendor;

    /**
     * Operating system version.
     * Example: 19.04
     *
     * @var string
     */
    protected $osVersion;

    /**
     * Crashed module's name.
     * Example: SenseLog
     *
     * @var string
     */
    protected $moduleName;

    /**
     * Local hostname.
     * Example: srv1.myhosting.net
     *
     * @var string
     */
    protected $hostName;

    /**
     * Server's GMT timestamp.
     * Example: 2019-06-25 11:26:38
     *
     * @var string
     */
    protected $serverTime;

    /**
     * BitNinja Agent version.
     * Example: 1.29.12
     *
     * @var string
     */
    protected $agentVersion;

    /**
     * Getter for osArch
     *
     * @return string
     */
    public function getOsArch(): string
    {
        return $this->osArch;
    }

    /**
     * Setter for osArch
     *
     * @param string $osArch
     * @return self
     */
    public function setOsArch(string $osArch)
    {
        $this->osArch = $osArch;
        return $this;
    }

    /**
     * Getter for osVendor
     *
     * @return string
     */
    public function getOsVendor(): string
    {
        return $this->osVendor;
    }

    /**
     * Setter for osVendor
     *
     * @param string $osVendor
     * @return self
     */
    public function setOsVendor(string $osVendor)
    {
        $this->osVendor = $osVendor;
        return $this;
    }

    /**
     * Getter for osVersion
     *
     * @return string
     */
    public function getOsVersion(): string
    {
        return $this->osVersion;
    }

    /**
     * Setter for osVersion
     *
     * @param string $osVersion
     * @return self
     */
    public function setOsVersion(string $osVersion)
    {
        $this->osVersion = $osVersion;
        return $this;
    }

    /**
     * Getter for moduleName
     *
     * @return string
     */
    public function getModuleName(): string
    {
        return $this->moduleName;
    }

    /**
     * Setter for moduleName
     *
     * @param string $moduleName
     * @return self
     */
    public function setModuleName(string $moduleName)
    {
        $this->moduleName = $moduleName;
        return $this;
    }

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string
    {
        return $this->hostName;
    }

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName)
    {
        $this->hostName = $hostName;
        return $this;
    }

    /**
     * Getter for serverTime
     *
     * @return string
     */
    public function getServerTime(): string
    {
        return $this->serverTime;
    }

    /**
     * Setter for serverTime
     *
     * @param string $serverTime
     * @return self
     */
    public function setServerTime(string $serverTime)
    {
        $this->serverTime = $serverTime;
        return $this;
    }

    /**
     * Getter for agentVersion
     *
     * @return string
     */
    public function getAgentVersion(): string
    {
        return $this->agentVersion;
    }

    /**
     * Setter for agentVersion
     *
     * @param string $agentVersion
     * @return self
     */
    public function setAgentVersion(string $agentVersion)
    {
        $this->agentVersion = $agentVersion;
        return $this;
    }

    /**
     * @param string $osArch
     * @param string $osVendor
     * @param string $osVersion
     * @param string $moduleName
     * @param string $hostName
     * @param string $serverTime
     * @param string $agentVersion
     * @return void
     */
    public function __construct(
        string $osArch,
        string $osVendor,
        string $osVersion,
        string $moduleName,
        string $hostName,
        string $serverTime,
        string $agentVersion
    ) {
        $this->osArch = $osArch;
        $this->osVendor = $osVendor;
        $this->osVersion = $osVersion;
        $this->moduleName = $moduleName;
        $this->hostName = $hostName;
        $this->serverTime = $serverTime;
        $this->agentVersion = $agentVersion;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
