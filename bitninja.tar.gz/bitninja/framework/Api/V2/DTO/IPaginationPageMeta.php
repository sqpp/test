<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class IPaginationPageMeta implements IPaginationPageMetaInterface, \JsonSerializable
{
    /**
     * @var int
     */
    protected $size;

    /**
     * @var int
     */
    protected $current;

    /**
     * @var int
     */
    protected $total;

    /**
     * Getter for size
     *
     * @return int
     */
    public function getSize(): int
    {
        return $this->size;
    }

    /**
     * Setter for size
     *
     * @param int $size
     * @return self
     */
    public function setSize(int $size)
    {
        $this->size = $size;
        return $this;
    }

    /**
     * Getter for current
     *
     * @return int
     */
    public function getCurrent(): int
    {
        return $this->current;
    }

    /**
     * Setter for current
     *
     * @param int $current
     * @return self
     */
    public function setCurrent(int $current)
    {
        $this->current = $current;
        return $this;
    }

    /**
     * Getter for total
     *
     * @return int
     */
    public function getTotal(): int
    {
        return $this->total;
    }

    /**
     * Setter for total
     *
     * @param int $total
     * @return self
     */
    public function setTotal(int $total)
    {
        $this->total = $total;
        return $this;
    }

    /**
     * @param int $size
     * @param int $current
     * @param int $total
     * @return void
     */
    public function __construct(int $size, int $current, int $total)
    {
        $this->size = $size;
        $this->current = $current;
        $this->total = $total;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
