<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class FileIncidentBySignatureListResponseDTO implements FileIncidentBySignatureListResponseDTOInterface, \JsonSerializable
{
    /**
     *
     * @var int
     */
    protected $serverId;

    /**
     *
     * @var string
     */
    protected $fileInfo;

    /**
     *
     * @var string
     */
    protected $malwareInfo;

    /**
     *
     * @var string
     */
    protected $createdAt;

    /**
     * Getter for serverId
     *
     * @return int
     */
    public function getServerId(): int
    {
        return $this->serverId;
    }

    /**
     * Setter for serverId
     *
     * @param int $serverId
     * @return self
     */
    public function setServerId(int $serverId)
    {
        $this->serverId = $serverId;
        return $this;
    }

    /**
     * Getter for fileInfo
     *
     * @return string
     */
    public function getFileInfo()
    {
        return $this->fileInfo;
    }

    /**
     * Setter for fileInfo
     *
     * @param string $fileInfo
     * @return self
     */
    public function setFileInfo($fileInfo)
    {
        $this->fileInfo = $fileInfo;
        return $this;
    }

    /**
     * Getter for malwareInfo
     *
     * @return string
     */
    public function getMalwareInfo()
    {
        return $this->malwareInfo;
    }

    /**
     * Setter for malwareInfo
     *
     * @param string $malwareInfo
     * @return self
     */
    public function setMalwareInfo($malwareInfo)
    {
        $this->malwareInfo = $malwareInfo;
        return $this;
    }

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * @param int $serverId
     * @param string $fileInfo
     * @param string $malwareInfo
     * @param string $createdAt
     * @return void
     */
    public function __construct(int $serverId, $fileInfo, $malwareInfo, $createdAt)
    {
        $this->serverId = $serverId;
        $this->fileInfo = $fileInfo;
        $this->malwareInfo = $malwareInfo;
        $this->createdAt = $createdAt;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
