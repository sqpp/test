<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class ServerResponseDTO implements ServerResponseDTOInterface, \JsonSerializable
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var int
     */
    protected $userId;

    /**
     * @var string
     */
    protected $agentVersion;

    /**
     * @var string
     */
    protected $agentStatus;

    /**
     * @var string
     */
    protected $hostName;

    /**
     * @var string
     */
    protected $remoteId;

    /**
     * @var string
     */
    protected $displayName;

    /**
     * @var int
     */
    protected $systemLoad1;

    /**
     * @var int
     */
    protected $systemLoad5;

    /**
     * @var int
     */
    protected $systemLoad15;

    /**
     * @var int
     */
    protected $ipReputationSize;

    /**
     * @var int
     */
    protected $systemUsers;

    /**
     * @var int
     */
    protected $normalUsers;

    /**
     * @var string
     */
    protected $publicIp;

    /**
     * @var string
     */
    protected $emailData;

    /**
     * @var int
     */
    protected $actionSec;

    /**
     * @var string
     */
    protected $osInfo;

    /**
     * @var string
     */
    protected $nicInfo;

    /**
     * @var int
     */
    protected $deleted;

    /**
     * @var int
     */
    protected $licenseId;

    /**
     * @var int
     */
    protected $trustPoints;

    /**
     * @var string
     */
    protected $ptr;

    protected $lastScan;

    /**
     * @var string
     */
    protected $instanceId;

    /**
     * When the record was created
     * Example: 2019-03-05T17:15:12.000Z
     *
     * @var string
     */
    protected $createdAt;

    /**
     * When the record was updated
     * Example: 2019-03-05T17:15:12.000Z
     *
     * @var string
     */
    protected $updatedAt;

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for userId
     *
     * @return int
     */
    public function getUserId(): int
    {
        return $this->userId;
    }

    /**
     * Setter for userId
     *
     * @param int $userId
     * @return self
     */
    public function setUserId(int $userId)
    {
        $this->userId = $userId;
        return $this;
    }

    /**
     * Getter for agentVersion
     *
     * @return string
     */
    public function getAgentVersion(): string
    {
        return $this->agentVersion;
    }

    /**
     * Setter for agentVersion
     *
     * @param string $agentVersion
     * @return self
     */
    public function setAgentVersion(string $agentVersion)
    {
        $this->agentVersion = $agentVersion;
        return $this;
    }

    /**
     * Getter for agentStatus
     *
     * @return string
     */
    public function getAgentStatus(): string
    {
        return $this->agentStatus;
    }

    /**
     * Setter for agentStatus
     *
     * @param string $agentStatus
     * @return self
     */
    public function setAgentStatus(string $agentStatus)
    {
        $this->agentStatus = $agentStatus;
        return $this;
    }

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string
    {
        return $this->hostName;
    }

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName)
    {
        $this->hostName = $hostName;
        return $this;
    }

    /**
     * Getter for remoteId
     *
     * @return string
     */
    public function getRemoteId(): string
    {
        return $this->remoteId;
    }

    /**
     * Setter for remoteId
     *
     * @param string $remoteId
     * @return self
     */
    public function setRemoteId(string $remoteId)
    {
        $this->remoteId = $remoteId;
        return $this;
    }

    /**
     * Getter for displayName
     *
     * @return string
     */
    public function getDisplayName(): string
    {
        return $this->displayName;
    }

    /**
     * Setter for displayName
     *
     * @param string $displayName
     * @return self
     */
    public function setDisplayName(string $displayName)
    {
        $this->displayName = $displayName;
        return $this;
    }

    /**
     * Getter for systemLoad1
     *
     * @return int
     */
    public function getSystemLoad1(): int
    {
        return $this->systemLoad1;
    }

    /**
     * Setter for systemLoad1
     *
     * @param int $systemLoad1
     * @return self
     */
    public function setSystemLoad1(int $systemLoad1)
    {
        $this->systemLoad1 = $systemLoad1;
        return $this;
    }

    /**
     * Getter for systemLoad5
     *
     * @return int
     */
    public function getSystemLoad5(): int
    {
        return $this->systemLoad5;
    }

    /**
     * Setter for systemLoad5
     *
     * @param int $systemLoad5
     * @return self
     */
    public function setSystemLoad5(int $systemLoad5)
    {
        $this->systemLoad5 = $systemLoad5;
        return $this;
    }

    /**
     * Getter for systemLoad15
     *
     * @return int
     */
    public function getSystemLoad15(): int
    {
        return $this->systemLoad15;
    }

    /**
     * Setter for systemLoad15
     *
     * @param int $systemLoad15
     * @return self
     */
    public function setSystemLoad15(int $systemLoad15)
    {
        $this->systemLoad15 = $systemLoad15;
        return $this;
    }

    /**
     * Getter for ipReputationSize
     *
     * @return int
     */
    public function getIpReputationSize(): int
    {
        return $this->ipReputationSize;
    }

    /**
     * Setter for ipReputationSize
     *
     * @param int $ipReputationSize
     * @return self
     */
    public function setIpReputationSize(int $ipReputationSize)
    {
        $this->ipReputationSize = $ipReputationSize;
        return $this;
    }

    /**
     * Getter for systemUsers
     *
     * @return int
     */
    public function getSystemUsers(): int
    {
        return $this->systemUsers;
    }

    /**
     * Setter for systemUsers
     *
     * @param int $systemUsers
     * @return self
     */
    public function setSystemUsers(int $systemUsers)
    {
        $this->systemUsers = $systemUsers;
        return $this;
    }

    /**
     * Getter for normalUsers
     *
     * @return int
     */
    public function getNormalUsers(): int
    {
        return $this->normalUsers;
    }

    /**
     * Setter for normalUsers
     *
     * @param int $normalUsers
     * @return self
     */
    public function setNormalUsers(int $normalUsers)
    {
        $this->normalUsers = $normalUsers;
        return $this;
    }

    /**
     * Getter for publicIp
     *
     * @return string
     */
    public function getPublicIp(): string
    {
        return $this->publicIp;
    }

    /**
     * Setter for publicIp
     *
     * @param string $publicIp
     * @return self
     */
    public function setPublicIp(string $publicIp)
    {
        $this->publicIp = $publicIp;
        return $this;
    }

    /**
     * Getter for emailData
     *
     * @return string
     */
    public function getEmailData(): string
    {
        return $this->emailData;
    }

    /**
     * Setter for emailData
     *
     * @param string $emailData
     * @return self
     */
    public function setEmailData(string $emailData)
    {
        $this->emailData = $emailData;
        return $this;
    }

    /**
     * Getter for actionSec
     *
     * @return int
     */
    public function getActionSec(): int
    {
        return $this->actionSec;
    }

    /**
     * Setter for actionSec
     *
     * @param int $actionSec
     * @return self
     */
    public function setActionSec(int $actionSec)
    {
        $this->actionSec = $actionSec;
        return $this;
    }

    /**
     * Getter for osInfo
     *
     * @return string
     */
    public function getOsInfo(): string
    {
        return $this->osInfo;
    }

    /**
     * Setter for osInfo
     *
     * @param string $osInfo
     * @return self
     */
    public function setOsInfo(string $osInfo)
    {
        $this->osInfo = $osInfo;
        return $this;
    }

    /**
     * Getter for nicInfo
     *
     * @return string
     */
    public function getNicInfo(): string
    {
        return $this->nicInfo;
    }

    /**
     * Setter for nicInfo
     *
     * @param string $nicInfo
     * @return self
     */
    public function setNicInfo(string $nicInfo)
    {
        $this->nicInfo = $nicInfo;
        return $this;
    }

    /**
     * Getter for deleted
     *
     * @return int
     */
    public function getDeleted(): int
    {
        return $this->deleted;
    }

    /**
     * Setter for deleted
     *
     * @param int $deleted
     * @return self
     */
    public function setDeleted(int $deleted)
    {
        $this->deleted = $deleted;
        return $this;
    }

    /**
     * Getter for licenseId
     *
     * @return int
     */
    public function getLicenseId(): int
    {
        return $this->licenseId;
    }

    /**
     * Setter for licenseId
     *
     * @param int $licenseId
     * @return self
     */
    public function setLicenseId(int $licenseId)
    {
        $this->licenseId = $licenseId;
        return $this;
    }

    /**
     * Getter for trustPoints
     *
     * @return int
     */
    public function getTrustPoints(): int
    {
        return $this->trustPoints;
    }

    /**
     * Setter for trustPoints
     *
     * @param int $trustPoints
     * @return self
     */
    public function setTrustPoints(int $trustPoints)
    {
        $this->trustPoints = $trustPoints;
        return $this;
    }

    /**
     * Getter for ptr
     *
     * @return string
     */
    public function getPtr(): string
    {
        return $this->ptr;
    }

    /**
     * Setter for ptr
     *
     * @param string $ptr
     * @return self
     */
    public function setPtr(string $ptr)
    {
        $this->ptr = $ptr;
        return $this;
    }

    public function getLastScan()
    {
        return $this->lastScan;
    }

    public function setLastScan($lastScan)
    {
        $this->lastScan = $lastScan;
        return $this;
    }

    /**
     * Getter for instanceId
     *
     * @return string
     */
    public function getInstanceId(): string
    {
        return $this->instanceId;
    }

    /**
     * Setter for instanceId
     *
     * @param string $instanceId
     * @return self
     */
    public function setInstanceId(string $instanceId)
    {
        $this->instanceId = $instanceId;
        return $this;
    }

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt(): string
    {
        return $this->createdAt;
    }

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt(string $createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Getter for updatedAt
     *
     * @return string
     */
    public function getUpdatedAt(): string
    {
        return $this->updatedAt;
    }

    /**
     * Setter for updatedAt
     *
     * @param string $updatedAt
     * @return self
     */
    public function setUpdatedAt(string $updatedAt)
    {
        $this->updatedAt = $updatedAt;
        return $this;
    }

    /**
     * @param int $id
     * @param int $userId
     * @param string $agentVersion
     * @param string $agentStatus
     * @param string $hostName
     * @param string $remoteId
     * @param string $displayName
     * @param int $systemLoad1
     * @param int $systemLoad5
     * @param int $systemLoad15
     * @param int $ipReputationSize
     * @param int $systemUsers
     * @param int $normalUsers
     * @param string $publicIp
     * @param string $emailData
     * @param int $actionSec
     * @param string $osInfo
     * @param string $nicInfo
     * @param int $deleted
     * @param int $licenseId
     * @param int $trustPoints
     * @param string $ptr
     * @param string $instanceId
     * @param string $createdAt
     * @param string $updatedAt
     * @return void
     */
    public function __construct(
        int $id,
        int $userId,
        string $agentVersion,
        string $agentStatus,
        string $hostName,
        string $remoteId,
        string $displayName,
        int $systemLoad1,
        int $systemLoad5,
        int $systemLoad15,
        int $ipReputationSize,
        int $systemUsers,
        int $normalUsers,
        string $publicIp,
        string $emailData,
        int $actionSec,
        string $osInfo,
        string $nicInfo,
        int $deleted,
        int $licenseId,
        int $trustPoints,
        string $ptr,
        $lastScan,
        string $instanceId,
        string $createdAt,
        string $updatedAt
    ) {
        $this->id = $id;
        $this->userId = $userId;
        $this->agentVersion = $agentVersion;
        $this->agentStatus = $agentStatus;
        $this->hostName = $hostName;
        $this->remoteId = $remoteId;
        $this->displayName = $displayName;
        $this->systemLoad1 = $systemLoad1;
        $this->systemLoad5 = $systemLoad5;
        $this->systemLoad15 = $systemLoad15;
        $this->ipReputationSize = $ipReputationSize;
        $this->systemUsers = $systemUsers;
        $this->normalUsers = $normalUsers;
        $this->publicIp = $publicIp;
        $this->emailData = $emailData;
        $this->actionSec = $actionSec;
        $this->osInfo = $osInfo;
        $this->nicInfo = $nicInfo;
        $this->deleted = $deleted;
        $this->licenseId = $licenseId;
        $this->trustPoints = $trustPoints;
        $this->ptr = $ptr;
        $this->lastScan = $lastScan;
        $this->instanceId = $instanceId;
        $this->createdAt = $createdAt;
        $this->updatedAt = $updatedAt;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
