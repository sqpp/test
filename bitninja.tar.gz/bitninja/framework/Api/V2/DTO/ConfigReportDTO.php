<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class ConfigReportDTO implements ConfigReportDTOInterface, \JsonSerializable
{
    /**
     * json object
     * Example: Array
     *
     * @var object
     */
    protected $config;

    /**
     * Getter for config
     *
     * @return object
     */
    public function getConfig(): object
    {
        return $this->config;
    }

    /**
     * Setter for config
     *
     * @param object $config
     * @return self
     */
    public function setConfig(object $config)
    {
        $this->config = $config;
        return $this;
    }

    /**
     * @param object $config
     * @return void
     */
    public function __construct(object $config)
    {
        $this->config = $config;
    }

    /**
     * @param object $config
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
