<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface LicenseVpsTypeInterface
{
    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int;

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id);

    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string;

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name);

    /**
     * Getter for size
     *
     * @return int
     */
    public function getSize(): int;

    /**
     * Setter for size
     *
     * @param int $size
     * @return self
     */
    public function setSize(int $size);

    /**
     * Getter for nextPayment
     *
     * @return string
     */
    public function getNextPayment();

    /**
     * Setter for nextPayment
     *
     * @param string $nextPayment
     * @return self
     */
    public function setNextPayment($nextPayment);
}
