<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface TrustedProxyResponseDTOInterface
{
    /**
     * Getter for id
     *
     * @return string
     */
    public function getId(): string;

    /**
     * Setter for id
     *
     * @param string $id
     * @return self
     */
    public function setId(string $id);

    /**
     * Getter for ip
     *
     * @return string
     */
    public function getIp(): string;

    /**
     * Setter for ip
     *
     * @param string $ip
     * @return self
     */
    public function setIp(string $ip);

    /**
     * Getter for comment
     *
     * @return string
     */
    public function getComment(): string;

    /**
     * Setter for comment
     *
     * @param string $comment
     * @return self
     */
    public function setComment(string $comment);

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt(): string;

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt(string $createdAt);

    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string;

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name);
}
