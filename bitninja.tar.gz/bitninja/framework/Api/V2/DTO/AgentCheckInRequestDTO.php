<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class AgentCheckInRequestDTO implements AgentCheckInRequestDTOInterface, \JsonSerializable
{
    /**
     * Agent unique license key
     *
     * @var string
     */
    protected $license;

    /**
     * Agent host name
     *
     * @var string
     */
    protected $hostName;

    /**
     * Agent unique appId
     *
     * @var string
     */
    protected $appId;

    /**
     * Product type
     * Example: vps
     * 
     * @var string
     */
    protected $type;

    /**
     * Getter for license
     *
     * @return string
     */
    public function getLicense(): string
    {
        return $this->license;
    }

    /**
     * Setter for license
     *
     * @param string $license
     * @return self
     */
    public function setLicense(string $license)
    {
        $this->license = $license;
        return $this;
    }

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string
    {
        return $this->hostName;
    }

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName)
    {
        $this->hostName = $hostName;
        return $this;
    }

    /**
     * Getter for appId
     *
     * @return string
     */
    public function getAppId(): string
    {
        return $this->appId;
    }

    /**
     * Setter for appId
     *
     * @param string $appId
     * @return self
     */
    public function setAppId(string $appId)
    {
        $this->appId = $appId;
        return $this;
    }

    /**
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param string $type
     * @return self
     */
    public function setType($type)
    {
        $this->type = $type;
        return $this;
    }

    /**
     * @param string $license
     * @param string $hostName
     * @param string $appId
     * @return void
     */
    public function __construct(string $license, string $hostName, string $appId, $type)
    {
        $this->license = $license;
        $this->hostName = $hostName;
        $this->appId = $appId;
        $this->type = $type;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
