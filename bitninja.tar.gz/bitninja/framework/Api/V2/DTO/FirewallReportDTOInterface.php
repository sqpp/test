<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface FirewallReportDTOInterface
{
    /**
     * Getter for captchaShown
     *
     * @return int
     */
    public function getCaptchaShown(): int;

    /**
     * Setter for captchaShown
     *
     * @param int $captchaShown
     * @return self
     */
    public function setCaptchaShown(int $captchaShown);

    /**
     * Getter for captchaSolved
     *
     * @return int
     */
    public function getCaptchaSolved(): int;

    /**
     * Setter for captchaSolved
     *
     * @param int $captchaSolved
     * @return self
     */
    public function setCaptchaSolved(int $captchaSolved);

    /**
     * Getter for connectionBlocked
     *
     * @return int
     */
    public function getConnectionBlocked(): int;

    /**
     * Setter for connectionBlocked
     *
     * @param int $connectionBlocked
     * @return self
     */
    public function setConnectionBlocked(int $connectionBlocked);
}
