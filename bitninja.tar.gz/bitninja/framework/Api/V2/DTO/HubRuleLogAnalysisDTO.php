<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class HubRuleLogAnalysisDTO implements HubRuleLogAnalysisDTOInterface, \JsonSerializable
{
    /**
     * Title of the rule
     * Example: Some awesome title
     *
     * @var string
     */
    protected $title;

    /**
     * The rule
     * Example: Fail2ban rule...
     *
     * @var string
     */
    protected $rule;

    /**
     * Rule description
     * Example: some content
     *
     * @var string
     */
    protected $description;

    /**
     * Getter for title
     *
     * @return string
     */
    public function getTitle(): string
    {
        return $this->title;
    }

    /**
     * Setter for title
     *
     * @param string $title
     * @return self
     */
    public function setTitle(string $title)
    {
        $this->title = $title;
        return $this;
    }

    /**
     * Getter for rule
     *
     * @return string
     */
    public function getRule(): string
    {
        return $this->rule;
    }

    /**
     * Setter for rule
     *
     * @param string $rule
     * @return self
     */
    public function setRule(string $rule)
    {
        $this->rule = $rule;
        return $this;
    }

    /**
     * Getter for description
     *
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * Setter for description
     *
     * @param string $description
     * @return self
     */
    public function setDescription(string $description)
    {
        $this->description = $description;
        return $this;
    }

    /**
     * @param string $title
     * @param string $rule
     * @param string $description
     * @return void
     */
    public function __construct(string $title, string $rule, string $description)
    {
        $this->title = $title;
        $this->rule = $rule;
        $this->description = $description;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
