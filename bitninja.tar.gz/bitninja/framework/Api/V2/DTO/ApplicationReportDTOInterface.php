<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface ApplicationReportDTOInterface
{
    /**
     * Getter for ruleId
     *
     * @return string
     */
    public function getRuleId(): string;

    /**
     * Setter for ruleId
     *
     * @param string $ruleId
     * @return self
     */
    public function setRuleId(string $ruleId);

    /**
     * Getter for application
     *
     * @return string
     */
    public function getApplication(): string;

    /**
     * Setter for application
     *
     * @param string $application
     * @return self
     */
    public function setApplication(string $application);

    /**
     * Getter for domain
     *
     * @return string
     */
    public function getDomain(): string;

    /**
     * Setter for domain
     *
     * @param string $domain
     * @return self
     */
    public function setDomain(string $domain);

    /**
     * Getter for documentRoot
     *
     * @return string
     */
    public function getDocumentRoot(): string;

    /**
     * Setter for documentRoot
     *
     * @param string $documentRoot
     * @return self
     */
    public function setDocumentRoot(string $documentRoot);
}
