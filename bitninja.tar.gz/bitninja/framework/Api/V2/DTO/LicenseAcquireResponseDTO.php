<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseAcquireResponseDTO implements LicenseAcquireResponseDTOInterface, \JsonSerializable
{
    /**
     * Server unique license key
     *
     * @var string
     */
    protected $license;

    /**
     * Getter for license
     *
     * @return string
     */
    public function getLicense(): string
    {
        return $this->license;
    }

    /**
     * Setter for license
     *
     * @param string $license
     * @return self
     */
    public function setLicense(string $license)
    {
        $this->license = $license;
        return $this;
    }

    /**
     * @param string $license
     * @return void
     */
    public function __construct(string $license)
    {
        $this->license = $license;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
