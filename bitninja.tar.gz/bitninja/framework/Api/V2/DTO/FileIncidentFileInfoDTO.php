<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class FileIncidentFileInfoDTO implements FileIncidentFileInfoDTOInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $directory;

    /**
     * @var string
     */
    protected $name;

    /**
     * @var int
     */
    protected $size;

    /**
     * @var string
     */
    protected $owner;

    /**
     * @var string
     */
    protected $group;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\DateInterface
     */
    protected $atime;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\DateInterface
     */
    protected $mtime;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\DateInterface
     */
    protected $ctime;

    /**
     * @var string
     */
    protected $permission;

    /**
     * @var string
     */
    protected $hash;

    /**
     * @var int
     */
    protected $uid;

    /**
     * @var int
     */
    protected $gid;

    /**
     * Getter for directory
     *
     * @return string
     */
    public function getDirectory(): string
    {
        return $this->directory;
    }

    /**
     * Setter for directory
     *
     * @param string $directory
     * @return self
     */
    public function setDirectory(string $directory)
    {
        $this->directory = $directory;
        return $this;
    }

    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * Getter for size
     *
     * @return int
     */
    public function getSize(): int
    {
        return $this->size;
    }

    /**
     * Setter for size
     *
     * @param int $size
     * @return self
     */
    public function setSize(int $size)
    {
        $this->size = $size;
        return $this;
    }

    /**
     * Getter for owner
     *
     * @return string
     */
    public function getOwner(): string
    {
        return $this->owner;
    }

    /**
     * Setter for owner
     *
     * @param string $owner
     * @return self
     */
    public function setOwner(string $owner)
    {
        $this->owner = $owner;
        return $this;
    }

    /**
     * Getter for group
     *
     * @return string
     */
    public function getGroup(): string
    {
        return $this->group;
    }

    /**
     * Setter for group
     *
     * @param string $group
     * @return self
     */
    public function setGroup(string $group)
    {
        $this->group = $group;
        return $this;
    }

    /**
     * Getter for atime
     *
     * @return BitNinja\Framework\Api\V2\DTO\DateInterface
     */
    public function getAtime(): DateInterface
    {
        return $this->atime;
    }

    /**
     * Setter for atime
     *
     * @param BitNinja\Framework\Api\V2\DTO\DateInterface $atime
     * @return self
     */
    public function setAtime(DateInterface $atime)
    {
        $this->atime = $atime;
        return $this;
    }

    /**
     * Getter for mtime
     *
     * @return BitNinja\Framework\Api\V2\DTO\DateInterface
     */
    public function getMtime(): DateInterface
    {
        return $this->mtime;
    }

    /**
     * Setter for mtime
     *
     * @param BitNinja\Framework\Api\V2\DTO\DateInterface $mtime
     * @return self
     */
    public function setMtime(DateInterface $mtime)
    {
        $this->mtime = $mtime;
        return $this;
    }

    /**
     * Getter for ctime
     *
     * @return BitNinja\Framework\Api\V2\DTO\DateInterface
     */
    public function getCtime(): DateInterface
    {
        return $this->ctime;
    }

    /**
     * Setter for ctime
     *
     * @param BitNinja\Framework\Api\V2\DTO\DateInterface $ctime
     * @return self
     */
    public function setCtime(DateInterface $ctime)
    {
        $this->ctime = $ctime;
        return $this;
    }

    /**
     * Getter for permission
     *
     * @return string
     */
    public function getPermission(): string
    {
        return $this->permission;
    }

    /**
     * Setter for permission
     *
     * @param string $permission
     * @return self
     */
    public function setPermission(string $permission)
    {
        $this->permission = $permission;
        return $this;
    }

    /**
     * Getter for hash
     *
     * @return string
     */
    public function getHash(): string
    {
        return $this->hash;
    }

    /**
     * Setter for hash
     *
     * @param string $hash
     * @return self
     */
    public function setHash(string $hash)
    {
        $this->hash = $hash;
        return $this;
    }

    /**
     * Getter for uid
     *
     * @return int
     */
    public function getUid(): int
    {
        return $this->uid;
    }

    /**
     * Setter for uid
     *
     * @param int $uid
     * @return self
     */
    public function setUid(int $uid)
    {
        $this->uid = $uid;
        return $this;
    }

    /**
     * Getter for gid
     *
     * @return int
     */
    public function getGid(): int
    {
        return $this->gid;
    }

    /**
     * Setter for gid
     *
     * @param int $gid
     * @return self
     */
    public function setGid(int $gid)
    {
        $this->gid = $gid;
        return $this;
    }

    /**
     * @param string $directory
     * @param string $name
     * @param int $size
     * @param string $owner
     * @param string $group
     * @param BitNinja\Framework\Api\V2\DTO\DateInterface $atime
     * @param BitNinja\Framework\Api\V2\DTO\DateInterface $mtime
     * @param BitNinja\Framework\Api\V2\DTO\DateInterface $ctime
     * @param string $permission
     * @param string $hash
     * @param int $uid
     * @param int $gid
     * @return void
     */
    public function __construct(
        string $directory,
        string $name,
        int $size,
        string $owner,
        string $group,
        DateInterface $atime,
        DateInterface $mtime,
        DateInterface $ctime,
        string $permission,
        string $hash,
        int $uid,
        int $gid
    ) {
        $this->directory = $directory;
        $this->name = $name;
        $this->size = $size;
        $this->owner = $owner;
        $this->group = $group;
        $this->atime = $atime;
        $this->mtime = $mtime;
        $this->ctime = $ctime;
        $this->permission = $permission;
        $this->hash = $hash;
        $this->uid = $uid;
        $this->gid = $gid;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
