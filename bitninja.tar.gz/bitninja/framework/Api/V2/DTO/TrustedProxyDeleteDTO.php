<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class TrustedProxyDeleteDTO implements TrustedProxyDeleteDTOInterface, \JsonSerializable
{
    /**
     * IP address or range. It can be ipv4 and ipv6 as well.
     * Example: 125.19.23.0/24
     *
     * @var string
     */
    protected $ip;

    /**
     * Getter for ip
     *
     * @return string
     */
    public function getIp(): string
    {
        return $this->ip;
    }

    /**
     * Setter for ip
     *
     * @param string $ip
     * @return self
     */
    public function setIp(string $ip)
    {
        $this->ip = $ip;
        return $this;
    }

    /**
     * @param string $ip
     * @return void
     */
    public function __construct(string $ip)
    {
        $this->ip = $ip;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
