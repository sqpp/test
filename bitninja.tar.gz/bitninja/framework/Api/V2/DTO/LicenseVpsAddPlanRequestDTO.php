<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseVpsAddPlanRequestDTO implements LicenseVpsAddPlanRequestDTOInterface, \JsonSerializable
{
    /**
     * Plan id
     *
     * @var int
     */
    protected $planId;

    /**
     * Getter for planId
     *
     * @return int
     */
    public function getPlanId(): int
    {
        return $this->planId;
    }

    /**
     * Setter for planId
     *
     * @param int $planId
     * @return self
     */
    public function setPlanId(int $planId)
    {
        $this->planId = $planId;
        return $this;
    }

    /**
     * @param int $planId
     * @return void
     */
    public function __construct(int $planId)
    {
        $this->planId = $planId;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
