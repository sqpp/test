<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface LicenseVpsSubscriptionResponseDTOInterface
{
    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int;

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id);

    /**
     * Getter for planId
     *
     * @return int
     */
    public function getPlanId(): int;

    /**
     * Setter for planId
     *
     * @param int $planId
     * @return self
     */
    public function setPlanId(int $planId);

    /**
     * Getter for status
     *
     * @return string
     */
    public function getStatus(): string;

    /**
     * Setter for status
     *
     * @param string $status
     * @return self
     */
    public function setStatus(string $status);

    /**
     * Getter for lastSuccessfulPayment
     *
     * @return string
     */
    public function getLastSuccessfulPayment();

    /**
     * Setter for lastSuccessfulPayment
     *
     * @param int $lastSuccessfulPayment
     * @return self
     */
    public function setLastSuccessfulPayment($lastSuccessfulPayment);

    /**
     * Getter for nextPaymentPeriod
     *
     * @return string
     */
    public function getNextPaymentPeriod();

    /**
     * Setter for nextPaymentPeriod
     *
     * @param int $nextPaymentPeriod
     * @return self
     */
    public function setNextPaymentPeriod($nextPaymentPeriod);

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt();

    /**
     * Setter for createdAt
     *
     * @param int $createdAt
     * @return self
     */
    public function setCreatedAt($createdAt);
}
