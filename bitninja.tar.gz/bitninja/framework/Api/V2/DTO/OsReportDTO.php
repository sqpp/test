<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class OsReportDTO implements OsReportDTOInterface, \JsonSerializable
{
    /**
     * @var BitNinja\Framework\Api\V2\DTO\OsInfoDTOInterface
     */
    protected $os;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\ServerInfoDTOInterface
     */
    protected $server;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\MemoryInfoDTOInterface
     */
    protected $memory;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\DiskInfoDTOInterface
     */
    protected $disk;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\CpuInfoDTOInterface
     */
    protected $cpu;

    /**
     * @var array
     */
    protected $networks;

    /**
     * @var object
     */
    protected $environment;

    /**
     * Getter for os
     *
     * @return BitNinja\Framework\Api\V2\DTO\OsInfoDTOInterface
     */
    public function getOs(): OsInfoDTOInterface
    {
        return $this->os;
    }

    /**
     * Setter for os
     *
     * @param BitNinja\Framework\Api\V2\DTO\OsInfoDTOInterface $os
     * @return self
     */
    public function setOs(OsInfoDTOInterface $os)
    {
        $this->os = $os;
        return $this;
    }

    /**
     * Getter for server
     *
     * @return BitNinja\Framework\Api\V2\DTO\ServerInfoDTOInterface
     */
    public function getServer(): ServerInfoDTOInterface
    {
        return $this->server;
    }

    /**
     * Setter for server
     *
     * @param BitNinja\Framework\Api\V2\DTO\ServerInfoDTOInterface $server
     * @return self
     */
    public function setServer(ServerInfoDTOInterface $server)
    {
        $this->server = $server;
        return $this;
    }

    /**
     * Getter for memory
     *
     * @return BitNinja\Framework\Api\V2\DTO\MemoryInfoDTOInterface
     */
    public function getMemory(): MemoryInfoDTOInterface
    {
        return $this->memory;
    }

    /**
     * Setter for memory
     *
     * @param BitNinja\Framework\Api\V2\DTO\MemoryInfoDTOInterface $memory
     * @return self
     */
    public function setMemory(MemoryInfoDTOInterface $memory)
    {
        $this->memory = $memory;
        return $this;
    }

    /**
     * Getter for disk
     *
     * @return BitNinja\Framework\Api\V2\DTO\DiskInfoDTOInterface
     */
    public function getDisk(): DiskInfoDTOInterface
    {
        return $this->disk;
    }

    /**
     * Setter for disk
     *
     * @param BitNinja\Framework\Api\V2\DTO\DiskInfoDTOInterface $disk
     * @return self
     */
    public function setDisk(DiskInfoDTOInterface $disk)
    {
        $this->disk = $disk;
        return $this;
    }

    /**
     * Getter for cpu
     *
     * @return BitNinja\Framework\Api\V2\DTO\CpuInfoDTOInterface
     */
    public function getCpu(): CpuInfoDTOInterface
    {
        return $this->cpu;
    }

    /**
     * Setter for cpu
     *
     * @param BitNinja\Framework\Api\V2\DTO\CpuInfoDTOInterface $cpu
     * @return self
     */
    public function setCpu(CpuInfoDTOInterface $cpu)
    {
        $this->cpu = $cpu;
        return $this;
    }

    /**
     * Getter for networks
     *
     * @return array
     */
    public function getNetworks(): array
    {
        return $this->networks;
    }

    /**
     * Setter for networks
     *
     * @param array $networks
     * @return self
     */
    public function setNetworks(array $networks)
    {
        $this->networks = $networks;
        return $this;
    }

    /**
     * Getter for environment
     *
     * @return object
     */
    public function getEnvironment(): object
    {
        return $this->environment;
    }

    /**
     * Setter for environment
     *
     * @param object $environment
     * @return self
     */
    public function setEnvironment(object $environment)
    {
        $this->environment = $environment;
        return $this;
    }

    /**
     * @param BitNinja\Framework\Api\V2\DTO\OsInfoDTOInterface $os
     * @param BitNinja\Framework\Api\V2\DTO\ServerInfoDTOInterface $server
     * @param BitNinja\Framework\Api\V2\DTO\MemoryInfoDTOInterface $memory
     * @param BitNinja\Framework\Api\V2\DTO\DiskInfoDTOInterface $disk
     * @param BitNinja\Framework\Api\V2\DTO\CpuInfoDTOInterface $cpu
     * @param array $networks
     * @param object $environment
     * @return void
     */
    public function __construct(
        OsInfoDTOInterface $os,
        ServerInfoDTOInterface $server,
        MemoryInfoDTOInterface $memory,
        DiskInfoDTOInterface $disk,
        CpuInfoDTOInterface $cpu,
        array $networks,
        object $environment
    ) {
        $this->os = $os;
        $this->server = $server;
        $this->memory = $memory;
        $this->disk = $disk;
        $this->cpu = $cpu;
        $this->networks = $networks;
        $this->environment = $environment;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
