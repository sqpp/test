<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface HubRuleLogAnalysisDTOInterface
{
    /**
     * Getter for title
     *
     * @return string
     */
    public function getTitle(): string;

    /**
     * Setter for title
     *
     * @param string $title
     * @return self
     */
    public function setTitle(string $title);

    /**
     * Getter for rule
     *
     * @return string
     */
    public function getRule(): string;

    /**
     * Setter for rule
     *
     * @param string $rule
     * @return self
     */
    public function setRule(string $rule);

    /**
     * Getter for description
     *
     * @return string
     */
    public function getDescription(): string;

    /**
     * Setter for description
     *
     * @param string $description
     * @return self
     */
    public function setDescription(string $description);
}
