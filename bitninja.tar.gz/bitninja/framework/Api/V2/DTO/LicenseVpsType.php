<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseVpsType implements LicenseVpsTypeInterface, \JsonSerializable
{
    /**
     * Unique ID of the subscription
     * Example: 28385
     *
     * @var int
     */
    protected $id;

    /**
     * Name of the subscription plan
     * Example: VPS-50
     *
     * @var string
     */
    protected $name;

    /**
     * Number of licenses
     * Example: 50
     *
     * @var int
     */
    protected $size;

    /**
     *
     * @var string
     */
    protected $nextPayment;

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * Getter for size
     *
     * @return int
     */
    public function getSize(): int
    {
        return $this->size;
    }

    /**
     * Setter for size
     *
     * @param int $size
     * @return self
     */
    public function setSize(int $size)
    {
        $this->size = $size;
        return $this;
    }

    /**
     * Getter for nextPayment
     *
     * @return string
     */
    public function getNextPayment()
    {
        return $this->nextPayment;
    }

    /**
     * Setter for nextPayment
     *
     * @param int $nextPayment
     * @return self
     */
    public function setNextPayment($nextPayment)
    {
        $this->nextPayment = $nextPayment;
        return $this;
    }

    /**
     * @param int $id
     * @param string $name
     * @param int $size
     * @return void
     */
    public function __construct(int $id, string $name, int $size, $nextPayment)
    {
        $this->id = $id;
        $this->name = $name;
        $this->size = $size;
        $this->nextPayment = $nextPayment;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
