<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class MemoryInfoDTO implements MemoryInfoDTOInterface, \JsonSerializable
{
    /**
     * @var int
     */
    protected $total;

    /**
     * @var int
     */
    protected $used;

    /**
     * @var int
     */
    protected $free;

    /**
     * @var int
     */
    protected $shared;

    /**
     * @var int
     */
    protected $available;

    /**
     * Getter for total
     *
     * @return int
     */
    public function getTotal(): int
    {
        return $this->total;
    }

    /**
     * Setter for total
     *
     * @param int $total
     * @return self
     */
    public function setTotal(int $total)
    {
        $this->total = $total;
        return $this;
    }

    /**
     * Getter for used
     *
     * @return int
     */
    public function getUsed(): int
    {
        return $this->used;
    }

    /**
     * Setter for used
     *
     * @param int $used
     * @return self
     */
    public function setUsed(int $used)
    {
        $this->used = $used;
        return $this;
    }

    /**
     * Getter for free
     *
     * @return int
     */
    public function getFree(): int
    {
        return $this->free;
    }

    /**
     * Setter for free
     *
     * @param int $free
     * @return self
     */
    public function setFree(int $free)
    {
        $this->free = $free;
        return $this;
    }

    /**
     * Getter for shared
     *
     * @return int
     */
    public function getShared(): int
    {
        return $this->shared;
    }

    /**
     * Setter for shared
     *
     * @param int $shared
     * @return self
     */
    public function setShared(int $shared)
    {
        $this->shared = $shared;
        return $this;
    }

    /**
     * Getter for available
     *
     * @return int
     */
    public function getAvailable(): int
    {
        return $this->available;
    }

    /**
     * Setter for available
     *
     * @param int $available
     * @return self
     */
    public function setAvailable(int $available)
    {
        $this->available = $available;
        return $this;
    }

    /**
     * @param int $total
     * @param int $used
     * @param int $free
     * @param int $shared
     * @param int $available
     * @return void
     */
    public function __construct(int $total, int $used, int $free, int $shared, int $available)
    {
        $this->total = $total;
        $this->used = $used;
        $this->free = $free;
        $this->shared = $shared;
        $this->available = $available;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
