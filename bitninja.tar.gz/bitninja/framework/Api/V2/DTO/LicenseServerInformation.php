<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseServerInformation implements LicenseServerInformationInterface, \JsonSerializable
{
    /**
     * Server Id
     * Example: 765
     *
     * @var int
     */
    protected $id;

    /**
     * Name of the server
     * Example: my-vps.bitninja.io
     *
     * @var string
     */
    protected $displayName;

    /**
     * Identifier added by user
     * Example: My first VPS server
     *
     * @var string
     */
    protected $remoteId;

    /**
     * @var string
     */
    protected $lastActive;

    /**
     * Is server deleted?
     *
     * @var boolean
     */
    protected $deleted;

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for displayName
     *
     * @return string
     */
    public function getDisplayName(): string
    {
        return $this->displayName;
    }

    /**
     * Setter for displayName
     *
     * @param string $displayName
     * @return self
     */
    public function setDisplayName(string $displayName)
    {
        $this->displayName = $displayName;
        return $this;
    }

    /**
     * Getter for remoteId
     *
     * @return string
     */
    public function getRemoteId(): string
    {
        return $this->remoteId;
    }

    /**
     * Setter for remoteId
     *
     * @param string $remoteId
     * @return self
     */
    public function setRemoteId(string $remoteId)
    {
        $this->remoteId = $remoteId;
        return $this;
    }

    /**
     * Getter for lastActive
     *
     * @return string
     */
    public function getLastActive()
    {
        return $this->lastActive;
    }

    /**
     * Setter for lastActive
     *
     * @param string $lastActive
     * @return self
     */
    public function setLastActive($lastActive)
    {
        $this->lastActive = $lastActive;
        return $this;
    }

    /**
     * Getter for deleted
     *
     * @return boolean
     */
    public function getDeleted(): bool
    {
        return $this->deleted;
    }

    /**
     * Setter for deleted
     *
     * @param boolean $deleted
     * @return self
     */
    public function setDeleted(bool $deleted)
    {
        $this->deleted = $deleted;
        return $this;
    }

    /**
     * @param int $id
     * @param string $displayName
     * @param string $remoteId
     * @param boolean $deleted
     * @return void
     */
    public function __construct(int $id, string $displayName, string $remoteId, $lastActive, \boolean $deleted)
    {
        $this->id = $id;
        $this->displayName = $displayName;
        $this->remoteId = $remoteId;
        $this->lastActive = $lastActive;
        $this->deleted = $deleted;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
