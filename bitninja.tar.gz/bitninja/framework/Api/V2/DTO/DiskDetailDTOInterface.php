<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface DiskDetailDTOInterface
{
    /**
     * Getter for mountedOn
     *
     * @return string
     */
    public function getMountedOn(): string;

    /**
     * Setter for mountedOn
     *
     * @param string $mountedOn
     * @return self
     */
    public function setMountedOn(string $mountedOn);

    /**
     * Getter for sizeTotal
     *
     * @return int
     */
    public function getSizeTotal(): int;

    /**
     * Setter for sizeTotal
     *
     * @param int $sizeTotal
     * @return self
     */
    public function setSizeTotal(int $sizeTotal);

    /**
     * Getter for sizeUsed
     *
     * @return int
     */
    public function getSizeUsed(): int;

    /**
     * Setter for sizeUsed
     *
     * @param int $sizeUsed
     * @return self
     */
    public function setSizeUsed(int $sizeUsed);
}
