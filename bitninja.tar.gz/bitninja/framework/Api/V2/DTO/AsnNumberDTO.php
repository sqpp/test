<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class AsnNumberDTO implements AsnNumberDTOInterface, \JsonSerializable
{
    /**
     * @var array
     */
    protected $asnNumbers;

    /**
     * Getter for asnNumbers
     *
     * @return array
     */
    public function getAsnNumbers(): array
    {
        return $this->asnNumbers;
    }

    /**
     * Setter for asnNumbers
     *
     * @param array $asnNumbers
     * @return self
     */
    public function setAsnNumbers(array $asnNumbers)
    {
        $this->asnNumbers = $asnNumbers;
        return $this;
    }

    /**
     * @param array $asnNumbers
     */
    public function __construct(array $asnNumbers)
    {
        $this->asnNumbers = $asnNumbers;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
