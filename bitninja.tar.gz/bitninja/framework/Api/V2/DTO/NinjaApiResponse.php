<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class NinjaApiResponse implements NinjaApiResponseInterface, \JsonSerializable
{
    /**
     * Has the operation been successful?
     * Example: 1
     *
     * @var boolean
     */
    protected $status;

    /**
     * Detailed output of the operation
     * Example: Operation successful!
     *
     * @var object
     */
    protected $message;

    /**
     * Unique identifier for the operation.
     * Example: 13
     *
     * @var object
     */
    protected $id;

    /**
     * Getter for status
     *
     * @return boolean
     */
    public function getStatus(): \boolean
    {
        return $this->status;
    }

    /**
     * Setter for status
     *
     * @param boolean $status
     * @return self
     */
    public function setStatus(\boolean $status)
    {
        $this->status = $status;
        return $this;
    }

    /**
     * Getter for message
     *
     * @return object
     */
    public function getMessage(): object
    {
        return $this->message;
    }

    /**
     * Setter for message
     *
     * @param object $message
     * @return self
     */
    public function setMessage(object $message)
    {
        $this->message = $message;
        return $this;
    }

    /**
     * Getter for id
     *
     * @return object
     */
    public function getId(): object
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param object $id
     * @return self
     */
    public function setId(object $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * @param boolean $status
     * @param object $message
     * @return void
     */
    public function __construct(\boolean $status, object $message)
    {
        $this->status = $status;
        $this->message = $message;
    }


    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
