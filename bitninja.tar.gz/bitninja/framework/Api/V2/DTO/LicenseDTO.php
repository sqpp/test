<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseDTO implements LicenseDTOInterface, \JsonSerializable
{
    /**
     * License key
     * Example: AAAABBBBCCC
     *
     * @var string
     */
    protected $licenseKey;

    /**
     * Getter for licenseKey
     *
     * @return string
     */
    public function getLicenseKey(): string
    {
        return $this->licenseKey;
    }

    /**
     * Setter for licenseKey
     *
     * @param string $licenseKey
     * @return self
     */
    public function setLicenseKey(string $licenseKey)
    {
        $this->licenseKey = $licenseKey;
        return $this;
    }

    /**
     * @param string $licenseKey
     * @return void
     */
    public function __construct(string $licenseKey)
    {
        $this->licenseKey = $licenseKey;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
