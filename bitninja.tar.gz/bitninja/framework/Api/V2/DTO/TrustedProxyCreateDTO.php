<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class TrustedProxyCreateDTO implements TrustedProxyCreateDTOInterface, \JsonSerializable
{
    /**
     * IP address or range. It can be ipv4 and ipv6 as well.
     * Example: 125.19.23.0/24
     *
     * @var string
     */
    protected $ip;

    /**
     * Custom comment for the IP range
     * Example: Internal company proxy range.
     *
     * @var string
     */
    protected $comment;

    /**
     * Getter for ip
     *
     * @return string
     */
    public function getIp(): string
    {
        return $this->ip;
    }

    /**
     * Setter for ip
     *
     * @param string $ip
     * @return self
     */
    public function setIp(string $ip)
    {
        $this->ip = $ip;
        return $this;
    }

    /**
     * Getter for comment
     *
     * @return string
     */
    public function getComment(): string
    {
        return $this->comment;
    }

    /**
     * Setter for comment
     *
     * @param string $comment
     * @return self
     */
    public function setComment(string $comment)
    {
        $this->comment = $comment;
        return $this;
    }

    /**
     * @param string $ip
     * @param string $comment
     * @return void
     */
    public function __construct(string $ip, string $comment)
    {
        $this->ip = $ip;
        $this->comment = $comment;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
