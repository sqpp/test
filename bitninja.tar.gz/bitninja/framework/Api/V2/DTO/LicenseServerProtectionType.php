<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseServerProtectionType implements LicenseServerProtectionTypeInterface, \JsonSerializable
{
    /**
     * Subscription ID
     *
     * @var int
     */
    protected $id;

    /**
     * Name of the subscription plan
     * Example: pro
     *
     * @var string
     */
    protected $name;

    /**
     * Subscription status
     *
     * @var string
     */
    protected $status;

    /**
     * Number of users on the server
     * Example: 50
     *
     * @var int
     */
    protected $users;

    /**
     * @var string
     */
    protected $nextPayment;

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * Getter for status
     *
     * @return string
     */
    public function getStatus(): string
    {
        return $this->status;
    }

    /**
     * Setter for status
     *
     * @param string $status
     * @return self
     */
    public function setStatus(string $status)
    {
        $this->status = $status;
        return $this;
    }

    /**
     * Getter for users
     *
     * @return int
     */
    public function getUsers(): int
    {
        return $this->users;
    }

    /**
     * Setter for users
     *
     * @param int $users
     * @return self
     */
    public function setUsers(int $users)
    {
        $this->users = $users;
        return $this;
    }

    /**
     * Getter for nextPayment
     *
     * @return string
     */
    public function getNextPayment()
    {
        return $this->nextPayment;
    }

    /**
     * Setter for nextPayment
     *
     * @param string $nextPayment
     * @return self
     */
    public function setNextPayment($nextPayment)
    {
        $this->nextPayment = $nextPayment;
        return $this;
    }

    /**
     * @param int $id
     * @param string $name
     * @param string $status
     * @param int $users
     * @return void
     */
    public function __construct(int $id, string $name, string $status, int $users, $nextPayment)
    {
        $this->id = $id;
        $this->name = $name;
        $this->status = $status;
        $this->users = $users;
        $this->nextPayment = $nextPayment;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
