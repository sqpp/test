<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseVpsSubscriptionCancelRequestDTO implements LicenseVpsSubscriptionCancelRequestDTOInterface, \JsonSerializable
{
    /**
     * Subscription ID
     *
     * @var int
     */
    protected $subscriptionId;

    /**
     * Getter for subscriptionId
     *
     * @return int
     */
    public function getSubscriptionId(): int
    {
        return $this->subscriptionId;
    }

    /**
     * Setter for subscriptionId
     *
     * @param int $subscriptionId
     * @return self
     */
    public function setSubscriptionId(int $subscriptionId)
    {
        $this->subscriptionId = $subscriptionId;
        return $this;
    }

    /**
     * @param int $subscriptionId
     * @return void
     */
    public function __construct(int $subscriptionId)
    {
        $this->subscriptionId = $subscriptionId;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
