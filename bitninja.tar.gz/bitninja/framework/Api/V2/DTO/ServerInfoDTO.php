<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class ServerInfoDTO implements ServerInfoDTOInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $hostName;

    /**
     * @var string
     */
    protected $time;

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string
    {
        return $this->hostName;
    }

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName)
    {
        $this->hostName = $hostName;
        return $this;
    }

    /**
     * Getter for time
     *
     * @return string
     */
    public function getTime(): string
    {
        return $this->time;
    }

    /**
     * Setter for time
     *
     * @param string $time
     * @return self
     */
    public function setTime(string $time)
    {
        $this->time = $time;
        return $this;
    }

    /**
     * @param string $hostName
     * @param string $time
     * @return void
     */
    public function __construct(string $hostName, string $time)
    {
        $this->hostName = $hostName;
        $this->time = $time;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
