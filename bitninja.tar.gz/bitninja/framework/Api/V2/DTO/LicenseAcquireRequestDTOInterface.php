<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface LicenseAcquireRequestDTOInterface
{
    /**
     * Getter for provisionKey
     *
     * @return string
     */
    public function getProvisionKey(): string;

    /**
     * Setter for provisionKey
     *
     * @param string $provisionKey
     * @return self
     */
    public function setProvisionKey(string $provisionKey);

    /**
     * Getter for type
     *
     * @return string
     */
    public function getType(): string;

    /**
     * Setter for type
     *
     * @param string $type
     * @return self
     */
    public function setType(string $type);

    /**
     * Getter for appId
     *
     * @return string
     */
    public function getAppId(): string;

    /**
     * Setter for appId
     *
     * @param string $appId
     * @return self
     */
    public function setAppId(string $appId);

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string;

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName);
}
