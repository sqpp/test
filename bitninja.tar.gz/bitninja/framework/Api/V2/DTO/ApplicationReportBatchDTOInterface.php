<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface ApplicationReportBatchDTOInterface
{
    /**
     * Getter for commandId
     *
     * @return string
     */
    public function getCommandId(): string;

    /**
     * Setter for commandId
     *
     * @param string $commandId
     * @return self
     */
    public function setCommandId(string $commandId);

    /**
     * Getter for agentVersion
     *
     * @return string
     */
    public function getAgentVersion(): string;

    /**
     * Setter for agentVersion
     *
     * @param string $agentVersion
     * @return self
     */
    public function setAgentVersion(string $agentVersion);

    /**
     * Getter for applications
     *
     * @return array
     */
    public function getApplications(): array;

    /**
     * Setter for applications
     *
     * @param array $applications
     * @return self
     */
    public function setApplications(array $applications);
}
