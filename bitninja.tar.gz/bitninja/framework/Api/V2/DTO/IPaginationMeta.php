<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class IPaginationMeta implements IPaginationMetaInterface, \JsonSerializable
{
    protected $page;

    /**
     * Available records
     *
     * @var int
     */
    protected $records;

    public function getPage()
    {
        return $this->page;
    }

    public function setPage($page)
    {
        $this->page = $page;
        return $this;
    }

    /**
     * Getter for records
     *
     * @return int
     */
    public function getRecords(): int
    {
        return $this->records;
    }

    /**
     * Setter for records
     *
     * @param int $records
     * @return self
     */
    public function setRecords(int $records)
    {
        $this->records = $records;
        return $this;
    }

    /**
     * @param int $records
     * @return void
     */
    public function __construct($page, int $records)
    {
        $this->page = $page;
        $this->records = $records;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
