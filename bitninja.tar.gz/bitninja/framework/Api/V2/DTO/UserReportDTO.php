<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class UserReportDTO implements UserReportDTOInterface, \JsonSerializable
{
    /**
     * local user name on server
     * Example: localUser
     *
     * @var string
     */
    protected $name;

    /**
     * User id on server
     * Example: 1001
     *
     * @var int
     */
    protected $uid;

    /**
     * home directory of local user
     * Example: /home/localUser
     *
     * @var string
     */
    protected $home;

    /**
     * Getter for name
     *
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Setter for name
     *
     * @param string $name
     * @return self
     */
    public function setName(string $name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * Getter for uid
     *
     * @return int
     */
    public function getUid(): int
    {
        return $this->uid;
    }

    /**
     * Setter for uid
     *
     * @param int $uid
     * @return self
     */
    public function setUid(int $uid)
    {
        $this->uid = $uid;
        return $this;
    }

    /**
     * Getter for home
     *
     * @return string
     */
    public function getHome(): string
    {
        return $this->home;
    }

    /**
     * Setter for home
     *
     * @param string $home
     * @return self
     */
    public function setHome(string $home)
    {
        $this->home = $home;
        return $this;
    }

    /**
     * @param string $name
     * @param int $uid
     * @param string $home
     * @return void
     */
    public function __construct(string $name, int $uid, string $home)
    {
        $this->name = $name;
        $this->uid = $uid;
        $this->home = $home;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
