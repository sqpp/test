<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseVpsSubscriptionResponseDTO implements LicenseVpsSubscriptionResponseDTOInterface, \JsonSerializable
{
    /**
     * Subscription id
     *
     * @var int
     */
    protected $id;

    /**
     * Plan ID
     *
     * @var int
     */
    protected $planId;

    /**
     * wtf
     *
     * @var string
     */
    protected $status;

    /**
     * @var string
     */
    protected $lastSuccessfulPayment;

    /**
     * @var string
     */
    protected $nextPaymentPeriod;

    /**
     * @var string
     */
    protected $createdAt;

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for planId
     *
     * @return int
     */
    public function getPlanId(): int
    {
        return $this->planId;
    }

    /**
     * Setter for planId
     *
     * @param int $planId
     * @return self
     */
    public function setPlanId(int $planId)
    {
        $this->planId = $planId;
        return $this;
    }

    /**
     * Getter for status
     *
     * @return string
     */
    public function getStatus(): string
    {
        return $this->status;
    }

    /**
     * Setter for status
     *
     * @param string $status
     * @return self
     */
    public function setStatus(string $status)
    {
        $this->status = $status;
        return $this;
    }

    /**
     * Getter for lastSuccessfulPayment
     *
     * @return string
     */
    public function getLastSuccessfulPayment()
    {
        return $this->lastSuccessfulPayment;
    }

    /**
     * Setter for lastSuccessfulPayment
     *
     * @param string $lastSuccessfulPayment
     * @return self
     */
    public function setLastSuccessfulPayment($lastSuccessfulPayment)
    {
        $this->lastSuccessfulPayment = $lastSuccessfulPayment;
        return $this;
    }

    /**
     * Getter for nextPaymentPeriod
     *
     * @return string
     */
    public function getNextPaymentPeriod()
    {
        return $this->nextPaymentPeriod;
    }

    /**
     * Setter for nextPaymentPeriod
     *
     * @param string $nextPaymentPeriod
     * @return self
     */
    public function setNextPaymentPeriod($nextPaymentPeriod)
    {
        $this->nextPaymentPeriod = $nextPaymentPeriod;
        return $this;
    }

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Setter for stcreatedAtatus
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * @param int $id
     * @param int $planId
     * @param string $status
     * @return void
     */
    public function __construct(int $id, int $planId, string $status, $lastSuccessfulPayment, $nextPaymentPeriod, $createdAt)
    {
        $this->id = $id;
        $this->planId = $planId;
        $this->status = $status;
        $this->lastSuccessfulPayment = $lastSuccessfulPayment;
        $this->nextPaymentPeriod = $nextPaymentPeriod;
        $this->createdAt = $createdAt;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
