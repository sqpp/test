<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface IPaginationPageMetaInterface
{
    /**
     * Getter for size
     *
     * @return int
     */
    public function getSize(): int;

    /**
     * Setter for size
     *
     * @param int $size
     * @return self
     */
    public function setSize(int $size);

    /**
     * Getter for current
     *
     * @return int
     */
    public function getCurrent(): int;

    /**
     * Setter for current
     *
     * @param int $current
     * @return self
     */
    public function setCurrent(int $current);

    /**
     * Getter for total
     *
     * @return int
     */
    public function getTotal(): int;

    /**
     * Setter for total
     *
     * @param int $total
     * @return self
     */
    public function setTotal(int $total);
}
