<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface ServerResponseDTOInterface
{
    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int;

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id);

    /**
     * Getter for userId
     *
     * @return int
     */
    public function getUserId(): int;

    /**
     * Setter for userId
     *
     * @param int $userId
     * @return self
     */
    public function setUserId(int $userId);

    /**
     * Getter for agentVersion
     *
     * @return string
     */
    public function getAgentVersion(): string;

    /**
     * Setter for agentVersion
     *
     * @param string $agentVersion
     * @return self
     */
    public function setAgentVersion(string $agentVersion);

    /**
     * Getter for agentStatus
     *
     * @return string
     */
    public function getAgentStatus(): string;

    /**
     * Setter for agentStatus
     *
     * @param string $agentStatus
     * @return self
     */
    public function setAgentStatus(string $agentStatus);

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string;

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName);

    /**
     * Getter for remoteId
     *
     * @return string
     */
    public function getRemoteId(): string;

    /**
     * Setter for remoteId
     *
     * @param string $remoteId
     * @return self
     */
    public function setRemoteId(string $remoteId);

    /**
     * Getter for displayName
     *
     * @return string
     */
    public function getDisplayName(): string;

    /**
     * Setter for displayName
     *
     * @param string $displayName
     * @return self
     */
    public function setDisplayName(string $displayName);

    /**
     * Getter for systemLoad1
     *
     * @return int
     */
    public function getSystemLoad1(): int;

    /**
     * Setter for systemLoad1
     *
     * @param int $systemLoad1
     * @return self
     */
    public function setSystemLoad1(int $systemLoad1);

    /**
     * Getter for systemLoad5
     *
     * @return int
     */
    public function getSystemLoad5(): int;

    /**
     * Setter for systemLoad5
     *
     * @param int $systemLoad5
     * @return self
     */
    public function setSystemLoad5(int $systemLoad5);

    /**
     * Getter for systemLoad15
     *
     * @return int
     */
    public function getSystemLoad15(): int;

    /**
     * Setter for systemLoad15
     *
     * @param int $systemLoad15
     * @return self
     */
    public function setSystemLoad15(int $systemLoad15);

    /**
     * Getter for ipReputationSize
     *
     * @return int
     */
    public function getIpReputationSize(): int;

    /**
     * Setter for ipReputationSize
     *
     * @param int $ipReputationSize
     * @return self
     */
    public function setIpReputationSize(int $ipReputationSize);

    /**
     * Getter for systemUsers
     *
     * @return int
     */
    public function getSystemUsers(): int;

    /**
     * Setter for systemUsers
     *
     * @param int $systemUsers
     * @return self
     */
    public function setSystemUsers(int $systemUsers);

    /**
     * Getter for normalUsers
     *
     * @return int
     */
    public function getNormalUsers(): int;

    /**
     * Setter for normalUsers
     *
     * @param int $normalUsers
     * @return self
     */
    public function setNormalUsers(int $normalUsers);

    /**
     * Getter for publicIp
     *
     * @return string
     */
    public function getPublicIp(): string;

    /**
     * Setter for publicIp
     *
     * @param string $publicIp
     * @return self
     */
    public function setPublicIp(string $publicIp);

    /**
     * Getter for emailData
     *
     * @return string
     */
    public function getEmailData(): string;

    /**
     * Setter for emailData
     *
     * @param string $emailData
     * @return self
     */
    public function setEmailData(string $emailData);

    /**
     * Getter for actionSec
     *
     * @return int
     */
    public function getActionSec(): int;

    /**
     * Setter for actionSec
     *
     * @param int $actionSec
     * @return self
     */
    public function setActionSec(int $actionSec);

    /**
     * Getter for osInfo
     *
     * @return string
     */
    public function getOsInfo(): string;

    /**
     * Setter for osInfo
     *
     * @param string $osInfo
     * @return self
     */
    public function setOsInfo(string $osInfo);

    /**
     * Getter for nicInfo
     *
     * @return string
     */
    public function getNicInfo(): string;

    /**
     * Setter for nicInfo
     *
     * @param string $nicInfo
     * @return self
     */
    public function setNicInfo(string $nicInfo);

    /**
     * Getter for deleted
     *
     * @return int
     */
    public function getDeleted(): int;

    /**
     * Setter for deleted
     *
     * @param int $deleted
     * @return self
     */
    public function setDeleted(int $deleted);

    /**
     * Getter for licenseId
     *
     * @return int
     */
    public function getLicenseId(): int;

    /**
     * Setter for licenseId
     *
     * @param int $licenseId
     * @return self
     */
    public function setLicenseId(int $licenseId);

    /**
     * Getter for trustPoints
     *
     * @return int
     */
    public function getTrustPoints(): int;

    /**
     * Setter for trustPoints
     *
     * @param int $trustPoints
     * @return self
     */
    public function setTrustPoints(int $trustPoints);

    /**
     * Getter for ptr
     *
     * @return string
     */
    public function getPtr(): string;

    /**
     * Setter for ptr
     *
     * @param string $ptr
     * @return self
     */
    public function setPtr(string $ptr);

    /**
     * Getter for getLastScan
     *
     * @return string
     */
    public function getLastScan();

    /**
     * Setter for lastScan
     *
     * @param int $lastScan
     * @return self
     */
    public function setLastScan($lastScan);

    /**
     * Getter for instanceId
     *
     * @return string
     */
    public function getInstanceId(): string;

    /**
     * Setter for instanceId
     *
     * @param string $instanceId
     * @return self
     */
    public function setInstanceId(string $instanceId);

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt(): string;

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt(string $createdAt);

    /**
     * Getter for updatedAt
     *
     * @return string
     */
    public function getUpdatedAt(): string;

    /**
     * Setter for updatedAt
     *
     * @param string $updatedAt
     * @return self
     */
    public function setUpdatedAt(string $updatedAt);
}
