<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface NetworkAddressDTOInterface
{
    /**
     * Getter for ipVersion
     *
     * @return int
     */
    public function getIpVersion(): int;

    /**
     * Setter for ipVersion
     *
     * @param int $ipVersion
     * @return self
     */
    public function setIpVersion(int $ipVersion);

    /**
     * Getter for ipAddress
     *
     * @return string
     */
    public function getIpAddress(): string;

    /**
     * Setter for ipAddress
     *
     * @param string $ipAddress
     * @return self
     */
    public function setIpAddress(string $ipAddress);

    /**
     * Getter for broadcastAddress
     *
     * @return string
     */
    public function getBroadcastAddress(): string;

    /**
     * Setter for broadcastAddress
     *
     * @param string $broadcastAddress
     * @return self
     */
    public function setBroadcastAddress(string $broadcastAddress);

    /**
     * Getter for netmaskAddress
     *
     * @return string
     */
    public function getNetmaskAddress(): string;

    /**
     * Setter for netmaskAddress
     *
     * @param string $netmaskAddress
     * @return self
     */
    public function setNetmaskAddress(string $netmaskAddress);
}
