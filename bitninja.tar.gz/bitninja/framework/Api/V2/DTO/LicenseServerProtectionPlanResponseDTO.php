<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseServerProtectionPlanResponseDTO implements LicenseServerProtectionPlanResponseDTOInterface, \JsonSerializable
{
    /**
     * Plan id
     *
     * @var int
     */
    protected $id;

    /**
     * Plan description
     *
     * @var string
     */
    protected $description;

    /**
     * Plan name
     *
     * @var string
     */
    protected $displayName;

    /**
     * Plan price
     *
     * @var int
     */
    protected $price;

    /**
     * Getter for id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Setter for id
     *
     * @param int $id
     * @return self
     */
    public function setId(int $id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Getter for description
     *
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * Setter for description
     *
     * @param string $description
     * @return self
     */
    public function setDescription(string $description)
    {
        $this->description = $description;
        return $this;
    }

    /**
     * Getter for displayName
     *
     * @return string
     */
    public function getDisplayName(): string
    {
        return $this->displayName;
    }

    /**
     * Setter for displayName
     *
     * @param string $displayName
     * @return self
     */
    public function setDisplayName(string $displayName)
    {
        $this->displayName = $displayName;
        return $this;
    }

    /**
     * Getter for price
     *
     * @return int
     */
    public function getPrice(): int
    {
        return $this->price;
    }

    /**
     * Setter for price
     *
     * @param int $price
     * @return self
     */
    public function setPrice(int $price)
    {
        $this->price = $price;
        return $this;
    }

    /**
     * @param int $id
     * @param string $description
     * @param string $displayName
     * @param int $price
     * @return void
     */
    public function __construct(int $id, string $description, string $displayName, int $price)
    {
        $this->id = $id;
        $this->description = $description;
        $this->displayName = $displayName;
        $this->price = $price;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
