<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface VhostReportRequestDTOInterface
{
    /**
     * Getter for vhosts
     *
     * @return array
     */
    public function getVhosts(): array;

    /**
     * Setter for vhosts
     *
     * @param array $vhosts
     * @return self
     */
    public function setVhosts(array $vhosts);
}
