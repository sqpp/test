<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class CpanelLoginDTO implements CpanelLoginDTOInterface, \JsonSerializable
{
    /**
     * Local user name
     * Example: bntest
     *
     * @var string
     */
    protected $userName;

    /**
     * Email address
     * Example: me@company.com
     *
     * @var string
     */
    protected $emailAddress;

    /**
     * Server identifier
     * Example: 34
     *
     * @var int
     */
    protected $serverId;

    /**
     * User's domains on the server
     *
     * @var array
     */
    protected $domains;

    /**
     * Getter for userName
     *
     * @return string
     */
    public function getUserName(): string
    {
        return $this->userName;
    }

    /**
     * Setter for userName
     *
     * @param string $userName
     * @return self
     */
    public function setUserName(string $userName)
    {
        $this->userName = $userName;
        return $this;
    }

    /**
     * Getter for emailAddress
     *
     * @return string
     */
    public function getEmailAddress(): string
    {
        return $this->emailAddress;
    }

    /**
     * Setter for emailAddress
     *
     * @param string $emailAddress
     * @return self
     */
    public function setEmailAddress(string $emailAddress)
    {
        $this->emailAddress = $emailAddress;
        return $this;
    }

    /**
     * Getter for serverId
     *
     * @return int
     */
    public function getServerId(): int
    {
        return $this->serverId;
    }

    /**
     * Setter for serverId
     *
     * @param int $serverId
     * @return self
     */
    public function setServerId(int $serverId)
    {
        $this->serverId = $serverId;
        return $this;
    }

    /**
     * Getter for domains
     *
     * @return array
     */
    public function getDomains(): array
    {
        return $this->domains;
    }

    /**
     * Setter for domains
     *
     * @param array $domains
     * @return self
     */
    public function setDomains(array $domains)
    {
        $this->domains = $domains;
        return $this;
    }

    /**
     * @param string $userName
     * @param string $emailAddress
     * @param int $serverId
     * @param array $domains
     * @return void
     */
    public function __construct(string $userName, string $emailAddress, int $serverId, array $domains)
    {
        $this->userName = $userName;
        $this->emailAddress = $emailAddress;
        $this->serverId = $serverId;
        $this->domains = $domains;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
