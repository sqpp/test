<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface CredentialsDTOInterface
{
    /**
     * Getter for email
     *
     * @return string
     */
    public function getEmail(): string;

    /**
     * Setter for email
     *
     * @param string $email
     * @return self
     */
    public function setEmail(string $email);

    /**
     * Getter for password
     *
     * @return string
     */
    public function getPassword(): string;

    /**
     * Setter for password
     *
     * @param string $password
     * @return self
     */
    public function setPassword(string $password);
}
