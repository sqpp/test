<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class CpuAndMemoryDTO implements \JsonSerializable
{
    /** @var array */
    private $cpu;

    /** @var array */
    private $mem;


    public function getCpu(): array
    {
        return $this->cpu;
    }

    public function setCpu(array $cpu): void
    {
        $this->cpu = $cpu;
    }

    public function getMem(): array
    {
        return $this->mem;
    }

    public function setMem(array $mem): void
    {
        $this->mem = $mem;
    }

    public function __construct(array $cpu, array $mem)
    {
        $this->setCpu($cpu);
        $this->setMem($mem);
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
