<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class FirewallListUpdateIpDTO implements FirewallListUpdateIpDTOInterface, \JsonSerializable
{
    /**
     * Custom comment for the IP range
     * Example: My customers IP range
     *
     * @var string
     */
    protected $comment;

    /**
     * IP address or IP range. IPv4 and IPv6 supported as well.
     * Example: 125.19.23.0/24
     *
     * @var string
     */
    protected $ip;

    /**
     * Getter for comment
     *
     * @return string
     */
    public function getComment(): string
    {
        return $this->comment;
    }

    /**
     * Setter for comment
     *
     * @param string $comment
     * @return self
     */
    public function setComment(string $comment)
    {
        $this->comment = $comment;
        return $this;
    }

    /**
     * Getter for ip
     *
     * @return string
     */
    public function getIp(): string
    {
        return $this->ip;
    }

    /**
     * Setter for ip
     *
     * @param string $ip
     * @return self
     */
    public function setIp(string $ip)
    {
        $this->ip = $ip;
        return $this;
    }

    /**
     * @param string $comment
     * @param string $ip
     * @return void
     */
    public function __construct(string $comment, string $ip)
    {
        $this->comment = $comment;
        $this->ip = $ip;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
