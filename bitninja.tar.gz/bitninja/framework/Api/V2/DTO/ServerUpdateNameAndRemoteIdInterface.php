<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface ServerUpdateNameAndRemoteIdInterface
{
    /**
     * Getter for displayName
     *
     * @return string
     */
    public function getDisplayName(): string;

    /**
     * Setter for displayName
     *
     * @param string $displayName
     * @return self
     */
    public function setDisplayName(string $displayName);

    /**
     * Getter for remoteId
     *
     * @return string
     */
    public function getRemoteId(): string;

    /**
     * Setter for remoteId
     *
     * @param string $remoteId
     * @return self
     */
    public function setRemoteId(string $remoteId);
}
