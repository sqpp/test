<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class LicenseAcquireRequestDTO implements LicenseAcquireRequestDTOInterface, \JsonSerializable
{
    /**
     * User unique provision key
     *
     * @var string
     */
    protected $provisionKey;

    /**
     * BitNinja product type
     *
     * @var string
     */
    protected $type;

    /**
     * BitNinja Agent unique generated ID
     *
     * @var string
     */
    protected $appId;

    /**
     * Server hostname
     *
     * @var string
     */
    protected $hostName;

    /**
     * Getter for provisionKey
     *
     * @return string
     */
    public function getProvisionKey(): string
    {
        return $this->provisionKey;
    }

    /**
     * Setter for provisionKey
     *
     * @param string $provisionKey
     * @return self
     */
    public function setProvisionKey(string $provisionKey)
    {
        $this->provisionKey = $provisionKey;
        return $this;
    }

    /**
     * Getter for type
     *
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * Setter for type
     *
     * @param string $type
     * @return self
     */
    public function setType(string $type)
    {
        $this->type = $type;
        return $this;
    }

    /**
     * Getter for appId
     *
     * @return string
     */
    public function getAppId(): string
    {
        return $this->appId;
    }

    /**
     * Setter for appId
     *
     * @param string $appId
     * @return self
     */
    public function setAppId(string $appId)
    {
        $this->appId = $appId;
        return $this;
    }

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string
    {
        return $this->hostName;
    }

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName)
    {
        $this->hostName = $hostName;
        return $this;
    }

    /**
     * @param string $provisionKey
     * @param string $type
     * @param string $appId
     * @param string $hostName
     * @return void
     */
    public function __construct(string $provisionKey, string $type, string $appId, string $hostName)
    {
        $this->provisionKey = $provisionKey;
        $this->type = $type;
        $this->appId = $appId;
        $this->hostName = $hostName;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
