<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface ExtensionInterface
{
    /**
     * Getter for family
     *
     * @return string
     */
    public function getFamily(): string;

    /**
     * Setter for family
     *
     * @param string $family
     * @return self
     */
    public function setFamily(string $family);

    /**
     * Getter for version
     *
     * @return string
     */
    public function getVersion(): string;

    /**
     * Setter for version
     *
     * @param string $version
     * @return self
     */
    public function setVersion(string $version);
}
