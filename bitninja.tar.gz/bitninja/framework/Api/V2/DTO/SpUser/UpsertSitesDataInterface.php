<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface UpsertSitesDataInterface
{
    /**
     * Getter for serverId
     *
     * @return int
     */
    public function getServerId(): int;

    /**
     * Setter for serverId
     *
     * @param int $serverId
     * @return self
     */
    public function setServerId(int $serverId);

    /**
     * Getter for linuxUserName
     *
     * @return string
     */
    public function getLinuxUserName(): string;

    /**
     * Setter for linuxUserName
     *
     * @param string $linuxUserName
     * @return self
     */
    public function setLinuxUserName(string $linuxUserName);

    /**
     * Getter for extension
     *
     * @return BitNinja\Framework\Api\V2\DTO\SpUser\ExtensionInterface
     */
    public function getExtension(): ExtensionInterface;

    /**
     * Setter for extension
     *
     * @param BitNinja\Framework\Api\V2\DTO\SpUser\ExtensionInterface $extension
     * @return self
     */
    public function setExtension(ExtensionInterface $extension);

    /**
     * Getter for sites
     *
     * @return array
     */
    public function getSites(): array;

    /**
     * Setter for sites
     *
     * @param array $sites
     * @return self
     */
    public function setSites(array $sites);
}
