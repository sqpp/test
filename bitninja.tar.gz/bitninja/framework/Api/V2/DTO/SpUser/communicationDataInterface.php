<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface communicationDataInterface
{
    /**
     * Getter for spEmail
     *
     * @return string
     */
    public function getSpEmail(): string;

    /**
     * @param string $spEmail
     * 
     * @return void
     * Setter for spEmail
     *
     * @param string $spEmail
     * @return self
     */
    public function setSpEmail(string $spEmail);

    /**
     * Getter for contactName
     *
     * @return string
     */
    public function getContactName(): string;

    /**
     * @param string $contactName
     * 
     * @return void
     * Setter for contactName
     *
     * @param string $contactName
     * @return self
     */
    public function setContactName(string $contactName);

    /**
     * Getter for contactPhone
     *
     * @return string
     */
    public function getContactPhone(): string;

    /**
     * @param string $contactPhone
     * 
     * @return void
     * Setter for contactPhone
     *
     * @param string $contactPhone
     * @return self
     */
    public function setContactPhone(string $contactPhone);

    /**
     * Getter for communication
     *
     * @return array
     */
    public function getCommunication(): array;

    /**
     * @param array $communication
     * 
     * @return void
     * Setter for communication
     *
     * @param array $communication
     * @return self
     */
    public function setCommunication(array $communication);
}
