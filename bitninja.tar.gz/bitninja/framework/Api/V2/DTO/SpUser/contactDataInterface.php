<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface contactDataInterface
{
    /**
     * Getter for contact_name
     *
     * @return string
     */
    public function getContact_name(): string;

    /**
     * @param string $contact_name
     * @return void
     * Setter for contact_name
     *
     * @param string $contact_name
     * @return self
     */
    public function setContact_name(string $contact_name);

    /**
     * Getter for contact_phone
     *
     * @return string
     */
    public function getContact_phone(): string;

    /**
     * @param string $contact_phone
     * @return void
     * Setter for contact_phone
     *
     * @param string $contact_phone
     * @return self
     */
    public function setContact_phone(string $contact_phone);
}
