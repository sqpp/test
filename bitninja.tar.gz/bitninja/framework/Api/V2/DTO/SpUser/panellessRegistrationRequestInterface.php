<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface panellessRegistrationRequestInterface
{
    /**
     * Getter for parentId
     *
     * @return int
     */
    public function getParentId(): int;

    /**
     * Setter for parentId
     *
     * @param int $parentId
     * @return self
     */
    public function setParentId(int $parentId);

    /**
     * Getter for serverId
     *
     * @return string
     */
    public function getServerId(): string;

    /**
     * Setter for serverId
     *
     * @param string $serverId
     * @return self
     */
    public function setServerId(string $serverId);

    /**
     * Getter for linuxUserName
     *
     * @return string
     */
    public function getLinuxUserName(): string;

    /**
     * Setter for linuxUserName
     *
     * @param string $linuxUserName
     * @return self
     */
    public function setLinuxUserName(string $linuxUserName);

    /**
     * Getter for sites
     *
     * @return array
     */
    public function getSites(): array;

    /**
     * Setter for sites
     *
     * @param array $sites
     * @return self
     */
    public function setSites(array $sites);

    /**
     * Getter for browserDatetime
     *
     * @return string
     */
    public function getBrowserDatetime(): string;

    /**
     * Setter for browserDatetime
     *
     * @param string $browserDatetime
     * @return self
     */
    public function setBrowserDatetime(string $browserDatetime);

    /**
     * Getter for email
     *
     * @return string
     */
    public function getEmail(): string;

    /**
     * Setter for email
     *
     * @param string $email
     * @return self
     */
    public function setEmail(string $email);

    /**
     * Getter for contactName
     *
     * @return string
     */
    public function getContactName(): string;

    /**
     * Setter for contactName
     *
     * @param string $contactName
     * @return self
     */
    public function setContactName(string $contactName);

    /**
     * Getter for contactPhone
     *
     * @return string
     */
    public function getContactPhone(): string;

    /**
     * Setter for contactPhone
     *
     * @param string $contactPhone
     * @return self
     */
    public function setContactPhone(string $contactPhone);
}
