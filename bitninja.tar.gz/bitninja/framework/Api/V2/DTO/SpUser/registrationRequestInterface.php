<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface registrationRequestInterface
{
    /**
     * Getter for parentId
     *
     * @return int
     */
    public function getParentId(): int;

    /**
     * Setter for parentId
     *
     * @param int $parentId
     * @return self
     */
    public function setParentId(int $parentId);

    /**
     * Getter for email
     *
     * @return string
     */
    public function getEmail(): string;

    /**
     * Setter for email
     *
     * @param string $email
     * @return self
     */
    public function setEmail(string $email);

    /**
     * Getter for password
     *
     * @return string
     */
    public function getPassword(): string;

    /**
     * Setter for password
     *
     * @param string $password
     * @return self
     */
    public function setPassword(string $password);

    /**
     * Getter for browserDatetime
     *
     * @return string
     */
    public function getBrowserDatetime(): string;

    /**
     * Setter for browserDatetime
     *
     * @param string $browserDatetime
     * @return self
     */
    public function setBrowserDatetime(string $browserDatetime);

    /**
     * Getter for siteDataId
     *
     * @return string
     */
    public function getSiteDataId(): string;

    /**
     * Setter for siteDataId
     *
     * @param string $siteDataId
     * @return self
     */
    public function setSiteDataId(string $siteDataId);

    /**
     * Getter for contactName
     *
     * @return string
     */
    public function getContactName(): string;

    /**
     * Setter for contactName
     *
     * @param string $contactName
     * @return self
     */
    public function setContactName(string $contactName);

    /**
     * Getter for contactPhone
     *
     * @return string
     */
    public function getContactPhone(): string;

    /**
     * Setter for contactPhone
     *
     * @param string $contactPhone
     * @return self
     */
    public function setContactPhone(string $contactPhone);
}
