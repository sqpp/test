<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface onboardSetDataInterface
{
    /**
     * Getter for startJourney
     *
     * @return boolean
     */
    public function getStartJourney(): \boolean;

    /**
     * Setter for startJourney
     *
     * @param boolean $startJourney
     * @return self
     */
    public function setStartJourney(\boolean $startJourney);

    /**
     * Getter for malwareRemoval
     *
     * @return boolean
     */
    public function getMalwareRemoval(): \boolean;

    /**
     * Setter for malwareRemoval
     *
     * @param boolean $malwareRemoval
     * @return self
     */
    public function setMalwareRemoval(\boolean $malwareRemoval);

    /**
     * Getter for secureLayer
     *
     * @return boolean
     */
    public function getSecureLayer(): \boolean;

    /**
     * Setter for secureLayer
     *
     * @param boolean $secureLayer
     * @return self
     */
    public function setSecureLayer(\boolean $secureLayer);

    /**
     * Getter for externalScan
     *
     * @return boolean
     */
    public function getExternalScan(): \boolean;

    /**
     * Setter for externalScan
     *
     * @param boolean $externalScan
     * @return self
     */
    public function setExternalScan(\boolean $externalScan);

    /**
     * Getter for phishingAlert
     *
     * @return boolean
     */
    public function getPhishingAlert(): \boolean;

    /**
     * Setter for phishingAlert
     *
     * @param boolean $phishingAlert
     * @return self
     */
    public function setPhishingAlert(\boolean $phishingAlert);
}
