<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Site implements SiteInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $domain;

    /**
     * @var string
     */
    protected $documentRoot;

    /**
     * @var string
     */
    protected $user;

    /**
     * @var string
     */
    protected $serverAdmin;

    /**
     * @var string
     */
    protected $domainType;

    /**
     * Getter for domain
     *
     * @return string
     */
    public function getDomain(): string
    {
        return $this->domain;
    }

    /**
     * Setter for domain
     *
     * @param string $domain
     * @return self
     */
    public function setDomain(string $domain)
    {
        $this->domain = $domain;
        return $this;
    }

    /**
     * Getter for documentRoot
     *
     * @return string
     */
    public function getDocumentRoot(): string
    {
        return $this->documentRoot;
    }

    /**
     * Setter for documentRoot
     *
     * @param string $documentRoot
     * @return self
     */
    public function setDocumentRoot(string $documentRoot)
    {
        $this->documentRoot = $documentRoot;
        return $this;
    }

    /**
     * Getter for user
     *
     * @return string
     */
    public function getUser(): string
    {
        return $this->user;
    }

    /**
     * Setter for user
     *
     * @param string $user
     * @return self
     */
    public function setUser(string $user)
    {
        $this->user = $user;
        return $this;
    }

    /**
     * Getter for serverAdmin
     *
     * @return string
     */
    public function getServerAdmin(): string
    {
        return $this->serverAdmin;
    }

    /**
     * Setter for serverAdmin
     *
     * @param string $serverAdmin
     * @return self
     */
    public function setServerAdmin(string $serverAdmin)
    {
        $this->serverAdmin = $serverAdmin;
        return $this;
    }

    /**
     * Getter for domainType
     *
     * @return string
     */
    public function getDomainType(): string
    {
        return $this->domainType;
    }

    /**
     * Setter for domainType
     *
     * @param string $domainType
     * @return self
     */
    public function setDomainType(string $domainType)
    {
        $this->domainType = $domainType;
        return $this;
    }

    /**
     * @param string $domain
     * @param string $documentRoot
     * @param string $domainType
     * @return void
     */
    public function __construct(string $domain, string $documentRoot, string $domainType)
    {
        $this->domain = $domain;
        $this->documentRoot = $documentRoot;
        $this->domainType = $domainType;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
