<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface domainInterface
{
    /**
     * Getter for domain
     *
     * @return string
     */
    public function getDomain(): string;

    /**
     * Setter for domain
     *
     * @param string $domain
     * @return self
     */
    public function setDomain(string $domain);

    /**
     * Getter for documentRoot
     *
     * @return string
     */
    public function getDocumentRoot(): string;

    /**
     * Setter for documentRoot
     *
     * @param string $documentRoot
     * @return self
     */
    public function setDocumentRoot(string $documentRoot);

    /**
     * Getter for type
     *
     * @return string
     */
    public function getType(): string;

    /**
     * Setter for type
     *
     * @param string $type
     * @return self
     */
    public function setType(string $type);
}
