<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Extension implements ExtensionInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $family;

    /**
     * @var string
     */
    protected $version;

    /**
     * Getter for family
     *
     * @return string
     */
    public function getFamily(): string
    {
        return $this->family;
    }

    /**
     * Setter for family
     *
     * @param string $family
     * @return self
     */
    public function setFamily(string $family)
    {
        $this->family = $family;
        return $this;
    }

    /**
     * Getter for version
     *
     * @return string
     */
    public function getVersion(): string
    {
        return $this->version;
    }

    /**
     * Setter for version
     *
     * @param string $version
     * @return self
     */
    public function setVersion(string $version)
    {
        $this->version = $version;
        return $this;
    }

    /**
     * @param string $family
     * @param integer $version
     * @return void
     */
    public function __construct(string $family, string $version)
    {
        $this->family = $family;
        $this->version = $version;
    }

    /**
     * 
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
