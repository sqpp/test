<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class UpsertSitesRequest implements UpsertSitesRequestInterface, \JsonSerializable
{
    /**
     * @var BitNinja\Framework\Api\V2\DTO\SpUser\MetaInterface
     */
    protected $meta;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\SpUser\UpsertSitesDataInterface
     */
    protected $data;

    /**
     * Getter for meta
     *
     * @return BitNinja\Framework\Api\V2\DTO\SpUser\MetaInterface
     */
    public function getMeta(): MetaInterface
    {
        return $this->meta;
    }

    /**
     * Setter for meta
     *
     * @param BitNinja\Framework\Api\V2\DTO\SpUser\MetaInterface $meta
     * @return self
     */
    public function setMeta(MetaInterface $meta)
    {
        $this->meta = $meta;
        return $this;
    }

    /**
     * Getter for data
     *
     * @return BitNinja\Framework\Api\V2\DTO\SpUser\UpsertSitesDataInterface
     */
    public function getData(): UpsertSitesDataInterface
    {
        return $this->data;
    }

    /**
     * Setter for data
     *
     * @param BitNinja\Framework\Api\V2\DTO\SpUser\UpsertSitesDataInterface $data
     * @return self
     */
    public function setData(UpsertSitesDataInterface $data)
    {
        $this->data = $data;
        return $this;
    }

    /**
     * @param BitNinja\Framework\Api\V2\DTO\SpUser\MetaInterface $meta
     * @param BitNinja\Framework\Api\V2\DTO\SpUser\UpsertSitesDataInterface $data
     * @return void
     */
    public function __construct(MetaInterface $meta, UpsertSitesDataInterface $data)
    {
        $this->meta = $meta;
        $this->data = $data;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
