<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class panellessRegistrationRequest implements panellessRegistrationRequestInterface, \JsonSerializable
{
    /**
     * @var integer
     */
    protected $parentId;

    /**
     * @var string
     */
    protected $serverId;

    /**
     * @var string
     */
    protected $linuxUserName;

    /**
     * @var array
     */
    protected $sites;

    /**
     * @var string
     */
    protected $browserDatetime;

    /**
     * @var string
     */
    protected $email;

    /**
     * @var string
     */
    protected $contactName;

    /**
     * @var string
     */
    protected $contactPhone;

    /**
     * Getter for parentId
     *
     * @return integer
     */
    public function getParentId(): int
    {
        return $this->parentId;
    }

    /**
     * Setter for parentId
     *
     * @param integer $parentId
     * @return self
     */
    public function setParentId(int $parentId)
    {
        $this->parentId = $parentId;
        return $this;
    }

    /**
     * Getter for serverId
     *
     * @return string
     */
    public function getServerId(): string
    {
        return $this->serverId;
    }

    /**
     * Setter for serverId
     *
     * @param string $serverId
     * @return self
     */
    public function setServerId(string $serverId)
    {
        $this->serverId = $serverId;
        return $this;
    }

    /**
     * Getter for linuxUserName
     *
     * @return string
     */
    public function getLinuxUserName(): string
    {
        return $this->linuxUserName;
    }

    /**
     * Setter for linuxUserName
     *
     * @param string $linuxUserName
     * @return self
     */
    public function setLinuxUserName(string $linuxUserName)
    {
        $this->linuxUserName = $linuxUserName;
        return $this;
    }

    /**
     * Getter for sites
     *
     * @return array
     */
    public function getSites(): array
    {
        return $this->sites;
    }

    /**
     * Setter for sites
     *
     * @param array $sites
     * @return self
     */
    public function setSites(array $sites)
    {
        $this->sites = $sites;
        return $this;
    }

    /**
     * Getter for browserDatetime
     *
     * @return string
     */
    public function getBrowserDatetime(): string
    {
        return $this->browserDatetime;
    }

    /**
     * Setter for browserDatetime
     *
     * @param string $browserDatetime
     * @return self
     */
    public function setBrowserDatetime(string $browserDatetime)
    {
        $this->browserDatetime = $browserDatetime;
        return $this;
    }

    /**
     * Getter for email
     *
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * Setter for email
     *
     * @param string $email
     * @return self
     */
    public function setEmail(string $email)
    {
        $this->email = $email;
        return $this;
    }

    /**
     * Getter for contactName
     *
     * @return string
     */
    public function getContactName(): string
    {
        return $this->contactName;
    }

    /**
     * Setter for contactName
     *
     * @param string $contactName
     * @return self
     */
    public function setContactName(string $contactName)
    {
        $this->contactName = $contactName;
        return $this;
    }

    /**
     * Getter for contactPhone
     *
     * @return string
     */
    public function getContactPhone(): string
    {
        return $this->contactPhone;
    }

    /**
     * Setter for contactPhone
     *
     * @param string $contactPhone
     * @return self
     */
    public function setContactPhone(string $contactPhone)
    {
        $this->contactPhone = $contactPhone;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
