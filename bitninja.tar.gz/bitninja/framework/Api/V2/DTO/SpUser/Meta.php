<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Meta implements MetaInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $actionId;

    /**
     * @var string
     */
    protected $actionKind;

    /**
     * @var string
     */
    protected $messageVersion;

    /**
     * Getter for actionId
     *
     * @return string
     */
    public function getActionId(): string
    {
        return $this->actionId;
    }

    /**
     * Setter for actionId
     *
     * @param string $actionId
     * @return self
     */
    public function setActionId(string $actionId)
    {
        $this->actionId = $actionId;
        return $this;
    }

    /**
     * Getter for actionKind
     *
     * @return string
     */
    public function getActionKind(): string
    {
        return $this->actionKind;
    }

    /**
     * Setter for actionKind
     *
     * @param string $actionKind
     * @return self
     */
    public function setActionKind(string $actionKind)
    {
        $this->actionKind = $actionKind;
        return $this;
    }

    /**
     * Getter for messageVersion
     *
     * @return string
     */
    public function getMessageVersion(): string
    {
        return $this->messageVersion;
    }

    /**
     * Setter for messageVersion
     *
     * @param string $messageVersion
     * @return self
     */
    public function setMessageVersion(string $messageVersion)
    {
        $this->messageVersion = $messageVersion;
        return $this;
    }

    /**
     * @param string $actionId
     * @param string $actionKind
     * @param string $messageVersion
     * @return void
     */
    public function __construct(string $actionId, string $actionKind, string $messageVersion)
    {
        $this->actionId = $actionId;
        $this->actionKind = $actionKind;
        $this->messageVersion = $messageVersion;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
