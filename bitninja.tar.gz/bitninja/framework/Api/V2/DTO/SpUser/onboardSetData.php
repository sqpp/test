<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class onboardSetData implements onboardSetDataInterface, \JsonSerializable
{
    /**
     * @var boolean
     */
    protected $startJourney;

    /**
     * @var boolean
     */
    protected $malwareRemoval;

    /**
     * @var boolean
     */
    protected $secureLayer;

    /**
     * @var boolean
     */
    protected $externalScan;

    /**
     * @var boolean
     */
    protected $phishingAlert;

    /**
     * Getter for startJourney
     *
     * @return boolean
     */
    public function getStartJourney(): \boolean
    {
        return $this->startJourney;
    }

    /**
     * Setter for startJourney
     *
     * @param boolean $startJourney
     * @return self
     */
    public function setStartJourney(\boolean $startJourney)
    {
        $this->startJourney = $startJourney;
        return $this;
    }

    /**
     * Getter for malwareRemoval
     *
     * @return boolean
     */
    public function getMalwareRemoval(): \boolean
    {
        return $this->malwareRemoval;
    }

    /**
     * Setter for malwareRemoval
     *
     * @param boolean $malwareRemoval
     * @return self
     */
    public function setMalwareRemoval(\boolean $malwareRemoval)
    {
        $this->malwareRemoval = $malwareRemoval;
        return $this;
    }

    /**
     * Getter for secureLayer
     *
     * @return boolean
     */
    public function getSecureLayer(): \boolean
    {
        return $this->secureLayer;
    }

    /**
     * Setter for secureLayer
     *
     * @param boolean $secureLayer
     * @return self
     */
    public function setSecureLayer(\boolean $secureLayer)
    {
        $this->secureLayer = $secureLayer;
        return $this;
    }

    /**
     * Getter for externalScan
     *
     * @return boolean
     */
    public function getExternalScan(): \boolean
    {
        return $this->externalScan;
    }

    /**
     * Setter for externalScan
     *
     * @param boolean $externalScan
     * @return self
     */
    public function setExternalScan(\boolean $externalScan)
    {
        $this->externalScan = $externalScan;
        return $this;
    }

    /**
     * Getter for phishingAlert
     *
     * @return boolean
     */
    public function getPhishingAlert(): \boolean
    {
        return $this->phishingAlert;
    }

    /**
     * Setter for phishingAlert
     *
     * @param boolean $phishingAlert
     * @return self
     */
    public function setPhishingAlert(\boolean $phishingAlert)
    {
        $this->phishingAlert = $phishingAlert;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
