<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class onboardData implements onboardDataInterface, \JsonSerializable
{
    /**
     * @var boolean
     */
    protected $completed;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\SpUser\onboardSetDataInterface
     */
    protected $steps;

    /**
     * Getter for completed
     *
     * @return boolean
     */
    public function getCompleted(): \boolean
    {
        return $this->completed;
    }

    /**
     * Setter for completed
     *
     * @param boolean $completed
     * @return self
     */
    public function setCompleted(\boolean $completed)
    {
        $this->completed = $completed;
        return $this;
    }

    /**
     * Getter for steps
     *
     * @return BitNinja\Framework\Api\V2\DTO\SpUser\onboardSetDataInterface
     */
    public function getSteps(): onboardSetDataInterface
    {
        return $this->steps;
    }

    /**
     * Setter for steps
     *
     * @param BitNinja\Framework\Api\V2\DTO\SpUser\onboardSetDataInterface $steps
     * @return self
     */
    public function setSteps(onboardSetDataInterface $steps)
    {
        $this->steps = $steps;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
