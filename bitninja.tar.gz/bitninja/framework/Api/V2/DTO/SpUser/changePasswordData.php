<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class changePasswordData implements changePasswordDataInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $oldPassword;

    /**
     * @var string
     */
    protected $newPassword;

    /**
     * Getter for oldPassword
     *
     * @return string
     */
    public function getOldPassword(): string
    {
        return $this->oldPassword;
    }

    /**
     * @param string $oldPassword
     * 
     * Setter for oldPassword
     *
     * @param string $oldPassword
     * @return self
     */
    public function setOldPassword(string $oldPassword)
    {
        $this->oldPassword = $oldPassword;
        return $this;
    }

    /**
     * Getter for newPassword
     *
     * @return string
     */
    public function getNewPassword(): string
    {
        return $this->newPassword;
    }

    /**
     * @param string $newPassword
     * 
     * Setter for newPassword
     *
     * @param string $newPassword
     * @return self
     */
    public function setNewPassword(string $newPassword)
    {
        $this->newPassword = $newPassword;
        return $this;
    }

    /**
     * @return self
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
