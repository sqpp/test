<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class UpsertSitesResponse implements UpsertSitesResponseInterface, \JsonSerializable
{
    /**
     * @var boolean
     */
    protected $isClaimed;

    /**
     * @var string
     */
    protected $siteDataId;

    /**
     * Getter for isClaimed
     *
     * @return boolean
     */
    public function getIsClaimed(): \boolean
    {
        return $this->isClaimed;
    }

    /**
     * Setter for isClaimed
     *
     * @param boolean $isClaimed
     * @return self
     */
    public function setIsClaimed(\boolean $isClaimed)
    {
        $this->isClaimed = $isClaimed;
        return $this;
    }

    /**
     * Getter for siteDataId
     *
     * @return string
     */
    public function getSiteDataId(): string
    {
        return $this->siteDataId;
    }

    /**
     * Setter for siteDataId
     *
     * @param string $siteDataId
     * @return self
     */
    public function setSiteDataId(string $siteDataId)
    {
        $this->siteDataId = $siteDataId;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
