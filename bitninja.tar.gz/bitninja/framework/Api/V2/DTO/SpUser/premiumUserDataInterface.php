<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface premiumUserDataInterface
{
    /**
     * Getter for linuxUserName
     *
     * @return string
     */
    public function getLinuxUserName(): string;

    /**
     * Setter for linuxUserName
     *
     * @param string $linuxUserName
     * @return self
     */
    public function setLinuxUserName(string $linuxUserName);

    /**
     * Getter for siteProtectionUserId
     *
     * @return int
     */
    public function getSiteProtectionUserId(): int;

    /**
     * Setter for siteProtectionUserId
     *
     * @param int $siteProtectionUserId
     * @return self
     */
    public function setSiteProtectionUserId(int $siteProtectionUserId);

    /**
     * Getter for domains
     *
     * @return array
     */
    public function getDomains(): array;

    /**
     * Setter for domains
     *
     * @param array $domains
     * @return self
     */
    public function setDomains(array $domains);
}
