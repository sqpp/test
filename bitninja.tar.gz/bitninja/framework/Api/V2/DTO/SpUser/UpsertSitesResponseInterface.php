<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface UpsertSitesResponseInterface
{
    /**
     * Getter for isClaimed
     *
     * @return boolean
     */
    public function getIsClaimed(): \boolean;

    /**
     * Setter for isClaimed
     *
     * @param boolean $isClaimed
     * @return self
     */
    public function setIsClaimed(\boolean $isClaimed);

    /**
     * Getter for siteDataId
     *
     * @return string
     */
    public function getSiteDataId(): string;

    /**
     * Setter for siteDataId
     *
     * @param string $siteDataId
     * @return self
     */
    public function setSiteDataId(string $siteDataId);
}
