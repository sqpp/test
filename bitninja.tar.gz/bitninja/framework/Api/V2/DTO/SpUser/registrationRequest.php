<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class registrationRequest implements registrationRequestInterface, \JsonSerializable
{
    /**
     * @var integer
     */
    protected $parentId;

    /**
     * @var string
     */
    protected $email;

    /**
     * @var string
     */
    protected $password;

    /**
     * @var string
     */
    protected $browserDatetime;

    /**
     * @var string
     */
    protected $siteDataId;

    /**
     * @var string
     */
    protected $contactName;

    /**
     * @var string
     */
    protected $contactPhone;

    /**
     * Getter for parentId
     *
     * @return integer
     */
    public function getParentId(): int
    {
        return $this->parentId;
    }

    /**
     * Setter for parentId
     *
     * @param integer $parentId
     * @return self
     */
    public function setParentId(int $parentId)
    {
        $this->parentId = $parentId;
        return $this;
    }

    /**
     * Getter for email
     *
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * Setter for email
     *
     * @param string $email
     * @return self
     */
    public function setEmail(string $email)
    {
        $this->email = $email;
        return $this;
    }

    /**
     * Getter for password
     *
     * @return string
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    /**
     * Setter for password
     *
     * @param string $password
     * @return self
     */
    public function setPassword(string $password)
    {
        $this->password = $password;
        return $this;
    }

    /**
     * Getter for browserDatetime
     *
     * @return string
     */
    public function getBrowserDatetime(): string
    {
        return $this->browserDatetime;
    }

    /**
     * Setter for browserDatetime
     *
     * @param string $browserDatetime
     * @return self
     */
    public function setBrowserDatetime(string $browserDatetime)
    {
        $this->browserDatetime = $browserDatetime;
        return $this;
    }

    /**
     * Getter for siteDataId
     *
     * @return string
     */
    public function getSiteDataId(): string
    {
        return $this->siteDataId;
    }

    /**
     * Setter for siteDataId
     *
     * @param string $siteDataId
     * @return self
     */
    public function setSiteDataId(string $siteDataId)
    {
        $this->siteDataId = $siteDataId;
        return $this;
    }

    /**
     * Getter for contactName
     *
     * @return string
     */
    public function getContactName(): string
    {
        return $this->contactName;
    }

    /**
     * Setter for contactName
     *
     * @param string $contactName
     * @return self
     */
    public function setContactName(string $contactName)
    {
        $this->contactName = $contactName;
        return $this;
    }

    /**
     * Getter for contactPhone
     *
     * @return string
     */
    public function getContactPhone(): string
    {
        return $this->contactPhone;
    }

    /**
     * Setter for contactPhone
     *
     * @param string $contactPhone
     * @return self
     */
    public function setContactPhone(string $contactPhone)
    {
        $this->contactPhone = $contactPhone;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
