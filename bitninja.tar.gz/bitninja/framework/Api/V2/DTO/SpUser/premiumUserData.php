<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class premiumUserData implements premiumUserDataInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $linuxUserName;

    /**
     * @var integer
     */
    protected $siteProtectionUserId;

    /**
     * @var array
     */
    protected $domains;

    /**
     * Getter for linuxUserName
     *
     * @return string
     */
    public function getLinuxUserName(): string
    {
        return $this->linuxUserName;
    }

    /**
     * Setter for linuxUserName
     *
     * @param string $linuxUserName
     * @return self
     */
    public function setLinuxUserName(string $linuxUserName)
    {
        $this->linuxUserName = $linuxUserName;
        return $this;
    }

    /**
     * Getter for siteProtectionUserId
     *
     * @return int
     */
    public function getSiteProtectionUserId(): int
    {
        return $this->siteProtectionUserId;
    }

    /**
     * Setter for siteProtectionUserId
     *
     * @param int $siteProtectionUserId
     * @return self
     */
    public function setSiteProtectionUserId(int $siteProtectionUserId)
    {
        $this->siteProtectionUserId = $siteProtectionUserId;
        return $this;
    }

    /**
     * Getter for domains
     *
     * @return array
     */
    public function getDomains(): array
    {
        return $this->domains;
    }

    /**
     * Setter for domains
     *
     * @param array $domains
     * @return self
     */
    public function setDomains(array $domains)
    {
        $this->domains = $domains;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
