<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class validationData implements validationDataInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $validation;

    /**
     * @var string
     */
    protected $emailAddress;

    /**
     * Getter for validation
     *
     * @return string
     */
    public function getValidation(): string
    {
        return $this->validation;
    }

    /**
     * Setter for validation
     *
     * @param string $validation
     * @return self
     */
    public function setValidation(string $validation)
    {
        $this->validation = $validation;
        return $this;
    }

    /**
     * Getter for emailAddress
     *
     * @return string
     */
    public function getEmailAddress(): string
    {
        return $this->emailAddress;
    }

    /**
     * Setter for emailAddress
     *
     * @param string $emailAddress
     * @return self
     */
    public function setEmailAddress(string $emailAddress)
    {
        $this->emailAddress = $emailAddress;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
