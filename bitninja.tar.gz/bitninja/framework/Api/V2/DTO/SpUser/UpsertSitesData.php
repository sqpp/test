<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class UpsertSitesData implements UpsertSitesDataInterface, \JsonSerializable
{
    /**
     * @var integer
     */
    protected $serverId;

    /**
     * @var string
     */
    protected $linuxUserName;

    /**
     * @var BitNinja\Framework\Api\V2\DTO\SpUser\ExtensionInterface
     */
    protected $extension;

    /**
     * @var array
     */
    protected $sites;

    /**
     * Getter for serverId
     *
     * @return int
     */
    public function getServerId(): int
    {
        return $this->serverId;
    }

    /**
     * Setter for serverId
     *
     * @param int $serverId
     * @return self
     */
    public function setServerId(int $serverId)
    {
        $this->serverId = $serverId;
        return $this;
    }

    /**
     * Getter for linuxUserName
     *
     * @return string
     */
    public function getLinuxUserName(): string
    {
        return $this->linuxUserName;
    }

    /**
     * Setter for linuxUserName
     *
     * @param string $linuxUserName
     * @return self
     */
    public function setLinuxUserName(string $linuxUserName)
    {
        $this->linuxUserName = $linuxUserName;
        return $this;
    }

    /**
     * Getter for extension
     *
     * @return BitNinja\Framework\Api\V2\DTO\SpUser\ExtensionInterface
     */
    public function getExtension(): ExtensionInterface
    {
        return $this->extension;
    }

    /**
     * Setter for extension
     *
     * @param BitNinja\Framework\Api\V2\DTO\SpUser\ExtensionInterface $extension
     * @return self
     */
    public function setExtension(ExtensionInterface $extension)
    {
        $this->extension = $extension;
        return $this;
    }

    /**
     * Getter for sites
     *
     * @return array
     */
    public function getSites(): array
    {
        return $this->sites;
    }

    /**
     * Setter for sites
     *
     * @param array $sites
     * @return self
     */
    public function setSites(array $sites)
    {
        $this->sites = $sites;
        return $this;
    }

    /**
     * @param integer $serverId
     * @param string $linuxUserName
     * @param BitNinja\Framework\Api\V2\DTO\SpUser\ExtensionInterface $extension
     * @param array $sites
     * @return void
     */
    public function __construct(int $serverId, string $linuxUserName, ExtensionInterface $extension, array $sites)
    {
        $this->serverId = $serverId;
        $this->linuxUserName = $linuxUserName;
        $this->extension = $extension;
        $this->sites = $sites;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
