<?php

namespace BitNinja\Framework\Api\V2\DTO\SpUser;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class communicationData implements communicationDataInterface, \JsonSerializable
{
    /**
     * @var string
     */
    protected $spEmail;

    /**
     * @var string
     */
    protected $contactName;

    /**
     * @var string
     */
    protected $contactPhone;

    /**
     * @var array
     */
    protected $communication;

    /**
     * Getter for spEmail
     *
     * @return string
     */
    public function getSpEmail(): string
    {
        return $this->spEmail;
    }

    /**
     * Setter for spEmail
     *
     * @param string $spEmail
     * @return self
     */
    public function setSpEmail(string $spEmail)
    {
        $this->spEmail = $spEmail;
        return $this;
    }

    /**
     * Getter for contactName
     *
     * @return string
     */
    public function getContactName(): string
    {
        return $this->contactName;
    }

    /**
     * Setter for contactName
     *
     * @param string $contactName
     * @return self
     */
    public function setContactName(string $contactName)
    {
        $this->contactName = $contactName;
        return $this;
    }

    /**
     * Getter for contactPhone
     *
     * @return string
     */
    public function getContactPhone(): string
    {
        return $this->contactPhone;
    }

    /**
     * Setter for contactPhone
     *
     * @param string $contactPhone
     * @return self
     */
    public function setContactPhone(string $contactPhone)
    {
        $this->contactPhone = $contactPhone;
        return $this;
    }

    /**
     * Getter for communication
     *
     * @return array
     */
    public function getCommunication(): array
    {
        return $this->communication;
    }

    /**
     * Setter for communication
     *
     * @param array $communication
     * @return self
     */
    public function setCommunication(array $communication)
    {
        $this->communication = $communication;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
