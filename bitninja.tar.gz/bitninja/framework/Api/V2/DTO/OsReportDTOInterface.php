<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface OsReportDTOInterface
{
    /**
     * Getter for os
     *
     * @return BitNinja\Framework\Api\V2\DTO\OsInfoDTOInterface
     */
    public function getOs(): OsInfoDTOInterface;

    /**
     * Setter for os
     *
     * @param BitNinja\Framework\Api\V2\DTO\OsInfoDTOInterface $os
     * @return self
     */
    public function setOs(OsInfoDTOInterface $os);

    /**
     * Getter for server
     *
     * @return BitNinja\Framework\Api\V2\DTO\ServerInfoDTOInterface
     */
    public function getServer(): ServerInfoDTOInterface;

    /**
     * Setter for server
     *
     * @param BitNinja\Framework\Api\V2\DTO\ServerInfoDTOInterface $server
     * @return self
     */
    public function setServer(ServerInfoDTOInterface $server);

    /**
     * Getter for memory
     *
     * @return BitNinja\Framework\Api\V2\DTO\MemoryInfoDTOInterface
     */
    public function getMemory(): MemoryInfoDTOInterface;

    /**
     * Setter for memory
     *
     * @param BitNinja\Framework\Api\V2\DTO\MemoryInfoDTOInterface $memory
     * @return self
     */
    public function setMemory(MemoryInfoDTOInterface $memory);

    /**
     * Getter for disk
     *
     * @return BitNinja\Framework\Api\V2\DTO\DiskInfoDTOInterface
     */
    public function getDisk(): DiskInfoDTOInterface;

    /**
     * Setter for disk
     *
     * @param BitNinja\Framework\Api\V2\DTO\DiskInfoDTOInterface $disk
     * @return self
     */
    public function setDisk(DiskInfoDTOInterface $disk);

    /**
     * Getter for cpu
     *
     * @return BitNinja\Framework\Api\V2\DTO\CpuInfoDTOInterface
     */
    public function getCpu(): CpuInfoDTOInterface;

    /**
     * Setter for cpu
     *
     * @param BitNinja\Framework\Api\V2\DTO\CpuInfoDTOInterface $cpu
     * @return self
     */
    public function setCpu(CpuInfoDTOInterface $cpu);

    /**
     * Getter for networks
     *
     * @return array
     */
    public function getNetworks(): array;

    /**
     * Setter for networks
     *
     * @param array $networks
     * @return self
     */
    public function setNetworks(array $networks);

    /**
     * Getter for environment
     *
     * @return object
     */
    public function getEnvironment(): object;

    /**
     * Setter for environment
     *
     * @param object $environment
     * @return self
     */
    public function setEnvironment(object $environment);
}
