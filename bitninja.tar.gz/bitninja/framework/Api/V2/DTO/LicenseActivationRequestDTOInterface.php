<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface LicenseActivationRequestDTOInterface
{
    /**
     * Getter for license
     *
     * @return string
     */
    public function getLicense(): string;

    /**
     * Setter for license
     *
     * @param string $license
     * @return self
     */
    public function setLicense(string $license);

    /**
     * Getter for type
     *
     * @return string
     */
    public function getType();

    /**
     * Setter for type
     *
     * @param string $type
     * @return self
     */
    public function setType($type);

    /**
     * Getter for appId
     *
     * @return string
     */
    public function getAppId(): string;

    /**
     * Setter for appId
     *
     * @param string $appId
     * @return self
     */
    public function setAppId(string $appId);

    /**
     * Getter for hostName
     *
     * @return string
     */
    public function getHostName(): string;

    /**
     * Setter for hostName
     *
     * @param string $hostName
     * @return self
     */
    public function setHostName(string $hostName);
}
