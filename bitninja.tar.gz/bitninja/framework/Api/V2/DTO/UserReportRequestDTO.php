<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class UserReportRequestDTO implements UserReportRequestDTOInterface, \JsonSerializable
{
    /**
     * List of server local users
     *
     * @var array
     */
    protected $localUsers;

    /**
     * Getter for localUsers
     *
     * @return array
     */
    public function getLocalUsers(): array
    {
        return $this->localUsers;
    }

    /**
     * Setter for localUsers
     *
     * @param array $localUsers
     * @return self
     */
    public function setLocalUsers(array $localUsers)
    {
        $this->localUsers = $localUsers;
        return $this;
    }

    /**
     * @param array $localUsers
     * @return void
     */
    public function __construct(array $localUsers)
    {
        $this->localUsers = $localUsers;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
