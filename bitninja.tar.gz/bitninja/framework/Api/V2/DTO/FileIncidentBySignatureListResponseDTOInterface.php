<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface FileIncidentBySignatureListResponseDTOInterface
{
    /**
     * Getter for serverId
     *
     * @return int
     */
    public function getServerId(): int;

    /**
     * Setter for serverId
     *
     * @param int $serverId
     * @return self
     */
    public function setServerId(int $serverId);

    /**
     * Getter for fileInfo
     *
     * @return string
     */
    public function getFileInfo();

    /**
     * Setter for fileInfo
     *
     * @param string $fileInfo
     * @return self
     */
    public function setFileInfo($fileInfo);

    /**
     * Getter for malwareInfo
     *
     * @return string
     */
    public function getMalwareInfo();

    /**
     * Setter for malwareInfo
     *
     * @param string $malwareInfo
     * @return self
     */
    public function setMalwareInfo($malwareInfo);

    /**
     * Getter for createdAt
     *
     * @return string
     */
    public function getCreatedAt();

    /**
     * Setter for createdAt
     *
     * @param string $createdAt
     * @return self
     */
    public function setCreatedAt($createdAt);
}
