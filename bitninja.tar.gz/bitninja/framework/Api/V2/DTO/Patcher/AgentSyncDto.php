<?php

namespace BitNinja\Framework\Api\V2\DTO\Patcher;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Jancsik Balázs <ezsolt@bitninja.io>
 * @copyright  © 2024 BitNinja Inc.
 */
class AgentSyncDto implements \JsonSerializable
{
    /** @var array */
    protected $statusesToGet;

    /** @var bool */
    protected $isNewDatabase;

    /**
     * @return self
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    /**
     * Get the value of statusesToGet
     */
    public function getStatusesToGet()
    {
        return $this->statusesToGet;
    }

    /**
     * Set the value of statusesToGet
     *
     * @return  self
     */
    public function setStatusesToGet($statusesToGet)
    {
        $this->statusesToGet = $statusesToGet;

        return $this;
    }

    /**
     * Get the value of isNewDatabase
     */
    public function getIsNewDatabase()
    {
        return $this->isNewDatabase;
    }

    /**
     * Set the value of isNewDatabase
     *
     * @return  self
     */
    public function setIsNewDatabase($isNewDatabase)
    {
        $this->isNewDatabase = $isNewDatabase;

        return $this;
    }
}
