<?php

namespace BitNinja\Framework\Api\V2\DTO\Patcher;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class PatchIdentifiedRequestDto implements \JsonSerializable
{
    /**
     * @var string
     */
    protected $patchName;

    /**
     * @var int
     */
    protected $identifiedAt;

    /** @var string */
    protected $domain;



    /**
     * @return self
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    /**
     * Get the value of identifiedAt
     *
     * @return  int
     */
    public function getIdentifiedAt()
    {
        return $this->identifiedAt;
    }

    /**
     * Set the value of identifiedAt
     *
     * @param  int  $identifiedAt
     *
     * @return  self
     */
    public function setIdentifiedAt(int $identifiedAt)
    {
        $this->identifiedAt = $identifiedAt;

        return $this;
    }

    /**
     * Get the value of patchName
     *
     * @return  string
     */
    public function getPatchName()
    {
        return $this->patchName;
    }

    /**
     * Set the value of patchName
     *
     * @param  string  $patchName
     *
     * @return  self
     */
    public function setPatchName(string $patchName)
    {
        $this->patchName = $patchName;

        return $this;
    }

    /**
     * Get the value of domain
     */
    public function getDomain()
    {
        return $this->domain;
    }

    /**
     * Set the value of domain
     *
     * @return  self
     */
    public function setDomain($domain)
    {
        $this->domain = $domain;

        return $this;
    }
}
