<?php

namespace BitNinja\Framework\Api\V2\DTO\Patcher;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class AgentResponseDto implements \JsonSerializable
{
    /** @var array */
    protected $patchNames;

    /** @var int */
    protected $identifiedAt;

    /** @var string */
    protected $domain;

    /** @var int */
    protected $status;

    /**
     * @return self
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    /**
     * Get the value of identifiedAt
     *
     * @return  int
     */
    public function getIdentifiedAt()
    {
        return $this->identifiedAt;
    }

    /**
     * Set the value of identifiedAt
     *
     * @param  int  $identifiedAt
     *
     * @return  self
     */
    public function setIdentifiedAt(int $identifiedAt)
    {
        $this->identifiedAt = $identifiedAt;

        return $this;
    }

    /**
     * Get the value of patchName
     *
     * @return  array
     */
    public function getPatchNames()
    {
        return $this->patchNames;
    }

    /**
     * Set the value of patchName
     *
     * @param  array  $patchName
     *
     * @return  self
     */
    public function setPatchNames(array $patchNames)
    {
        $this->patchNames = $patchNames;

        return $this;
    }

    /**
     * Get the value of domain
     */
    public function getDomain()
    {
        return $this->domain;
    }

    /**
     * Set the value of domain
     *
     * @return  self
     */
    public function setDomain($domain)
    {
        $this->domain = $domain;

        return $this;
    }

    /**
     * Get the value of status
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set the value of status
     *
     * @return  self
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }
}
