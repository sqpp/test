<?php

namespace BitNinja\Framework\Api\V2\DTO\Patcher;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class BackupInfoDto implements \JsonSerializable
{
    /**
     * @var string
     */
    protected $backupFilePath;

    /**
     * @var string
     */
    protected $domain;

    /**
     * @var string
     */
    protected $patchName;

    /**
     * @var int
     */
    protected $status;

    /**
     * @var string
     */
    protected $pattern;

    /**
     * @var string
     */
    protected $md5Hash;



    /**
     * @return self
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }


    public function getBackupFilePath(): string
    {
        return $this->backupFilePath;
    }

    public function setBackupFilePath(string $backupFilePath): void
    {
        $this->backupFilePath = $backupFilePath;
    }

    public function getDomain(): string
    {
        return $this->domain;
    }

    public function setDomain(string $domain): void
    {
        $this->domain = $domain;
    }


    public function getPatchName(): string
    {
        return $this->patchName;
    }

    public function setPatchName(string $patchName): void
    {
        $this->patchName = $patchName;
    }


    public function getStatus(): int
    {
        return $this->status;
    }


    public function setStatus(int $status): void
    {
        $this->status = $status;
    }

    /**
     * Get the value of pattern
     *
     * @return  string
     */
    public function getPattern()
    {
        return $this->pattern;
    }

    /**
     * Set the value of pattern
     *
     * @param  string  $pattern
     *
     * @return  self
     */
    public function setPattern(string $pattern)
    {
        $this->pattern = $pattern;

        return $this;
    }

    /**
     * Get the value of md5Hash
     *
     * @return  string
     */
    public function getMd5Hash()
    {
        return $this->md5Hash;
    }

    /**
     * Set the value of md5Hash
     *
     * @param  string  $md5Hash
     *
     * @return  self
     */
    public function setMd5Hash(string $md5Hash)
    {
        $this->md5Hash = $md5Hash;

        return $this;
    }
}
