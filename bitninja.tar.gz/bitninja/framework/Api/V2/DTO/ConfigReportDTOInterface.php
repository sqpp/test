<?php

namespace BitNinja\Framework\Api\V2\DTO;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
interface ConfigReportDTOInterface
{
    /**
     * Getter for config
     *
     * @return object
     */
    public function getConfig(): object;

    /**
     * Setter for config
     *
     * @param object $config
     * @return self
     */
    public function setConfig(object $config);
}
