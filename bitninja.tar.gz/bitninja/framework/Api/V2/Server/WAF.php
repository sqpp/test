<?php

namespace BitNinja\Framework\Api\V2\Server;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Peter Saller <peter.saller@bitninja.io>
 * @copyright  © 2022 BitNinja Inc.
 */
class WAF
{
    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     * @return void
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param int $serverId
     * @return mixed
     */
    public function post(int $serverId) 
    {   
        return $this->client->post("/v2/server/$serverId/waf/test");
    }
}