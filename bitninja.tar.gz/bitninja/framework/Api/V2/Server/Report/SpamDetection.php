<?php

namespace BitNinja\Framework\Api\V2\Server\Report;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Peter Saller <peter.saller@bitninja.io>
 * @copyright  © 2023 BitNinja Inc.
 * @package    BitNinja
 */
class SpamDetection
{
    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    private $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     * @return void
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param array $SpamDetectionDTO
     * @param int $serverId
     * @return mixed
     */
    public function post(int $serverId,array $SpamDetectionDTO)
    {
        $params[] = $SpamDetectionDTO;
        return $this->client->post("/v2/server/$serverId/report/spamDetection",$params);
    }
}
