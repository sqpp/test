<?php

namespace BitNinja\Framework\Api\V2\Server\Report;

use BitNinja\Framework\Api\V2\Adapter\AdapterInterface;
use BitNinja\Framework\Api\V2\DTO\CpuAndMemoryDTO;

/**
 * @author     Jancsik Balázs <balazs.jancsik@bitninja.io>
 * @copyright  © 2023 BitNinja Inc.
 */
class CpuAndMemoryTop
{
    /** @var AdapterInterface */
    public $client;

    public function __construct(AdapterInterface $client)
    {
        $this->client = $client;
    }


    public function post(CpuAndMemoryDTO $cpuAndMemoryDTO, int $serverId)
    {
        $params = [];
        $params[] = $cpuAndMemoryDTO;
        return $this->client->post("/v2/server/$serverId/report/cpuAndMemoryTop", $params);
    }
}
