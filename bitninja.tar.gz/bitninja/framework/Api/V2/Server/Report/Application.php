<?php

namespace BitNinja\Framework\Api\V2\Server\Report;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Application
{
    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     * @return void
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param \BitNinja\Framework\Api\V2\DTO\ApplicationReportBatchDTOInterface $applicationReportBatchDTO
     * @param int $serverId
     * @return mixed
     */
    public function post(
        \BitNinja\Framework\Api\V2\DTO\ApplicationReportBatchDTOInterface $applicationReportBatchDTO,
        int $serverId
    ) {
        $params = [];
        $params[] = $applicationReportBatchDTO;
        return $this->client->post("/v2/server/$serverId/report/application", $params);
    }
}
