<?php

namespace BitNinja\Framework\Api\V2\Hub\Waf;

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
class Rule
{
    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     */
    public $client;

    /**
     * @param \BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client
     * @return void
     */
    public function __construct(\BitNinja\Framework\Api\V2\Adapter\AdapterInterface $client)
    {
        $this->client = $client;
    }

    /**
     * @param \BitNinja\Framework\Api\V2\DTO\HubRuleWafDTOInterface $hubRuleWafDTO
     * @return mixed
     */
    public function post(\BitNinja\Framework\Api\V2\DTO\HubRuleWafDTOInterface $hubRuleWafDTO)
    {
        $params = [];
        $params[] = $hubRuleWafDTO;
        return $this->client->post("/v2/hub/waf/rule", $params);
    }

    /**
     * @return mixed
     */
    public function get()
    {
        return $this->client->get("/v2/hub/waf/rule");
    }
}
