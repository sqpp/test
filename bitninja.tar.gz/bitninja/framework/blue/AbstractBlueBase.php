<?php

/**
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
abstract class AbstractBlueBase
{

    /**
     * @var BlueLog
     */
    protected $log;

    public function __construct()
    {
        $this->log = \BlueLog::instance($this);
    }
}
