<?php

/**
 * It is the new version of BlueCommandManager.
 * The BlueCommandManager used legacy method to call a command. This
 * rewritten version is to support local calls and RabbitMq too.
 *
 * $ipset = BlueIpset::instnace();
 * $ipset->createSet(''); // Calls dieffeent methods on Debian6 and Debian7
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */

use BitNinja\Common\Messaging\Redis\RedisClientManager;
use BitNinja\Framework\ContainerInstance;
use BitNinja\Framework\RPC\Exception\RequestTimeout;
use Clue\React\Redis\RedisClient;
use React\EventLoop\LoopInterface;
use React\Promise\Deferred;
use React\Promise\PromiseInterface;
use Rx\Observable;

use function React\Promise\all;
use function React\Promise\reject;

class BlueCommandExec extends BlueBaseCommand
{

    /** @var string */
    private $module = "";

    /** @var string */
    private $command;

    /** @var RedisClientManager */
    private $redisClientManager;

    /** @var int */
    private $messageTtl;

    /** @var LoopInterface */
    private $loop;

    /** @var string */
    private $node;

    /** @var array */
    private $args;

    /** 
     * Contains command names that should not be sent via pub/sub channels.
     * These commands are persisted only and won't have any TTL.
     * 
     * @var array 
     * */
    private $publishBlacklist = [
        "NewIncidentCommand"
    ];

    public function __construct()
    {
        parent::__construct();
        $container = ContainerInstance::getInstance()->getContainer();

        $this->redisClientManager = $container['redis_client'];
        $this->messageTtl = $container['config_manager']->getIntKey('general', 'message_ttl', 60);
        $this->loop = $container[LoopInterface::class];

        $args = func_get_args();
        call_user_func_array([
            $this,
            'setupCommand'
        ], $args);
    }

    public function setupCommand()
    {
        $args = func_get_args();

        if (count($args) < 2) {
            $this->log->error('BlueCommandExec needs at least 2 arguments');
            $this->log->backtrace();
        }

        $this->command = $args[0];
        $this->node = $args[1];
        if (strpos($args[1], '.') !== false) {
            list($this->node, $this->module) = explode('.', $args[1]);
        }
        // Double shift args to remove first 2 element (command class and server)
        array_shift($args);
        array_shift($args);
        $this->args = $args;
    }

    private function findCommandClassName(string $command)
    {
        $moduleName = $this->getModuleName();
        $className = '\\' . $command . 'Command';
        if (isset($moduleName)) {
            $tryClass = '\\BitNinja\\' . $this->getModuleName() . $className;
            if (class_exists($tryClass)) {
                return $tryClass;
            }
            $tryClass = '\\BitNinja\\modules\\' . $this->getModuleName() . '\\commands' . $className;
            if (class_exists($tryClass)) {
                return $tryClass;
            }
            $tryClass = '\\BitNinja\\Framework\\commands' . $className;
            if (class_exists($tryClass)) {
                return $tryClass;
            }
            if (class_exists($className)) {
                return $className;
            }
        }

        return $className;
    }

    /**
     * Example usage:
     * ```
     * $cmd = new \BlueCommandExec("CheckFile", "local.MalwareDetection", "/tmp/some_file");
     * $cmd->RpcModuleCall(30)->then(function ($result) {
     *     echo json_encode($response, JSON_PRETTY_PRINT);
     * })->catch(function (\Throwable $e) {
     *     echo "\nError: " . $e->getMessage();
     * });
     * ```
     *
     * @param integer $timeout
     * @return PromiseInterface
     */
    public function rpcModuleCall(int $timeout = 30): PromiseInterface
    {
        $className = $this->findCommandClassName($this->command);
        $this->log->info('Executing module [' . $this->getModuleName() . '] RPC command class [' . $className . '] locally.');
        $commandId = uniqid();

        $deferred = new Deferred();
        $waitingTimeMs = 0;
        $waitTimer = $this->loop->addPeriodicTimer(.1, function () use (&$waitingTimeMs, &$waitTimer, $commandId, $timeout, $className, $deferred) {
            $responseKey = "Response_" . $commandId;
            if ($this->getRedisClient() == null) {
                $deferred->reject(new \Exception("Redis client is not available"));
                return;
            }
            $this->getRedisClient()->get($responseKey)
                ->then(
                    function ($response) use (&$waitingTimeMs, &$waitTimer, $responseKey, $timeout, $className, $deferred) {
                        if ($response) {
                            $this->getRedisClient()->del($responseKey);
                            $deferred->resolve($this->decodeRpcResponse($response));
                            $this->loop->cancelTimer($waitTimer);
                        } else {
                            if ($waitingTimeMs / 1000 > $timeout) {
                                $deferred->reject(new RequestTimeout("RPC Command [$className] timed out after [$timeout] seconds."));
                                $this->loop->cancelTimer($waitTimer);
                            }
                            $waitingTimeMs += 100;
                        }
                    }
                )->catch(function ($err) use (&$waitTimer, $deferred) {
                    $deferred->reject($err);
                    $this->loop->cancelTimer($waitTimer);
                });
        });

        $this->sendCommand($className, $commandId, $this->args, $timeout, true, false, 0)
            ->then(
                null
            )->catch(function ($err) use ($waitTimer, $deferred) {
                $this->loop->cancelTimer($waitTimer);
                $this->handleCommandError($err);
                $deferred->reject($err);
            });

        return $deferred->promise();
    }

    private function getRedisClient(): ?RedisClient
    {
        return $this->redisClientManager->getRedisClient();
    }

    /**
     * Shorthand for `Observable::fromPromise(queue())`
     * 
     * @return Observable
     */
    public function fromQueue()
    {
        return Observable::fromPromise($this->queue());
    }

    /**
     * Shorthand for `Observable::fromPromise(rpcModuleCall($timeout))`
     * 
     * @return Observable
     */
    public function fromRpcModuleCall(int $timeout = 30)
    {
        return Observable::fromPromise($this->rpcModuleCall($timeout));
    }

    /**
     * Shorthand for `Observable::fromPromise(rpcModuleCallWithRetries($timeout, $retries))`
     * 
     * @return Observable
     */
    public function fromRpcModuleCallWithRetries(int $timeout = 30, int $retries = 1)
    {
        return Observable::fromPromise($this->rpcModuleCallWithRetries($timeout, $retries));
    }

    /**
     * Same as `rpcModuleCall` but retries `$retries` times (doubling the timeout threshold each time) if the command timed out.
     * Returns a promise which resolves with `null` if the number of retries exceeds the threshold or if an unknown error occured,
     * otherwise the promise resolves with the actual response.
     * 
     * @param boolean $targetNamespaced
     * @param integer $timeout
     * @param integer $retries
     * @param string $nodeName
     * @throws Exception
     * @return mixed
     */
    public function rpcModuleCallWithRetries(int $timeout = 30, int $retries = 1)
    {
        return $this->rpcModuleCall($timeout)
            ->otherwise(function ($error) use ($timeout, $retries) {
                if ($error instanceof RequestTimeout) {
                    if ($retries <= 0) {
                        $this->log->error("Could not execute command [{$this->node}.{$this->command}] after multiple retries. Is the target module running?");
                    } else {
                        $this->log->warn("Could not execute command [{$this->node}.{$this->command}]. Communication with the target module has timed out.");
                        $this->log->warn("Retrying with a bigger timeout interval...");
                        return $this->rpcModuleCallWithRetries($timeout * 2, $retries - 1)
                            ->then(
                                function () {
                                    $this->log->info("Command [{$this->node}.{$this->command}] was successfully executed after retrying.");
                                }
                            )->catch(
                                function ($error) {
                                    $this->log->error("Could not execute command [{$this->node}.{$this->command}] after multiple retries. Is the target module running?");
                                    return reject($error);
                                }
                            );
                    }
                }
                return reject($error);
            });
    }

    /**
     * Send the command to the Redis queue of the
     * process of the appropriate module.
     *
     * @param boolean $targetNamespaced
     *            Is the target namespaced
     * @return PromiseInterface Promise which resolves with the error code of the message sending. 0 is ok, -1 can not perform operation.
     * If Redis is used, a promise is returned which resolves with an empty value.
     */
    public function queue(): PromiseInterface
    {
        if ($this->node != 'local') {
            return reject(new \Exception('Only local sending implemented! You sent  to [' . $this->node . ']'));
        }
        $className = $this->findCommandClassName($this->command);

        $this->log->info('Executing module [' . $this->getModuleName() . '] command class [' . $className . '] locally.');
        $commandId = uniqid();
        return $this->sendCommand($className, $commandId, $this->args, $this->messageTtl, false, false, 0)
            ->then(
                null
            )->catch(
                function ($err) {
                    $this->handleCommandError($err);
                    return reject($err);
                }
            );
    }

    /**
     * Start the command locally by istantiating the command
     * class and invoking the run method.
     *
     * @return mixed
     */
    public function start()
    {
        if ($this->node != 'local') {
            $this->log->warning('Only local sending is implemented.');
            return false;
        }
        $className = $this->findCommandClassName($this->command);
        $this->log->info('Executing module [' . $this->getModuleName() . '] command class [' . $className . '] locally.');

        $cmd = new $className();
        return call_user_func_array(array(
            $cmd,
            'run'
        ), $this->args);
    }

    private function decodeRpcResponse($response)
    {
        return json_decode($response, true);
    }

    private function sendCommand(string $className, string $commandId, $args, int $timeout, bool $shouldRespond = false, bool $sentByApi = false, int $retryAttempts = 0)
    {

        if ($this->getRedisClient() == null) {
            return reject(new RuntimeException("Redis client is not available"));
        }

        // Convert NewIncidentCommand calls to an RPUSH into the incident queue
        if (strpos($className, "NewIncidentCommand") !== false && count($args) > 0) {
            if ($shouldRespond === true) {
                $this->log->warn("NewIncidentCommand called via RPC. Response will be ignored.");
            }

            $args[0] = base64_encode($args[0]);
            return $this->getRedisClient()
                ->rpush("Incidents", $args[0])
                ->catch(function ($err) {
                    $this->log->error("Could not send incident to queue. Error was: " . $err->getMessage());
                });
        }

        $deferred = new Deferred();
        $moduleName = $this->getModuleName();
        $commandObject = ['classname' => $className, 'args' => $args, 'shouldRespond' => $shouldRespond, 'id' => $commandId, "sentByApi" => $sentByApi, "retryAttempts" => $retryAttempts, 'moduleName' => $moduleName];
        $payload = json_encode($commandObject);
        if ($payload === false) {
            $this->log->warn("Command encoding is possibly invalid: [$moduleName.$className]. Trying to send anyway...");
            $payload = json_encode($commandObject, JSON_INVALID_UTF8_IGNORE | JSON_INVALID_UTF8_SUBSTITUTE);
        }

        $persistOnly = false;
        foreach ($this->publishBlacklist as $blacklistedCommand) {
            if (strpos($className, $blacklistedCommand) !== false) {
                $persistOnly = true;
                break;
            }
        }

        $queueName = $moduleName . "_Request_" . $commandId;
        if ($persistOnly) {
            $this->persistCommand($queueName, $payload)
                ->then(
                    function () use ($deferred) {
                        $deferred->resolve(null);
                    }
                )->catch(function ($err) use ($deferred) {
                    $deferred->reject($err);
                });
        } else {
            $this->getRedisClient()
                ->publish($moduleName, $payload)
                ->then(
                    function ($numberOfClientsReceived) use ($payload, $timeout, $deferred, $queueName) {
                        if ($numberOfClientsReceived < 1) {
                            $this->persistCommand($queueName, $payload, $timeout)
                                ->then(
                                    function () use ($deferred) {
                                        $deferred->resolve(null);
                                    }
                                )->catch(function ($err) use ($deferred) {
                                    $deferred->reject($err);
                                });
                        } else {
                            $deferred->resolve(null);
                        }
                    }
                )->catch(function ($err) use ($deferred) {
                    $deferred->reject($err);
                });
        }
        return $deferred->promise();
    }

    /** @return PromiseInterface */
    private function persistCommand($queueName, $payload, $timeout = false)
    {
        if ($this->getRedisClient() == null) {
            $promises = [reject(new RuntimeException("Redis client is not available"))];
            return all($promises);
        }
        $promises = [$this->getRedisClient()->set($queueName, $payload)];
        if ($timeout !== false && is_numeric($timeout)) {
            $promises[] = $this->getRedisClient()->expire($queueName, $timeout);
        }

        return all($promises);
    }

    private function getModuleName(): ?string
    {
        return $this->module;
    }

    private function handleCommandError($error): void
    {
        $className = $this->findCommandClassName($this->command);
        $moduleName = $this->getModuleName();

        $message = "";
        if ($error instanceof Throwable) {
            $message = $error->getMessage();
        } else if (is_array($error)) {
            $message = implode(
                PHP_EOL,
                array_map(
                    function ($item) {
                        if ($item instanceof Throwable) {
                            return $item->getMessage();
                        }

                        return print_r($item, true);
                    },
                    $error
                )
            );
        } else {
            $message = print_r($error, true);
        }

        $this->log->error("Could not send command [$moduleName.$className]. Error was: $message");
    }
}
