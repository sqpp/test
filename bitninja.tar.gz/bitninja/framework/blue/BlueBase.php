<?php

/**
 * Szolgadd base class. For all functions
 * that could be useful in ohter classes.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueBase
{

    /**
     * When a fatal error occurs, we stop the script. Not that good implementation,
     * but raise awareness to correct the errors.
     * 
     * @param string $msg Error message
     * @return void
     */
    public function fatal_error($msg)
    {
        $this->log->error($msg);
        debug_print_backtrace();
        exit(-1);
    }

    /**
     * Returns a szolgadd answer array and logs the error.
     *
     * Usage: return $this->error('Failed to execute...');
     * 
     * @param string $msg
     * @return array
     */
    protected function error($msg)
    {
        $this->log->error($msg);
        return array(false, $msg);
    }

    /**
     * Returns a szolgadd answer array and logs it as info.
     *
     * Usage: return $this->success('Successfully executed...');
     * 
     * @param string $msg
     * @return array
     */
    protected function success($msg)
    {
        $this->log->info($msg);
        return array(true, $msg);
    }
}
