<?php

/**
 * Class to hold and handle results from BlueCmdBuilder
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueCmdResult implements JsonSerializable
{

    /**
     * Array of result lines
     * @var array
     */
    private $result;

    /**
     * Return value of a command. 0 on success
     * @var int
     */
    private $return_var;

    /**
     * Those severity level log rows will not going to be split.
     *
     * @var array
     */
    protected $unsplitableLogSeverities = ['warn', 'error'];

    /**
     * Holds the Command builder which this result belongs to.
     *
     * @var BlueCmdBuilder
     */
    protected $command;

    /**
     * @param array $result
     * @param int $result_var
     */
    public function __construct($result, $return_var)
    {
        $this->result = $result;
        $this->return_var = $return_var;
    }
    /**
     * @param BlueCmdBuilder $command
     * @return void
     */
    public function setCommand(\BlueCmdBuilder $command)
    {
        $this->command = clone $command;
    }

    /**
     * @return string
     */
    public function getCommand()
    {
        return $this->command;
    }
    /**
     * Return with the array of result lines.
     * 
     * @return array
     */
    public function getResult()
    {
        return $this->result;
    }

    /**
     * @return int
     */
    public function getReturnVar()
    {
        return $this->return_var;
    }

    /**
     * Returns the result as a string.
     */
    public function getResultAsString(): string
    {
        return substr($this, strpos($this, PHP_EOL) + 1);
    }

    public function resultContainsLine(string $line): bool
    {
        if (empty($this->getResult())) {
            return false;
        }

        foreach ($this->getResult() as $resultLine) {
            if (strpos($resultLine, $line) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Return true if the result is any empty string.
     * 
     * @return boolean
     */
    public function resultIsEmpty()
    {
        if (count($this->result) == 0) {
            return true;
        }

        if ($this->result[0] == '') {
            return true;
        }

        return false;
    }

    /**
     * Log the result in the given severity.
     * 
     * @param string $severity
     * @return void
     */
    public function log($severity = 'info')
    {
        $log = BlueLog::instance($this);
        $log->$severity($this->__toString());
    }

    /**
     * Log the result in the given severity. Every line is a new log entry.
     * 
     * @param string $severity
     * @param object $logInstace use $this for this value, for correct logging
     * @return void
     */
    public function logEveryLine($severity = 'info', $logInstace = null)
    {
        $log = BlueLog::instance((!is_null($logInstace) ? $logInstace : $this));

        // The following severities are kept intact to be able to recognize the context.
        if (in_array($severity, $this->unsplitableLogSeverities)) {
            $log->$severity(preg_replace('%\n%', ' || ', $this->__toString()));
        } else {
            foreach (explode("\n", $this->__toString()) as $str) {
                $log->$severity($str);
            }
        }
    }

    /**
     * @param int $line_number
     * @return string
     */
    public function getLine($line_number)
    {
        if (isset($this->result[$line_number])) {
            return trim($this->result[$line_number]);
        }
        return '';
    }

    /**
     * Return true if the first result line contains the given string
     * 
     * @param string $str
     * @return boolean
     */
    public function firstLineContains($str)
    {
        if (!isset($this->result[0])) {
            return false;
        }

        if (strpos($this->result[0], $str) === false) {
            return false;
        }
        return true;
    }

    /**
     * Return true if the result contains the given string
     * 
     * @param string $str
     * @return boolean
     */
    public function contains($str)
    {
        if (!is_array($this->result)) {
            return false;
        }

        foreach ($this->result as $line) {
            if (strpos($line, $str) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Return true if the result equal or greater the given string
     * 
     * @param string $str
     * @return boolean
     */
    public function equalOrGreater($str)
    {
        if (!is_array($this->result)) {
            return false;
        }

        foreach ($this->result as $line) {
            preg_match('/(\d+\.\d+(\.\d+)*)/', $line, $matches);
            if (version_compare($matches[1], $str, '>=')) {
               return true;
            }
        }

        return false;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        $res = 'Return value: [' . $this->getReturnVar() . ']' . "\n";
        foreach ($this->getResult() as $line) {
            $res .= $line . "\n";
        }
        return $res;
    }

    /**
     * @return boolean
     */
    public function isSuccessFull()
    {
        return !$this->return_var;
    }

    /**
     * Recursively filters an array of BlueCmdResult for failed commands.
     * Successful commands will be removed from the result.
     *
     * @param BlueCmdResult| BlueCmdResult[] $results
     * @return boolean| BlueCmdResult| BlueCmdResult[] false when the array not contains failed commands. Otherwise the original array without successful commands.
     */
    public static function filterFailCommands($results)
    {
        if ($results instanceof BlueCmdResult) {
            return $results->isSuccessFull() ? false : $results;
        }
        if (is_array($results)) {
            $filteredArray = [];
            foreach ($results as $key => $value) {
                $filteredvalue = BlueCmdResult::filterFailCommands($value);
                if ($filteredvalue) {
                    $filteredArray[$key] = $filteredvalue;
                }
            }
            return empty($filteredArray) ? false : $filteredArray;
        }
        return false;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return ['command' => $this->command, 'result' => $this->result, 'return_var' => $this->return_var];
    }
}
