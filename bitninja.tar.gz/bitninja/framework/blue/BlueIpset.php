<?php

/**
 *
 * Wrapper class of ipset linux command
 * The main reason of wrapping it to make it more
 * convenient use of ipset.
 *
 * $ipset = BlueIpset::instnace();
 * $ipset->createSet(''); // Calls dieffeent methods on Debian6 and Debian7
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueIpset extends BlueBaseCommand
{
    /**
     * @param boolean $log
     * @return void
     */
    public function __construct($log = false)
    {
        if ($log !== false) {
            $this->setLog($log);
            return;
        }
        $this->setLog(\BlueLog::instance($this));
    }

    /**
     * Change the logger
     * useful if you whant to use the caller classes logger.
     * eg.
     * $iptables = new BlueIptables($this->log);
     * 
     * @param string $log
     * @return void
     */
    public function setLog($log)
    {
        $this->log = $log;
    }

    /**
     * @param array $params
     * @param string $log
     * @return mixed
     */
    public static function execIpset($params, $log = null)
    {
        $cmd = new BlueCmdBuilder('ipset', $params, $log);
        return $cmd->execute();
    }

    /**
     * Create an ipset with the given name.
     * 
     * @param string $setName
     * @return mixed
     */
    public function create($setName)
    {
        $method = BlueIpSetVariantSelector::instance()->get();
        if ($method == 'default') {
            return self::execIpset(['create', $setName, 'hash:ip'], $this->log);
        }
        if ($method == 'OldIpSet') {
            return self::execIpset(['--create', $setName, 'iphash'], $this->log);
        }
    }

    /**
     * Remove an ip from the given set.
     *
     * @param string $setName
     * @param string $ip
     * @return mixed
     */
    public function removeIp($setName, $ip)
    {
        $method = BlueIpSetVariantSelector::instance()->get();
        if ($method == 'default') {
            return self::execIpset(['del', $setName, $ip], $this->log);
        }
        if ($method == 'OldIpSet') {
            return self::execIpset(['-D', $setName, $ip], $this->log);
        }
    }

    /**
     * Add an ip to a given set.
     * @param string $setName
     * @param string $ip
     * @return mixed
     */
    public function addIp($setName, $ip)
    {
        $method = BlueIpSetVariantSelector::instance()->get();
        if ($method == 'default') {
            return self::execIpset(['add', $setName, $ip], $this->log);
        }
        if ($method == 'OldIpSet') {
            return self::execIpset(['--add', $setName, $ip], $this->log);
        }
    }

    /**
     * Returns true if the given set exists. False if it does not exist.
     *
     * @param string $setName the name of the set
     * @return boolean true or false
     */
    public function setExists($setName)
    {
        $res = self::execIpset(['-T', $setName, '1'], $this->log);

        if ($res->firstLineContains('not exist')) {
            return false;
        }

        if ($res->firstLineContains('Unknown')) {
            return false;
        }

        return true;
    }

    /**
     * Destroye the given Ipset
     * in the case of old ipset format if the set is not found,
     * we iterate while we find ipsets like.
     * greylist --> greylist1, greylist2, greylsit3
     * if an iptales rule prevents the destroy, we try to find those rules
     * and remove them.
     *
     * @param $setName The ipset set name
     * @return mixed
     */
    public function destroy($setName)
    {
        $method = BlueIpSetVariantSelector::instance()->get();
        if ($method == 'default') {
            return  $this->_destroy($setName);
        }
        if ($method == 'OldIpSet') {
            if ($this->setExists($setName)) {
                return  $this->_destroy($setName);
            }
            // this set is stored as many set like greylist1, greylist2, greylist3, ...
            // itrerate and destroy all.
            for ($i = 0; $i < 255; $i++) {
                $this->_destroy($setName . $i);
            }
        }
    }

    /**
     * Destory the given set.
     * Returns false on error.
     *
     * @param string $setName
     * @return boolean
     */
    private function _destroy($setName)
    {
        if ($this->setExists($setName) == false) {
            return false;
        }

        $res = $this->_do_destroy($setName);

        if ($res == 0) {
            // Everything was fine.
            return true;
        }

        // if there was a problem of deleting the set
        // probably an iptables rule is uses it.
        if ($res == 1) {
            $this->log->debug('Ipset could not be deleted because an iptables rule is referenced! Trying to remove those iptables rules.');
            $ipt = new BlueIptables($this->log);
            $ipt->deleteAllRule('match-set ' . $setName);
            // Need some delay befor we try to delete ipsets again.
            sleep(1);
        }
        $res = $this->_do_destroy($setName);
        if ($res == 0) {
            return true;
        }
        // we still have problem deleting this ipset.
        $this->log->error('Ipset [' . $setName . '] could not be deleted.');
        return false;
    }

    /**
     * If the given IP is in the given set, returns true.
     * else returns false.
     *
     * @param string $setName
     * @param string $ip
     * @return boolean
     */
    public function isIpInSet($setName, $ip)
    {
        $method = BlueIpSetVariantSelector::instance()->get();

        if ($method == 'default') {
            $res = self::execIpset(['test', $setName, $ip]);
        }

        if ($method == 'OldIpSet') {
            $res = self::execIpset(['-T', $setName, $ip]);
        }

        if ($res->getReturnVar() == 0) {
            return true;
        }
        return false;
    }

    /**
     * @param string $setName
     * @return mixed
     */
    private function _do_destroy($setName)
    {
        $method = BlueIpSetVariantSelector::instance()->get();
        if ($method == 'default') {
            $res = self::execIpset(['destroy', $setName]);
        }

        if ($method == 'OldIpSet') {
            $res = self::execIpset(['--destroy', $setName]);
        }
        return $res->getReturnVar();
    }
}
