<?php

class CallableStub
{
    public function __invoke()
    {
    }
}
