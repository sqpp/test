<?php

/**
 * Resolvs an IP address and return the hostname of it.
 * Caches every query to offload nameserver usage on high load.
 *
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueHostResolver
{
    use TraitSingleton;

    /**
     * Hostanem cache indexed by ip addresses.
     *
     * @var array
     */
    private $hostnames;

    /**
     * Return with the reverse name of the given ip.
     *
     * @param string $ip
     * @return array
     */
    public function getHostByAddr($ip)
    {
        if (!isset($this->hostnames[$ip])) {
            $this->hostnames[$ip] = gethostbyaddr($ip);
        }
        return $this->hostnames[$ip];
    }
}
