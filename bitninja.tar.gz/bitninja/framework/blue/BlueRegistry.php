<?php

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 *
 */

class BlueRegistry
{
    use TraitSingleton;

    /**
     * @var array
     */
    private $registry = array();

    /**
     *
     * @return BlueRegistry
     *
    public function instance(){
        return self::instance();
    }*/

    /**
     * @param string $key
     * @param string $value
     * @return boolean
     */
    public function valueEquals($key, $value)
    {
        if (!$this->keyExists($key)) {
            //$this->log->debug('Key ['.$key.'] does not exists');
            $this->debug();
            return false;
        }

        if ($value == $this->get($key)) {
            //$this->log->debug('Value is equal');
            return true;
        }

        //$this->log->debug('Value does not match ['.$value.'] and ['.$this->get($key).']');
        return false;
    }

    /**
     * @return void
     */
    public function debug()
    {
        foreach ($this->registry as $key => $value) {
            $this->log->info($key.' =>['.print_r($value, true).']');
        }
    }

    /**
     * @param string $key
     * @return boolean
     */
    public function keyExists($key)
    {
        if (isset($this->registry[$key])) {
            return true;
        }
        return false;
    }

    /**
     * @param string $key
     * @throws BlueRegistrKeyNotSetException
     * @return string
     */
    public function get($key)
    {
        if (isset($this->registry[$key])) {
            return $this->registry[$key];
        }
        throw new BlueRegistrKeyNotSetException($key);
    }

    /**
     * @param string $key
     * @param string $value
     */
    public function set($key, $value)
    {
        $this->registry[$key] = $value;
    }
}
