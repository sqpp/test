<?php

/**
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueStringLib
{

    /**
     * Return true if the $haystack ends with $needle
     *
     * @param string $haystack
     * @param string $needle
     * @return boolean
     */
    public static function endsWith($haystack, $needle)
    {
        // search forward starting from end minus needle length characters
        return $needle === "" || (($temp = strlen($haystack) - strlen($needle)) >= 0 && strpos($haystack, $needle, $temp) !== false);
    }

    /**
     * Return true if the $haystack starts with $needle.
     *
     * @param string $haystack
     * @param string $needle
     * @return boolean
     */
    public static function startsWith($haystack, $needle)
    {
        // search backwards starting from haystack length characters from the end
        return $needle === "" || strrpos($haystack, $needle, -strlen($haystack)) !== false;
    }

    /**
     * Clears double whitespaces from a string.
     * examlpe
     * BlueExec::removeExtraWhitespaces('   a     b  ');
     * ' a b ';
     *
     * @param string $str
     * @return string
     */
    public static function removeExtraWhitespaces($str): string
    {
        return preg_replace('/\s+/', ' ', $str);
    }

    /**
     * Removes prefix of IPv4 mapped to IPv6 addresses.
     * This prefix looks something like: ::ffff: or 0:0:0:0:0:FFFF:
     *
     * @param string $ip
     * @return string trimmed address
     */
    public static function trimIpv4ToIpv6MappingPrefix($ip)
    {
        if (preg_match('/^([0:]+:ffff:)(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/i', trim($ip), $matches)) {
            return $matches[2];
        }
        return $ip;
    }

    /**
     * Translates a camel case string into a string with
     * underscores (e.g. firstName -> first_name)
     *
     * @param string $str String in camel case format
     * @return string $str Translated into underscore format
     */
    public static function fromCamelCase($str)
    {
        $str = lcfirst($str);
        return preg_replace_callback('/([A-Z])/', function ($match) {
            return '_' . strtolower($match[0]);
        }, $str);
    }

    /**
     * Translates a string with underscores
     * into camel case (e.g. first_name -> firstName)
     *
     * @param string $str                   String in underscore format
     * @param bool   $capitalise_first_char If true, capitalise the first char in $str
     * @return string $str translated into camel caps
     */
    public static function toCamelCase($str, $capitalise_first_char = false)
    {
        if ($capitalise_first_char) {
            $str = ucfirst($str);
        }

        return preg_replace_callback('/_([a-z])/', function ($match) {
            return strtoupper(substr($match[0], 1));
        }, $str);
    }
    /**
     * @param string $pattern
     * @return string
     */
    public static function convertGlobToRegex($pattern)
    {
        if (strpos($pattern, '^') === false && strpos($pattern, '$') == false) {
            //probably a glob pattern
            if (strpos($pattern, '*') !== false && strpos($pattern, '.*') === false) {
                $pattern = str_replace('*', '.*', $pattern);
            }
        }
        return $pattern;
    }
    /**
     * @param string $path
     * @return string
     */
    public static function convertRegexPatternToPosixRegex(string $path)
    {
        $posixBrackets = [
            '\\d' => '[[:digit:]]',
            '\\w' => '[[:word:]]',
            '\\s' => '[[:space:]]',
            '\\h' => '[[:blank:]]',
            '\\l' => '[[:lower:]]',
            '\\u' => '[[:upper:]]'
        ];
        foreach ($posixBrackets as $needle => $replacment) {
            if (strpos($path, $needle) !== false) {
                $path = str_replace($needle, $replacment, $path);
            }
        }
        return $path;
    }
}
