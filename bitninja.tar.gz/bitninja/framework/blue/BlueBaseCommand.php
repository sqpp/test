<?php

use BitNinja\Common\Messaging\CommandMessage;

/**
 * Base class to write every function in OO and have a nice, organized codebase.
 *
 * Contains a few base commands to make it easier to write nicer codes.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueBaseCommand extends BlueBase
{
    use \TraitOsHelper;
    use \TraitNetworkingHelper;
    /**
     * @var  BlueLog $log
     */
    protected $log;

    /**
     * @var CommandMessage
     */
    protected $command_message;


    /**
     * @return void
     */
    public function __construct()
    {
        $this->log = BlueLog::instance($this);
    }

    /**
     * Same as exec()
     * 
     * @param string $cmd
     * @return mixed
     */
    public function system($command)
    {
        $this->log->debug('    [# ' . $command . ']');
        return system($command);
    }

    /**
     * @param string $msg
     * @return void
     */
    public function setCommandMessage($cmd)
    {
        $this->command_message = $cmd;
    }

    /**
     * @return CommandMessage
     */
    public function getCommandMessage()
    {
        return $this->command_message;
    }
}
