<?php

use BitNinja\Framework\TraitCommandBuilder;

/**
 * Wrapper class of iptables linux command
 * The main reason of wrapping it to make it more
 * convenient use of iptables commands and make sure not to add
 * a rule twice and delete the rules easily.
 *
 * $ipt = new BlueIptabes($this->log);
 * $ipt->deleteRule('filter', 'HEIMDALL_IN', 'rule spec');
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueIptables
{
    use TraitCommandBuilder;

    public const RULE_COMMENT = "Rule added by Bitninja";

    /**
     * @var string
     */
    protected $table;
    /**
     * @var array
     */
    protected $tables = ['filter', 'nat', 'mangle'];
    /**
     * @var string
     */
    protected $iptables = 'iptables';
    /**
     * @var string
     */
    protected $log;

    /**
     * @var string
     */
    protected $commentString = '-m comment --comment "' . self::RULE_COMMENT . '"';

    const MANGLE = 'mangle';
    const NAT = 'nat';
    const FILTER = 'filter';
    const DROP = 'DROP';
    const RETURN = 'RETURN';
    const ACCEPT = 'ACCEPT';

    const FILTER_INPUT_CHAIN = 'INPUT';
    const FILTER_FORWARD_CHAIN = 'FORWARD';
    const FILTER_OUTPUT_CHAIN = 'OUTPUT';

    const NAT_PREROUTING_CHAIN = 'PREROUTING';
    const NAT_INPUT_CHAIN = 'INPUT';
    const NAT_OUTPUT_CHAIN = 'OUTPUT';
    const NAT_POSTROUTING_CHAIN = 'POSTROUTING';

    const MANGLE_PREROUTING_CHAIN = 'PREROUTING';
    const MANGLE_INPUT_CHAIN = 'INPUT';
    const MANGLE_FORWARD_CHAIN = 'FORWARD';
    const MANGLE_OUTPUT_CHAIN = 'OUTPUT';
    const MANGLE_POSTROUTING_CHAIN = 'POSTROUTING';

    /**
     * @param string $table
     * @return BlueCmdResult
     */
    public function listRulesInTable($table)
    {
        return $this->execIptablesKeepOringTable($table, ['-S']);
    }
    /**
     * @return string
     */
    public function getIptablesCommand()
    {
        return $this->iptables;
    }

    /**
     * @param string $iptables
     * @return void
     */
    public function setIptablesCommand($iptables)
    {
        $this->iptables = $iptables;
    }

    /**
     * @return string
     */
    public function getCommentString()
    {
        return $this->commentString;
    }

    /**
     * @return BlueIptables
     */
    public function changeToIp6Tables()
    {
        $this->iptables = 'ip6tables';
        return $this;
    }
    /**
     * @return BlueIptables
     */
    public function changeToIpTables()
    {
        $this->iptables = 'iptables';
        return $this;
    }

    /**
     * @param string $table
     * @param boolean $log
     * @param string $iptables
     * @return void
     */
    public function __construct($table, $log = false, $iptables = 'iptables')
    {
        if ($table instanceof \BlueLog) {
            $log = $table;
        } else {
            $this->table = $table;
        }
        if (in_array($iptables, ['iptables', 'ip6tables'])) {
            $this->iptables = $iptables;
        }
        if ($log !== false) {
            $this->setLog($log);
        } else {
            $this->setLog(BlueLog::instance($this));
        }
        $this->commandBuilder = new \BlueCmdBuilder();
        $this->commandBuilder->setLog($this->log);
    }

    /**
     * Change the logger
     * useful if you whant to use the caller classes logger.
     * eg.
     * $iptables = new BlueIptables($this->log);
     *
     * @param string $log
     * @return void
     */
    public function setLog($log)
    {
        $this->log = $log;
        return $this;
    }

    /**
     * @param string $table
     * @return BlueIptables
     */
    public function setTable($table)
    {
        $this->table = $table;
        return $this;
    }

    /**
     * Try to find a rules based on the given string
     *
     * @param string $str
     * @return array [
     *                  [
     *                     'table' => 'filter',
     *                     'chain' => 'INPUT',
     *                     'ruleno' => 2
     *                  ],
     *               ]
     */
    public function findRules($str)
    {
        $result = array();
        $originTable = $this->table;
        foreach ($this->tables as $table) {
            $this->setTable($table);
            $ipt_result = $this->execIptables([
                '--list', '--numeric', '--line-numbers',
                new BlueCmdBuilder('grep', ['-E', '(Chain|' . preg_quote($str) . ')'])
            ]);
            $chain = '';
            foreach ($ipt_result->getResult() as $line) {
                if (strpos($line, 'Chain') !== false) {
                    $arr = explode(' ', $line);
                    $chain = $arr[1];
                }
                if (strpos($line, $str)) {
                    $line = BlueStringLib::removeExtraWhitespaces($line);
                    $arr = explode(' ', $line);
                    if (is_numeric($arr[0])) {
                        $res['table'] = $table;
                        $res['chain'] = $chain;
                        $res['ruleno'] = $arr[0];
                        $res['line'] = $line;
                        $result[] = $res;
                    }
                }
            }
        }

        if (sizeof($result) > 0) {
            $this->log->trace("Rules found for search string [$str]: ");
            foreach ($result as $id => $rule) {
                $this->log->trace('  ' . $rule['table'] . ' ' . $rule['chain'] . ' ' . $rule['ruleno'] . ' [' . $rule['line'] . ']');
            }
        }
        $this->setTable($originTable);
        return $result;
    }

    /**
     * @param string $table
     * @param array $params
     * @return mixed
     */
    protected function execIptablesKeepOringTable($table, $params)
    {
        $orignTable = $this->table;
        $this->setTable($table);
        $res = $this->execIptables($params);
        $this->setTable($orignTable);
        return $res;
    }
    /**
     * Delete the rule specified by $rule.
     * $rule = array(
     *          'table' => 'filter',
     *          'chain' => 'INPUT',
     *          'ruleno' => 2)
     * @param array $rule
     * @return mixed
     */
    public function deleteRule($rule)
    {
        return $this->execIptablesKeepOringTable($rule['table'], ['--delete', $rule['chain'], $rule['ruleno']]);
    }

    /**
     * Execute the iptables command
     *
     * @param array $params
     * @param string $log
     * @return \BlueCmdResult
     */
    public function execIptables($params, $log = null)
    {
        $params2 = array_merge(['--table', $this->table, '-m', 'comment', '--comment', 'Rule added by Bitninja'], $params);
        return $this->runCommand($this->iptables, $params2);
    }

    /**
     * Deletes the given chain.
     *
     * @param string $chain
     * @return void
     */
    public function deleteChain($chain)
    {
        $this->execIptables(['--flush', $chain]);
        $this->execIptables(['--delete-chain', $chain]);
    }

    /**
     * Creates the given cahin.
     *
     * @param string $chain
     * @return void
     */
    public function createChain($chain)
    {
        $this->execIptables(['--new-chain', $chain]);
    }

    /**
     * Deletes all iptables rules wich contains the $str string.
     * Works on every table we ever used. (filter, nat, etc.)
     *
     * @param string $str
     * @return void
     */
    public function deleteAllRule($str)
    {
        $rules = $this->findRules($str);
        // reverse the array so we can delete by rule numbers
        // if we delete the original order, like 1, 2, 3, 4, than
        // we run out of numbers, in half way.
        $rules = array_reverse($rules);
        foreach ($rules as $rule) {
            $this->deleteRule($rule);
        }
    }

    /**
     * Removes all duplicated iptables rule.
     *
     * @return void
     */
    public function removeDuplicates()
    {
        $this->exec("/sbin/{$this->iptables}-save | /usr/bin/awk ' !x[$0]++' | /sbin/{$this->iptables}-restore");
    }

    /**
     * @param string $ruleString
     * @param string $chain
     * @return string
     */
    public function getRuleNumber($ruleString, $chain = '')
    {
        $iptablesCommandArray = [
            '--numeric',
            '--line-numbers',
            '--list',
        ];
        if ($chain != '') {
            $iptablesCommandArray[] = $chain;
        }
        $iptablesCommandArray[] = new BlueCmdBuilder('grep', [$ruleString]);
        $iptablesCommandArray[] = new BlueCmdBuilder('cut', [
            '-d', ' ',
            '-f1'
        ]);
        $res = $this->execIptables($iptablesCommandArray);
        return trim($res->getLine(0));
    }
    /**
     * @return string
     */
    public function getTable()
    {
        return $this->table;
    }

    /**
     * @return boolean
     */
    public function isIp6tables()
    {
        return $this->iptables == 'ip6tables';
    }

    /**
     *
     * @param string $table
     * @param string $chain
     * @return array|boolean
     */
    public function findNotBitNinjaRulesInTable(string $table, string $chain = null)
    {
        $params = ['-S'];
        if (!is_null($chain)) {
            $params[] = $chain;
        }
        $res = $this->execIptablesKeepOringTable($table, $params);
        $result = $res->getResult();
        if (!is_array($result)) {
            return false;
        }
        $notBitninjaRules = [];
        foreach ($result as $line) {
            if (strpos($line, self::RULE_COMMENT) !== false) {
                continue;
            }
            $notBitninjaRules[] = $line;
        }
        return $notBitninjaRules;
    }
}
