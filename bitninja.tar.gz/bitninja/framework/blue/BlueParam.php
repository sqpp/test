<?php

/**
 * Szolgadd CLI paramater handler class.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueParam
{

    /**
     * Stores the processed params.
     * @var array
     */
    private $options;

    /**
     * Using singleton design pattern.
     * 
     * @return void
     */
    private function __construct()
    {
        $this->log = BlueLog::instance('blue.blue.BlueParam');
        $short = 'h:' . // hostname required
                'n' .
                'c:' .
                'd';

        // The : is neccesary, because if we miss it, we cannot give value to them

        $long = array(
            'hostname:', // hostanme required
            'help', // help
            'nocolors', //
            'cron:', // run a cron
            'run:', // run a class, similar to cron
            'nodatabase', // run without database
            'p1:',
            'p2:',
            'p3:',
            'p4:',
            'daemonize',
        );
        $this->options = getopt($short, $long);

        // Options go to the $this->merged variable with their long name
        $this->merged = array();
        $parosok = array(
            'hostname' => 'h',
            'help' => 'help',
            'nocolors' => 'n',
            'cron' => 'c',
            'run' => 'r',
            'p1' => 'p1',
            'p2' => 'p2',
            'p3' => 'p3',
            'p4' => 'p4',
            'nodatabase' => 'nodatabase',
            'daemonize' => 'd',
        );

        foreach ($parosok as $hosszu => $rovid) {
            if (isset($this->options[$hosszu])) {
                $this->merged[$hosszu] = $this->options[$hosszu];
            }
            if (isset($this->options[$rovid])) {
                $this->merged[$hosszu] = $this->options[$rovid];
            }
        }
    }

    /**
     * Call this method to get singleton
     *
     * @return BlueParamHandler
     */
    public static function instance()
    {
        // Only instance of singleton
        static $inst;

        if ($inst === null) {
            $inst = new BlueParam();
        }
        return $inst;
    }

    /**
     * It the given index exixsts, the long name of the parameter exists true, if not, false
     *
     * @param string $name
     * @return boolean
     */
    public function hasParam($name)
    {
        if (isset($this->merged[$name])) {
            return true;
        }
        return false;
    }

    /**
     * Returns the parameter at the index of $name
     * 
     * @param string $name
     * @return mixed
     */
    public function get($name)
    {
        if ($this->hasParam($name)) {
            return $this->merged[$name];
        }
        return false;
    }
}
