<?php

/**
 * ErrorHandler to avoid errors, notices and others in the syslog.
 *
 * Usage example:
 *
 * BlueErrorHandler::register();
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueErrorHandler
{
    /**
     * @var boolean
     */
    protected static $develMode = false;
    /**
     * Register itself as an error handler
     * 
     * @param boolean $develMode
     * @return void
     */
    public static function register($develMode = false)
    {
        set_error_handler(array('BlueErrorHandler', 'errorHandler'));
        error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
        self::$develMode = $develMode;
    }

    /**
     * @param int $errno
     * @param string $errstr
     * @param string $errfile
     * @param int $errline
     * @return boolean
     */
    public static function errorHandler($errno, $errstr, $errfile, $errline)
    {
        $errReporting = true;
        // For @ operator
        if (error_reporting() === 0) {
            $errReporting = false;
        }
        $whitelisted = ['msg_send', 'fsockopen', 'Declaration of'];
        foreach ($whitelisted as $word) {
            if (strpos($errstr, $word) !== false) {
                return;
            }
        }

        // 2048 Declaration should be compatible notcie.
        if ($errno == 2048) {
            return;
        }
        $logLevel = 'error';
        if (!self::$develMode) {
            switch ($errno) {
                    //E_ERROR | E_WARNING | E_PARSE | E_NOTICE
                case E_USER_ERROR:
                case E_ERROR:
                case E_PARSE:
                    $logLevel = 'error';
                    break;
                case E_USER_WARNING:
                case E_WARNING:
                    $logLevel = 'warn';
                    break;
                case E_USER_NOTICE:
                case E_NOTICE:
                    $logLevel = 'debug';
                    break;
                default:
                    $logLevel = 'error';
            }
        }
        $log = BlueLog::instance('PHP');
        if ($errReporting === true) {
            $log->$logLevel($errno . ' ' . $errstr . ' ' . $errfile . ' ' . $errline);
        } else {
            $log->trace($errno . ' ' . $errstr . ' ' . $errfile . ' ' . $errline);
        }

        return true;
    }
}
