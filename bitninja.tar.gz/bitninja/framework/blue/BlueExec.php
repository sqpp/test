<?php

/**
 *
 * Wrapper class of exec and system php menthods.
 * The main reason of wrapping it to automate globally
 * the use of sudo, logging and others on command
 * executions.
 *
 * $ipset = BlueIpset::instnace();
 * $ipset->createSet(''); // Calls dieffeent methods on Debian6 and Debian7
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueExec
{
    use TraitSingleton;

    /**
     * @param string $cmd
     * @param string $result
     * @param string $return_var
     * @param boolean $log
     * @return void
     */
    public function _exec($cmd, &$result = null, &$return_var = null, $log = true)
    {
        $result = array();
        // Redirect stderr to stdout if we havent already did.
        if (strpos($cmd, '2>&1') === false) {
            $cmd .= ' 2>&1';
        }

        $result_log = false;
        $return_var_log = false;

        if ($log instanceof BlueLog) {
            $logger = $log;
        } elseif ($result instanceof BlueLog) {
            $logger = $result;
            $result_log = true;
        } elseif ($return_var instanceof BlueLog) {
            $logger = $return_var;
            $return_var_log = true;
        } else {
            $logger = $this->log;
        }

        if ($log) {
            $logger->debug($cmd);
        }

        if ($result_log) {
            exec($cmd);
        } elseif ($return_var_log) {
            exec($cmd, $result);
        } else {
            exec($cmd, $result, $return_var);
        }

        if ($return_var === 127 && $log) {
            $logger->warn('Binary could not be located [' . substr($cmd, 0, 256) . ']');
        }

        if (!$log) {
            return;
        }
        if (sizeof($result) !== 0) {
            $logger->trace('   Result:');
            foreach ($result as $line) {
                $logger->trace('   ' . $line);
            }
        }
    }

    /**
     * Call the exec method
     * preferred way to use
     * example: BlueExec::exec('/bin/echo hello');
     * 
     * @param string $cmd
     * @param string $result
     * @param string $return_var
     * @param boolean $log
     * @return void
     */
    public static function exec($cmd, &$result = null, &$return_var = null, $log = true)
    {
        BlueExec::instance()->_exec($cmd, $result, $return_var, $log);
    }

    /**
     * Clears double whitespaces from a string.
     * examlpe
     * BlueExec::removeExtraWhitespaces('   a     b  ');
     * ' a b ';
     *
     * @param string $str
     * @return string
     */
    public static function removeExtraWhitespaces($str): string
    {
        return BlueStringLib::removeExtraWhitespaces($str);
    }
}
