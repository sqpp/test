<?php

/**
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueIpSetVariantSelector
{
    use TraitSingleton;

    /**
     * @var boolean
     */
    private $variant = false;

    /**
     * @return String default | OldIpSet
     */
    public function get()
    {
        if ($this->variant !== false) {
            return $this->variant;
        }
        $selector = 'default';

        $cmd = new BlueCmdBuilder('ipset', ['help']);
        $res = $cmd->execute();
        if ($res->getReturnVar() != 0) {
            $selector = 'OldIpSet';
        }

        $this->log->info('Using [' . $selector . '] ipset functions.');
        $this->variant = $selector;
        return $this->variant;
    }

    /**
     * @return string
     */
    public function getMethod()
    {
        return 'run_' . $this->get();
    }

    /**
     * Hash an IP to a 0..99 interval.
     *
     * @param string $ip
     * @return int
     */
    public static function ipHash($ip)
    {
        list($ip1, $ip2, $ip3, $ip4) = explode('.', $ip);
        $sum = $ip1 + $ip2 + $ip3 + $ip4;
        return $sum % 100;
    }
}
