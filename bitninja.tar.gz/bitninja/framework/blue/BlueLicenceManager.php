<?php

use BitNinja\Framework\Api\V2\Adapter\AdapterInterface;
use BitNinja\Framework\Api\V2\DTO\LicenseAcquireRequestDTO;
use BitNinja\Framework\Api\V2\DTO\LicenseActivationRequestDTO;
use BitNinja\Framework\Api\V2\License\Acquire;
use BitNinja\Framework\Api\V2\License\Activate;
use BitNinja\Framework\ContainerInstance;
use GuzzleHttp\Exception\GuzzleException;

/**
 * Simple License manager, managing a Free and a nonFree mode.
 *
 * Usage:
 *
 * $license_manager = BlueLicenseManager::instance();
 * $license_manager->isFree()
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueLicenceManager
{
    use TraitSingleton;

    const SERVER_PROTECTION = 'server-protection';
    const VPS = 'vps';
    const CONTAINER_PROTECTION = 'container-protection';
    /**
     * The lincence in string format. (like free, trial, etc.)
     * @var string
     */
    private $license;

    /**
     * @var array
     */
    private $moduleRestrictions = [];

    /**
     * @var array
     */
    private $availableRestictedWorkerNames = [];

    /**
     * @var EnvironmentInfo
     */
    protected $environment;

    /**
     * @var string
     */
    protected $provisionKey;

    /**
     * @var string
     */
    protected $licenseKey;

    /**
     * @var string
     */
    protected $licenseType = self::SERVER_PROTECTION;

    /**
     * @var string
     */
    protected $licenseCreatedAt;

    /**
     * @var string
     */
    protected $sysname = 'bitninja';

    /**
     * @var int
     */
    protected $licenseAssociationId;

    /**
     * @var AdapterInterface
     */
    protected $guzzleClient;

    /**
     * @var string
     */
    protected $appId;

    /**
     * @var string
     */
    protected $hostname;

    /**
     * @var string
     */
    protected $container;

    /**
     * @var string
     */
    protected $licensev2File;
    /**
     * @var string
     */
    protected $etcDir;

    /**
     * @return void
     */
    public function onInit()
    {
        $this->container = ContainerInstance::getInstance()->getContainer();
        $this->licensev2File = $this->container['license_file'];
        $this->environment = $this->container['environment_info'];
        $this->etcDir = $this->container['etc_dir'];
        if ($this->environment->runningInDocker()) {
            $this->licenseType = self::CONTAINER_PROTECTION;
        }
    }

    /**
     * @param string $hostname
     * @return BlueLicenseManager
     */
    public function setHostName(string $hostname)
    {
        $this->hostname = $hostname;
        return $this;
    }

    /**
     * @param GuzzleClient $guzzleClient
     * @return BlueLicenseManager
     */
    public function setGuzzleClient($guzzleClient)
    {
        $this->guzzleClient = $guzzleClient;
        return $this;
    }

    /**
     * @param string $sysname
     * @return BlueLicenseManager
     */
    public function setSysname($sysname)
    {
        $this->sysname = $sysname;
        return $this;
    }

    /**
     * @param string $appId
     * @return BlueLicenseManager
     */
    public function setAppId(string $appId)
    {
        $this->appId = $appId;
        return $this;
    }
    /**
     * @return array
     */
    public function getAvailableRestictedWorkerNames()
    {
        if (!empty($this->moduleRestrictions) && empty($this->availableRestictedWorkerNames)) {
            foreach ($this->moduleRestrictions as $module) {
                $this->availableRestictedWorkerNames[] = 'Worker' . $module;
            }
        }
        return $this->availableRestictedWorkerNames;
    }

    /**
     * @param string $license
     * @return void
     */
    public function setLicence($license)
    {
        $this->log->info('License is set to [' . $license . ']');
        $this->license = $license;
    }

    /**
     * @return array
     */
    public function getModuleRestrictions()
    {
        return $this->moduleRestrictions;
    }

    /**
     * @param array $moduleRestrictions
     * @return void
     */
    public function setModuleRestrictions($moduleRestrictions)
    {
        $this->moduleRestrictions = $moduleRestrictions;
    }

    /**
     * @return string
     */
    public function getLicence()
    {
        return $this->license;
    }

    /**
     * If the license is a free version, it returns true.
     *
     * @return boolean
     */
    public function isFree()
    {
        if ($this->license == 'free') {
            return true;
        }
        return false;
    }

    /**
     * @return void
     */
    public function loadLicense()
    {
        try {
            $this->loadOldLicense();
            $this->loadLicenseV2();
        } catch (Exception $e) {
            $this->log->error('Error while loading license key');
            $this->log->error($e->getMessage());
            exit(1);
        }
    }
    /**
     * @throws RuntimeException
     * @return void
     */
    protected function loadOldLicense()
    {
        try {
            if (!is_file($this->etcDir . '/license.php')) {
                throw new RuntimeException('Provision key file missing from [' . $this->etcDir . '/license.php]');
            }
            $license = include $this->etcDir . '/license.php';
            if (!(isset($license['Heimdall']) && isset($license['Heimdall']['license_key']))) {
                throw new RuntimeException('Missing provision key');
            }
            $this->provisionKey = $license['Heimdall']['license_key'];
        } catch (Exception $e) {
            $this->log->error('Error while loading provision key');
            $this->log->error($e->getMessage());
        }
    }

    /**
     * @return void
     * @throws RuntimeException
     */
    protected function loadLicenseV2()
    {
        $licensePath = $this->etcDir . DIRECTORY_SEPARATOR . $this->licensev2File;
        if (!is_file($licensePath)) {
            $licenseKey = $this->acquireLicense();
            $this->saveLicense($licensePath, $this->licenseType, $licenseKey);
            $associationId = $this->activateLicense($licenseKey, $this->licenseType, $this->appId);
            $this->updateLicense($licensePath, 'associationId', $associationId);
        }

        if (is_file($licensePath)) {
            $license = json_decode(file_get_contents($licensePath), true);
            if (is_null($license)) {
                throw new RuntimeException('License file corrupted');
            }
            if (isset($license['type']) && !in_array($license['type'], [self::SERVER_PROTECTION, self::VPS, self::CONTAINER_PROTECTION])) {
                $this->updateLicense($licensePath, 'type', self::SERVER_PROTECTION);
                $license['type'] = self::SERVER_PROTECTION;
            }
            if (!$this->validateLicenseV2($license)) {
                throw new RuntimeException('Invalid license');
            }
            $this->licenseType = $license['type'];
            $this->licenseCreatedAt = $license['createdAt'];
            if (!isset($license['license'])) {
                unset($license['associationId']);
                $license['license'] = $this->acquireLicense();
                $this->updateLicense($licensePath, 'license', $license['license']);
            }
            if (!isset($license['associationId'])) {
                $license['associationId'] = $this->activateLicense($license['license'], $license['type'], $this->appId);
                $this->updateLicense($licensePath, 'associationId', $license['associationId']);
            }
            $this->licenseKey = $license['license'];
            $this->licenseAssociationId = $license['associationId'] ?? null;
        }
    }

    /**
     * @param string $licensePath
     * @param string $type
     * @param string $license
     * @return void
     */
    protected function saveLicense($licensePath, $type, $license)
    {
        file_put_contents($licensePath, json_encode([
            'type' => $type,
            'license' => $license,
            'createdAt' => gmdate("Y-m-d H:i:s"),
        ], JSON_PRETTY_PRINT));
    }

    /**
     * @param string $licensePath
     * @param string $field
     * @param string $value
     * @throws RuntimeException
     * @return void
     */
    protected function updateLicense($licensePath, $field, $value)
    {
        if (!in_array($field, ['license', 'type', 'associationId'])) {
            throw new RuntimeException('Tried to update invalid license field');
        }
        $originContent = json_decode(file_get_contents($licensePath), true);
        $originContent[$field] = $value;
        file_put_contents($licensePath, json_encode($originContent, JSON_PRETTY_PRINT));
    }

    /**
     * @throws RuntimeException
     * @return string
     */
    protected function acquireLicense()
    {
        try {
            $acquireLicense = new Acquire($this->guzzleClient);
            $res = $acquireLicense->post(new LicenseAcquireRequestDTO($this->provisionKey, $this->licenseType, $this->appId, $this->hostname));
            $response = json_decode($res->getBody(), true);
            if (isset($response['license']) && $this->validateLicenseKey($response['license'])) {
                return $response['license'];
            }
            if (isset($response['status']) && $response['status'] === false) {
                throw new RuntimeException(isset($response['message']) && is_string($response['message']) ? $response['message'] : 'Failed to acquire License');
            }
        } catch (GuzzleException $e) {
            $this->log->warn('Failed to access the API server. Retrying after 10 seconds.');
            ModuleWorker::static_pcntl_sleep(10);
            return $this->acquireLicense();
        } catch (RuntimeException $e) {
            throw $e;
        } catch (Exception $e) {
            $this->log->error('Failed to acquire License');
            $this->log->error($e->getMessage());
            throw $e;
        }
    }

    /**
     * @param string $license
     * @param string $licenseType
     * @param string $appid
     * @throws RuntimeException
     * @return mixed
     */
    protected function activateLicense($license, $licenseType, $appid)
    {
        try {
            $activateLicense = new Activate($this->guzzleClient);
            $res = $activateLicense->post(new LicenseActivationRequestDTO($license, $licenseType, $appid, $this->hostname));
            $response = json_decode($res->getBody(), true);
            if (isset($response['status']) && $response['status'] === false) {
                throw new RuntimeException(isset($response['message']) && is_string($response['message']) ? $response['message'] : 'Failed to activate License');
            }
            if (isset($response['status']) && $response['status'] === true) {
                if (!(isset($response['id']) && isset($response['id']['associationId']) && is_numeric($response['id']['associationId']))) {
                    throw new RuntimeException($response['message'] ?? 'Failed to activate License');
                }
                return $response['id']['associationId'];
            }
        } catch (GuzzleException $e) {
            $this->log->warn('Failed to access the API server. Retrying after 10 seconds.');
            ModuleWorker::static_pcntl_sleep(10);
            return $this->activateLicense($license, $licenseType, $appid);
        } catch (RuntimeException $e) {
            throw $e;
        } catch (Exception $e) {
            $this->log->error('Failed to acquire License');
            throw $e;
        }
    }

    /**
     * @param string $license
     * @return boolean
     */
    protected function validateLicenseV2($license)
    {
        if (!is_array($license)) {
            return false;
        }
        if (!isset($license['type']) || !in_array($license['type'], [self::SERVER_PROTECTION, self::VPS, self::CONTAINER_PROTECTION])) {
            return false;
        }
        if (!isset($license['createdAt'])) {
            return false;
        }
        if (isset($license['license']) && !$this->validateLicenseKey($license['license'])) {
            return false;
        }
        if (isset($license['associationId']) && !is_numeric($license['associationId'])) {
            return false;
        }
        if (isset($license['type']) && $license['type'] === self::CONTAINER_PROTECTION && !$this->environment->runningInDocker()) {
            return false;
        }
        return true;
    }

    /**
     * @param string $license
     * @return boolean
     */
    protected function validateLicenseKey($licenseKey)
    {
        return is_string($licenseKey);
    }

    /**
     * @return string
     */
    public function getProvisionKey()
    {
        return $this->provisionKey;
    }

    /**
     * @return string
     */
    public function getLicenseKey()
    {
        return $this->licenseKey;
    }

    /**
     * @return string
     */
    public function getLicenseType()
    {
        return $this->licenseType;
    }

    /**
     * @return boolean
     */
    public function isVPSLicense()
    {
        return $this->licenseType === self::VPS;
    }
}
