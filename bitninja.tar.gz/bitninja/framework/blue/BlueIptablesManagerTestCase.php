<?php
/**
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueIptablesManagerTestCase extends \BlueCodeceptionTestCase
{

    /**
     * @param array $methods
     * @return \BlueIptables
     */
    protected function getMockedIptablesManager($params,$output,$returnCode=0)
    {
        $output = is_array($output)?$output:explode("\n", $output);
        $willReturn = new \BlueCmdResult($output, $returnCode);
        $mock = $this->getMockBuilder(\BlueIptables::class)
        ->setMethods(['execIptables'])
        ->disableOriginalConstructor()
        ->getMock();
        $mock->expects($this->any())->
        method('execIptables')
        ->with($params)
        ->willReturn($willReturn);
        return $mock;
    }
    /**
     * @param array $methods
     * @return \BlueIptables
     */
    protected function getMockedIptablesManagerMultiCall($calls,$results)
    {
        $mock = $this->getMockBuilder(\BlueIptables::class)
        ->setMethods(['execIptables'])
        ->disableOriginalConstructor()
        ->getMock();
        for($i =0 ; $i <count($calls); $i++){
            $result = isset($results[$i])?$results[$i]:[[],0];
            $output = is_array($result[0])?$result[0]:explode("\n", $result[0]);
            $returnCode = isset($result[1])?$result[1]:0;
            $willReturn = new \BlueCmdResult($output, $returnCode);
//             codecept_debug($calls[$i]);
            $mock->expects($this->at($i))->
            method('execIptables')
            ->with($calls[$i])
            ->willReturn($willReturn);
        }
        return $mock;
    }


}