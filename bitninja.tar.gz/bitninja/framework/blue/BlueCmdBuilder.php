<?php

use BitNinja\Framework\ContainerInstance;
use React\ChildProcess\Process;
use React\EventLoop\LoopInterface;
use React\Promise\Deferred;
use React\Promise\PromiseInterface;

/**
 * A Class to build commands and execute them.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueCmdBuilder implements JsonSerializable
{
    use \TraitOsHelper;

    /** @var LoopInterface */
    private $loop;

    /**
     * The absolute path of the command to execute
     *
     * @var string
     */
    private $cmd;
    /**
     * The original command, tried to run. Useful when command not found in the PATH.
     *
     * @var string
     */
    protected $originalCmd;
    /**
     * The parameters as an array.
     *
     * @var array
     */
    private $params = array();

    /**
     * Holds a cache of the absolute path of commands
     *
     * @var array
     */
    public static $cmd_absolute_paths;

    /**
     * @var BlueLog
     */
    private $log;

    /**
     * This is a timeout param by second
     *
     * @var int
     */
    private $timeout;

    /**
     * Bash stdout save to file operator '>'
     *
     * @var string
     */
    const STDOUT_TO_FILE = '>';
    /**
     * Bash stdout append to file operator '>>'
     *
     * @var string
     */
    const STDOUT_TO_APPEND_FILE = '>>';

    /**
     * This array holds Bash operators currently allowed to use in unescapeded from.
     *
     * @var array
     */
    private $allowedOsOperations = [self::STDOUT_TO_FILE, self::STDOUT_TO_APPEND_FILE];
    /**
     * Stores the last executed command string
     *
     * @var string
     */
    protected $lastExecutedCmd = '';
    /**
     * @var string
     */
    protected static $locator;

    /**
     * @param string $cmd
     *            The command in sort format like ipset
     * @param array $params
     *            (optional) The params as an array or the log instance to use
     * @param BlueLog $log
     *            (optional) The log instance to use.
     */
    public function __construct($cmd = null, $params = null, $log = null)
    {
        $this->setupCommand($cmd, $params, $log);
        $this->loop = ContainerInstance::getInstance()->getContainer()[LoopInterface::class];
    }

    /**
     * This method setup Command Builder to execute a bash command.
     *
     * @param string $cmd
     *            The command in sort format like ipset if null nothing will happen
     * @param array $params
     *            (optional) The params as an array or the log instance to use
     * @param BlueLog $log
     *            (optional) The log instance to use.
     * @return void
     */
    public function setupCommand($cmd = null, $params = null, $log = null)
    {
        if (is_null($cmd)) {
            return;
        }
        if ($params instanceof BlueLog) {
            $this->log = $params;
        }

        if ($log instanceof BlueLog) {
            $this->log = $log;
        }

        if (is_array($params)) {
            $this->params = $params;
        }

        if ($this->log == null) {
            $this->log = BlueLog::instance($this);
        }

        $this->originalCmd = $cmd;
        $this->cmd = $this->locateCommand($cmd);

        $this->timeout = 0;
    }

    /**
     * @return int
     */
    public function getTimeout()
    {
        return $this->timeout;
    }

    /**
     * @param int $timeout
     * @return void
     */
    public function setTimeout($timeout)
    {
        $this->timeout = $timeout;
    }

    /**
     * @param string $param
     * @return void
     */
    public function addParam($param)
    {
        if (is_string($param)) {
            $this->params[] = trim($param);
        }

        if ($param instanceof BlueCmdBuilder) {
            $this->params[] = $param;
        }
    }

    /**
     * @return \BlueCmdResult
     */
    public function execute()
    {
        $this->lastExecutedCmd = $this->getCommandStr();
        $this->exec($this->getCommandStr(), $result, $return_var, $this->log);
        $res = new BlueCmdResult($result, $return_var);
        $res->setCommand($this);
        return $res;
    }

    /**
     * Executes the command asynchronously.
     * 
     * @return PromiseInterface A promise which resolves with a `BlueCmdResult` when the command execution is complete.
     */
    public function executeAsync($pollingInterval = 0.1)
    {
        $deferred = new Deferred();
        $process = new Process($this->getCommandStr());
        $out = [];

        $process->start($this->loop, $pollingInterval);
        $process->stdout->on("data", function ($chunk) use (&$out) {
            $out = array_merge($out, explode(PHP_EOL, $chunk));
        });

        $process->on("exit", function ($exitCode) use ($deferred, &$out) {
            // For consistency with `execute()`
            if (count($out) > 1 && last($out) === "") {
                array_pop($out);
            }

            $deferred->resolve(new BlueCmdResult($out, $exitCode));
        });

        return $deferred->promise();
    }

    /**
     * @return string
     */
    public function getCommandStr()
    {
        $commandStr = $this->cmd . ' ' . $this->getParamStr();
        $timeout = $this->getTimeout();
        if ($timeout > 0) {
            $commandStr = "timeout $timeout $commandStr";
        }

        return $commandStr;
    }

    public function getCommandStrWithRelativePath()
    {
        $commandStr = $this->getCommandStr();
        foreach (self::$cmd_absolute_paths as $relative => $absolute) {
            $commandStr = str_replace($absolute, $relative, $commandStr);
        }
        while (strpos($commandStr, '2>&1 2>&1') !== false) {
            $commandStr = str_replace('2>&1 2>&1', '2>&1', $commandStr);
        }
        return $commandStr;
    }
    /**
     * @return string
     */
    public function getParamStr()
    {
        $res = '';
        foreach ($this->params as $param) {
            if (in_array($param, $this->allowedOsOperations)) {
                $res .= " $param ";
                continue;
            }
            if (is_string($param)) {
                $res .= escapeshellarg($param) . ' ';
                continue;
            }
            if ($param instanceof BlueCmdBuilder) {
                $res .= ' 2>&1 |' . $param->getCommandStr();
            }
        }
        return $res . ' 2>&1';
    }

    /**
     * @param string $path
     * @return boolean
     */
    public function isExecutableFileAtPath($path)
    {
        return file_exists(realpath($path)) && is_file($path) && is_executable($path);
    }

    /**
     * Find the executable binary of a program and return the full path of it.
     *
     * @param string $cmd
     * @param boolean $logError should we log error, if no executable found
     * @return string
     */
    public function locateCommand($cmd, $logError = true)
    {
        //var_dump(getenv());
        if (isset(self::$cmd_absolute_paths[$cmd])) {
            return self::$cmd_absolute_paths[$cmd];
        }

        // To be able to run an executable which is not in the search path of which
        if ($this->isExecutableFileAtPath($cmd)) {
            self::$cmd_absolute_paths[$cmd] = realpath($cmd);
            return self::$cmd_absolute_paths[$cmd];
        }

        //$this->exec('/usr/bin/which ' . $cmd, $result, $res, false);
        $this->_locateCommand($cmd, $result, $res, false);
        if ($res != 0) {
            if ($logError) {
                $this->log->error('Cannot find executable for command [' . $cmd . ']');
            }
            return false;
        }
        $this->log->debug('Executables for command [' . $cmd . '] is set to [' . $result[0] . ']');
        self::$cmd_absolute_paths[$cmd] = $result[0];

        return $result[0];
    }
    protected function _locateCommand($cmd, &$result, &$res, $log)
    {
        if (is_null(self::$locator)) {
            self::$locator = $this->_findLocator();
        }
        $locator = self::$locator;
        return $this->$locator($cmd, $result, $res, $log);
    }
    protected function _findLocator()
    {
        $locatorResult = null;
        $locatorReturnVar = null;
        $this->exec('/usr/bin/which', $locatorResult, $locatorReturnVar, false);
        if ($locatorReturnVar !== 127) {
            return '_whichLocator';
        }
        $this->exec('/usr/bin/whereis', $locatorResult, $locatorReturnVar, false);
        if ($locatorReturnVar !== 127) {
            return '_whereisLocator';
        }
    }
    protected function _whichLocator($cmd, &$result, &$res, &$log)
    {
        return $this->exec('/usr/bin/which ' . $cmd, $result, $res, $log);
    }
    protected function _whereisLocator($cmd, &$result, &$res, &$log)
    {
        $ret = $this->exec('/usr/bin/whereis ' . $cmd, $result, $res, $log);
        $parts = explode(' ', $result[0] ?? '');
        if (count($parts) < 2) {
            $res = 1;
            return $ret;
        }
        $result = [$parts[1]];
        return $ret;
    }
    /**
     * Getter for log
     *
     * @return BlueLog
     */
    public function getLog()
    {
        return $this->log;
    }

    /**
     * Setter for log
     *
     * @param BlueLog $log
     * @return BlueCmdBuilder
     */
    public function setLog(BlueLog $log)
    {
        $this->log = $log;
        return $this;
    }

    /**
     * Getter for cmd
     *
     * @return string
     */
    public function getCmd()
    {
        return $this->cmd;
    }

    /**
     * Setter for cmd
     *
     * @param string $cmd
     * @return BlueCmdBuilder
     */
    public function setCmd($cmd)
    {
        $this->cmd = $cmd;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return ['originalCommand' => $this->originalCmd, 'params' => $this->params, 'commandString' => $this->getCommandStr()];
    }
}
