<?php

/**
 * Packaging the commands sent via RabbitMQ and HTTP
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   ÂŠ 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class CommandMessage
{
    /** @var string */
    private $cmd_class;

    /** @var string */
    private $cmd_method;

    /** @var array */
    private $params;

    /** @var string */
    private $sender_server;

    /** @var string */
    private $send_timestamp;

    /** @var ModuleWorker */
    private $worker;

    /** @var string */
    private $module_name;

    /**
     * @param string $cmd_class
     * @param array $params
     * @return void
     */
    public function __construct($cmd_class, $params)
    {
        $this->cmd_class = $cmd_class;
        $this->cmd_method = 'run';
        $this->params = $params;
        $this->sender_server = ServerDataProvider::getHostName();
        $this->send_timestamp = time();
    }

    /**
     * @return string
     */
    public function getCmdClass()
    {
        return $this->cmd_class;
    }

    /**
     * @return string
     */
    public function getCmdMethod()
    {
        return $this->cmd_method;
    }

    /**
     * @return array
     */
    public function getParams()
    {
        return $this->params;
    }

    /**
     * @return string
     */
    public function getSenderServer()
    {
        return $this->sender_server;
    }

    /**
     * @return string
     */
    public function getSendTimestamp()
    {
        return $this->send_timestamp;
    }

    /**
     * @return ModuleWorker
     */
    public function getWorker()
    {
        return $this->worker;
    }

    /**
     * @return ModuleWorker $worker
     * @return void
     */
    public function setWorker($worker)
    {
        $this->worker = $worker;
    }

    public function getModuleName(): string
    {
        return $this->module_name;
    }

    /**
     * @return mixed
     */
    public function invoke()
    {
        $class = $this->cmd_class;
        $method = $this->cmd_method;
        if (!(class_exists($class) && method_exists($class, $method))) {
            echo "Class or method not exists [$class::$method]\n";
            return false;
        }
        $obj = new $class();
        $obj->setCommandMessage($this);
        return call_user_func_array(array($obj, $method), $this->params);
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return '[' . $this->sender_server . '] ' . $this->cmd_class . '->' . $this->cmd_method . '(' . 'params)';
    }
}
