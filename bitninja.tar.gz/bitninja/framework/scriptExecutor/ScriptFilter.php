<?php

/**
 * Classes implementing this interfaace should be used to decide whether a
 * script should be ran.
 */
interface ScriptFilter
{
    /**
     * @param string $filename
     * @return void
     */
    public function filter($filename);
}
