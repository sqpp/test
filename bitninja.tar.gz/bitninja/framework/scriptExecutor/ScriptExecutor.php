<?php

/**
 * Classes implementing this interface are
 * responsible to execute a script given by filename
 */

interface ScriptExecutor
{

    /**
     * This function should run an executable.
     *
     * @param String   $filename The full path of the script to be ran
     * @param String[] $params   An array of parameters to be passed to the script
     * @throws RuntimeException if a condition (for example existance) is not met.
     * @return void
     */

    public function execute($filename, array $params = array());
}
