<?php

/**
 * Class to filter Scripts based on their file names.
 */
class FileNameScriptFilter implements ScriptFilter
{
    /**
     * @var array
     */
    private $patterns;
    
    /**
     * Constructor.
     *
     * @param String[] $patterns The filename must match with at least one of the
     *                           PCRE patterns in this array to avoid filtering.
     */
    public function __construct(array $patterns)
    {
        $this->patterns = $patterns;
    }

    /**
     * Rejects the file names (the name of the file, without the path)
     * which doesn't match with at least one of the patterns given in the constructor.
     * An invalid regex shouldn't match anything.
     *
     * @param String $filename
     * @return bool False if the filename matches at least one of the PCRE patterns
     * given in the constructor, true otherways.
     */
    public function filter($filename)
    {
        $pathlessFilename = pathinfo($filename, PATHINFO_FILENAME);
        foreach ($this->patterns as $pattern) {
            if (preg_match($pattern, $pathlessFilename)) {
                return false;
            }
        }
        return true;
    }
}
