<?php


/**
 * Decorator for ScriptExecutors, which can be used to apply ScriptFilters
 * to prevent running of specific scripts.
 *
 */
class FilteringScriptExecutorDecorator implements ScriptExecutor
{
    /**
     * @var ScriptExecutor
     */
    private $decorated;
    /**
     * @var array
     */
    private $filters;
    /**
     * @var object
     */
    private $log;


    /**
     * Constructor.
     *
     * @param ScriptExecutor $decorated The decorated instance
     * @param ScriptFilter[] $filters   The filters to be applied
     */
    public function __construct(ScriptExecutor $decorated, array $filters)
    {
        $this->decorated = $decorated;
        $this->filters = $filters;
        $this->log = BlueLog::instance($this);
    }

    /**
     * Prevents running the script if the filter method of
     * at least one the filters specified in the constructor returns true.
     *
     * @param String   $filename The filename to be passed to the decorated instance
     * @param String[] $params   The params to be passed to the decorated instance
     * @return void
     */
    public function execute($filename, array $params = array())
    {
        foreach ($this->filters as $filter) {
            if ($filter->filter($filename)) {
                $this->log->trace("$filename was filtered.");
                return;
            }
        }
        $this->decorated->execute($filename, $params);
    }
}
