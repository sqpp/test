<?php

/**
 * One of the classes implementing this interface should be used to
 * run every script/a part of the scripts in a directory, for example
 * after moving a file into quarantene in the MalwareDetection module
 * or after loading the sets in IpFilter.
 */

interface ScriptDirExecutor
{
    /**
     * @param string $directory
     * @param array $params
     * @return void
     */
    public function execute($directory, array $params = array());
}
