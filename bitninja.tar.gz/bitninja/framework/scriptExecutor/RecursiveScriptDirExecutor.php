<?php

/**
 * ScriptDirExecutor which traverses the specified directory recursively and
 * tries to run every file.
 */

class RecursiveScriptDirExecutor implements ScriptDirExecutor
{
    /**
     * @var ScriptExecutor
     */
    private $eggsecutor;
    /**
     * @var object
     */
    private $log;

    /**
     * @param ScriptExecutor $eggsecutor
     * @return void
     */
    public function __construct(ScriptExecutor $eggsecutor)
    {
        $this->eggsecutor = $eggsecutor;
        $this->log = BlueLog::instance($this);
    }

    /**
     * @param string $directory
     * @param array $params
     * @return boolean
     */
    public function execute($directory, array $params = array())
    {
        $scripts_dir = $directory;
        if (!is_dir($directory)) {
            return false;
        }
        try {
            $rit = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($scripts_dir),
                \RecursiveIteratorIterator::SELF_FIRST
            );
            foreach ($rit as $key => $file_info) {
                $this->log->trace("Running script: {$file_info->getFilename()}");
                $filename = $file_info->getPath() . DIRECTORY_SEPARATOR . $file_info->getFilename();
                try {
                    $this->eggsecutor->execute($filename, $params);
                } catch (RuntimeException $ex) {
                    $this->log->warn("There was an exception while trying to run " . $filename);
                    $this->log->warn("The error message was " . $ex->getMessage());
                }
            }
        } catch (\UnexpectedValueException $ex) {
            $this->log->error("Directory not found: " . $directory);
        }
    }
}
