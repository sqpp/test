<?php

use React\EventLoop\LoopInterface;

class ReactScriptExecutor implements ScriptExecutor
{
    /** @var LoopInterface */
    private $loop;

    public function __construct(LoopInterface $loop)
    {
        $this->loop = $loop;
    }

    public function execute($filename, array $params = array())
    {
        if (!file_exists($filename)) {
            throw new RuntimeException("Script file not found.");
        }
        if (!is_executable($filename)) {
            throw new RuntimeException("Script file was found but it is not executable.");
        }

        $process = new \React\ChildProcess\Process('exec ' . $filename . ' ' . implode(' ', $params));
        $process->start($this->loop);
    }
}