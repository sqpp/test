<?php

/**
 * ScriptExecutor using BlueCmdBuilder.
 */
class BlueCmdBuilderScriptExecutor implements ScriptExecutor
{

    /**
     * This function should be able to run any kind of script/binary which
     * 1) exists
     * 2) the owner has executable bit on it
     *
     * @param String $filename The full path of the script to be ran
     * @param String[] $params An array of parameters to be passed to the script
     * @throws RuntimeException if a condition (for example existance) is not met.
     * @return void
     *
     */
    public function execute($filename, array $params = array())
    {
        if (!file_exists($filename)) {
            throw new RuntimeException("Script file not found.");
        }
        if (!is_executable($filename)) {
            throw new RuntimeException("Script file was found but it is not executable.");
        }
        $commandBuilder = new BlueCmdBuilder($filename, $params);
        $commandBuilder->execute();
    }
}
