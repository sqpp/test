<?php

/**
 * A class that represents a module.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class Module
{

    /**
     * The name of the module
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $latest_migration;

    /**
     * If true this is a newly installed system. If false it is a system, installed before.
     * 
     * @var boolean
     */
    private $new_install;

    /**
     * If migrations should run at module time we should put migrations to another directory.
     *
     * @var string
     */
    private $migrationSubdir = '';

    /**
     * @param mixed $migrationSubdir
     * @return void
     */
    public function setMigrationSubdir($migrationSubdir)
    {
        $this->migrationSubdir = $migrationSubdir;
    }

    /**
     * @param string $name
     * @return void
     */
    public function __construct($name)
    {
        $this->name = $name;
        $this->log = BlueLog::instance($this);
    }

    /**
     * @return string
     */
    public function getWorkerClassName()
    {
        return 'Worker' . $this->name;
    }

    /**
     * Initialize module by loading the include.php if there is one,
     * and registers the module main directory along with commands and
     * lib directory as a search path. At the same time loads all dependent
     * modules. Module dependency can be set in the config.ini file of
     * the module directory.
     *
     * @return void
     */
    public function init()
    {
        // Initialize module level configuration
        ModuleConfigManager::instance()->setModuleName($this->name);
        ModuleConfigManager::instance()->onInit();

        $config = ModuleConfigManager::instance()->getConfig('module');

        if (isset($config['depends']) && is_array($config['depends'])) {
            foreach ($config['depends'] as $depend_module) {
                $conf = ModuleConfigManager::instance($depend_module)->getConfig('module');
                $this->module_include($depend_module, $conf);
            }
        }

        $this->module_include($this->name, $config);
    }

    /**
     * @param string $moduleName
     * @param boolean $config
     * @return void
     */
    private function module_include($moduleName, $config = false)
    {
        $autoloader = Autoloader::instance();
        $autoloader->addModulePath($moduleName);
        $autoloader->addModulePath($moduleName . '/commands');
        $autoloader->addModulePath($moduleName . '/lib');

        if (isset($config['includes'])) {
            foreach ($config['includes'] as $path) {
                $autoloader->addModulePath($moduleName . '/' . $path);
                // $this->log->trace('Log path added ['.$path.']');
            }
        }
    }

    /**
     * Returns the array of already executed migrations of this module.
     *
     * @return array Example array('s2013_01_01-1000_TestMigration');
     */
    public function getExecutedMigrations()
    {
        $config = ConfigManager::instance()->getConfig('general');
        $fname = $config['var_dir'] . '/' . $this->name . '.migration.list';
        if (!is_file($fname)) {
            return array();
        }
        $str = file_get_contents($fname);
        $this->executed_migrations = json_decode($str, true);
        if (!is_array($this->executed_migrations)) {
            $this->executed_migrations = array();
        }
        return $this->executed_migrations;
    }

    public function addExecutedMigration($migrationName)
    {
        $this->executed_migrations[] = $migrationName;
        $this->log->trace('ExecutedMigration added: [' . $migrationName . ']');
    }

    /**
     * Save the list of executed migrations.
     * 
     * @param $migratins array
     * @return void
     */
    public function saveExecutedMigrations()
    {
        if (!isset($this->executed_migrations)) {
            $this->executed_migrations = array();
        }
        $config = ConfigManager::instance()->getConfig('general');
        if (!is_dir($config['var_dir'])) {
            mkdir($config['var_dir'], 0700, true);
        }
        $fname = $config['var_dir'] . '/' . $this->name . '.migration.list';
        $this->log->trace(var_export($this->executed_migrations, true));
        asort($this->executed_migrations);
        $json = json_encode($this->executed_migrations, JSON_PRETTY_PRINT);
        $this->log->trace('SavedExecutedMigrations: ' . $json);
        file_put_contents($fname, $json);
    }

    /**
     * @return string
     */
    private function getMigrationsDir()
    {
        $modulePath = __DIR__ . '/../../modules/' . $this->name;

        return  $modulePath . ($this->migrationSubdir === '' ? '/migrations' : $this->migrationSubdir);
    }

    /**
     * @return void
     */
    public function migrateUp()
    {
        if (!is_dir($this->getMigrationsDir())) {
            $this->log->error('The /migrations directory is missing for module [' . $this->name . ']!');
            $this->new_install = true;
            return;
        }

        $executed = $this->getExecutedMigrations();
        // Get the list of migrations
        $migrations = $this->getMigrations();

        foreach ($migrations as $time => $name) {
            if (!in_array($name, $executed)) {
                $this->log->info('Migration starting. Created at: [' . date('Y-m-d H:i:s', $time) . '] Name: [' . $name . ']');
                $this->runMigration($name);
                $this->log->debug('[' . $name . '] migration finished.');
                $this->addExecutedMigration($name);
                $this->saveExecutedMigrations();
            }
        }
    }

    /**
     * @param string $class_name
     */
    private function runMigration($class_name)
    {
        include_once($this->getMigrationsDir() . '/' . $class_name . '.php');
        $migration = new $class_name();
        $migration->up();
        // Allitsuk vissza az aktualis konyvtarat a kezdo konyvtarunkra.
        chdir(ConfigManager::instance()->getBaseDir());
    }

    /**
     * Return migrations in an array sorted by migration timestamp.
     * If this is a new install, we skip every update migration.
     * 
     * @return array
     */
    private function getMigrations()
    {
        $migrations = array();
        $files = scandir($this->getMigrationsDir());
        foreach ($files as $file) {
            if (strpos($file, '.php') !== false) {
                list($date, $time, $desc) = explode('_', $file, 3);
                $year = (int) substr($date, 1, 4);
                $month = (int) substr($date, 5, 2);
                $day = (int) substr($date, 7, 2);
                $hour = (int) substr($time, 0, 2);
                $minute = (int) substr($time, 2, 2);
                $timestamp = mktime($hour, $minute, 0, $month, $day, $year);
                $classname = str_replace('.php', '', $file);
                // Drop update migrations in case of new installation
                if ($this->new_install && ($classname[0] == 'u')) {
                    $this->addExecutedMigration($name);
                    continue;
                }
                $migrations[$timestamp] = $classname;
            }
        }
        asort($migrations);
        return $migrations;
    }
}
