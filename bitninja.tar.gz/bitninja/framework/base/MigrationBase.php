<?php

/**
 * This handles the autoload of the necessary files.
 * Usage:
 *
 * include('framework/base/Autoloader');
 *
 * It does the rest.
 * Important! The system expects the class name to be the same
 * as the .php file!
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class MigrationBase extends BlueBaseCommand
{
    /**
     * @return void
     */
    public function __construct()
    {
        $this->log = BlueLog::instance($this);
    }

    /**
     * Here you can provide the necessary commands for migration.
     * It is advised to use $this->exec() instead of plain exec() and
     * $this->system() instead of plain system(). But you should rely on $this->exec().
     * If something should be ran as root, use the $this->suexec() function.
     *
     * After the migration, the system goes back to the root directory, so in the migration codes
     * free feel to use the chdir() function.
     * The main functions was inherited from ASzolgaddBaseCommand, so everything that
     * the parent class has, can also be used here, such as tarhelyByUid, tarhelyByUsername etc.
     */
    public function up()
    {
    }

    public function down()
    {
    }
}
