<?php

use BitNinja\Framework\ContainerInstance;

/**
 * Global config manager class.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class ConfigManager extends AbstractConfigManager
{
    use TraitSingleton;

    protected $defaultConfigFile;
    /**
     * @return void
     */
    public function onInit()
    {
        $this->log = BlueLog::instance($this);
    }

    protected function loadDefaultConfig()
    {
        if (isset($this->remoteConfig)) {
            $this->config = $this->remoteConfig;
            return;
        }
        if (isset($this->cloudConfig)) {
            return;
        }
        $this->setLicenseManager(ContainerInstance::instance()->getContainer()['license_manager']);
        $this->parseConfig($this->defaultConfigFile);
    }
    public function setDefaultConfigFile($configFile)
    {
        $this->defaultConfigFile = $configFile;
    }

    /**
     * Static function to get the BaseDir.
     *
     * @return string
     */
    public function getBaseDir()
    {
        $config = $this->getConfig('general');
        return $config['base_dir'];
    }

    /**
     * Function to get the var directory of the Agent or the module.
     *
     * @param string $module
     * @return string Path of the var dir. Like: /var/lib/bitninja/<module>/
     */
    public function getVarDir($module = '')
    {
        $config = $this->getConfig('general', false);
        if (!isset($config['var_dir'])) {
            return str_replace('/', DIRECTORY_SEPARATOR, '/var/lib/bitninja/');
        }
        $varDir = $module != '' && is_dir($config['var_dir'] . DIRECTORY_SEPARATOR . $module) ?
            $config['var_dir'] . DIRECTORY_SEPARATOR . $module . DIRECTORY_SEPARATOR :
            $config['var_dir'] . DIRECTORY_SEPARATOR;
        return $varDir;
    }
    /**
     * @return string Default is /var/lib/bitninja/tmp/
     */
    public function getAgentTmpPath()
    {
        return $this->getVarDir() . 'tmp' . DIRECTORY_SEPARATOR;
    }

    /**
     * Returns the code directory of all or just a specific module
     *
     * @param string $module
     * @return string
     */
    public function getModuleDir($module = '')
    {
        $config = $this->getConfig('general');
        $baseDir = $module != '' && is_dir($config['base_dir'] . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . $module) ? $config['base_dir'] . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . $module . DIRECTORY_SEPARATOR : $config['base_dir'] . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR;
        return $baseDir;
    }

    /**
     * Returns the names of the available modules
     *
     * @return array
     */
    public function getAvailableModules()
    {
        $moduleDir = $this->getModuleDir();
        $moduleDirectories = array_map('basename', glob($moduleDir . '*', GLOB_ONLYDIR));
        $excludedDirs = ['pre_HoneypotGeneral', 'pre_ModuleTemplate'];
        foreach ($excludedDirs as $dir) {
            $index = array_search($dir, $moduleDirectories);
            if ($index !== false) {
                unset($moduleDirectories[$index]);
            }
        }
        return $moduleDirectories;
    }

    /**
     * This method will drop every loaded configuration, and reloads them from the file system.
     * @return void
     */
    public function reInit()
    {
        $this->config = $this->cloudConfig;
        $etcDir = ContainerInstance::instance()->getContainer()['etc_dir'];
        foreach ($this->parsedConfigs as $path => $config) {
            if (!empty($this->cloudConfig) && !empty($this->remoteConfig) && strpos($path, $etcDir) === false) {
                continue;
            }
            $this->parseConfig($config);
        }
    }
}
