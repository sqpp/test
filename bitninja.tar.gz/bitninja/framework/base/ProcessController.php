<?php

/**
 * The Blue framework opens a new process for every bigger tasks
 * with the pcntl_fork. This class handles the forking.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */

// declare(ticks = 100);

use BitNinja\Common\Cgroup\Cgroup;
use BitNinja\Common\Messaging\CommandMessage;
use BitNinja\Common\Messaging\Redis\RedisMessageQueue;
use BitNinja\Common\Module\Contract\IWorker;
use BitNinja\Common\ServiceManager\DispatcherManager;
use BitNinja\Common\ServiceManager\RedisManager;
use BitNinja\Common\Util\ProcessManager;
use BitNinja\Framework\ContainerInstance;
use BitNinja\Framework\TraitCommandBuilder;
use React\EventLoop\LoopInterface;
use React\Promise\PromiseInterface;

use function React\Promise\all;
use function React\Promise\resolve;

class ProcessController implements IWorker
{
    use TraitCommandBuilder;

    /**
     * @var boolean
     */
    private $i_am_child = false;

    /**
     * @var boolean
     */
    private $shutting_down = false;

    /**
     * @var ModuleWorker
     */
    private $module = null;

    /**
     * @var int The time of the last sent message (Unix timestamp)
     */
    private $last_message_sent = array();

    /**
     * @var array Array of process handler names $class => $pid
     */
    private $handler_names = [];

    /**
     * @var array Array of process pids $pid => $class
     */
    private $handler_pids = [];

    /**
     * @var array
     */
    protected $crashCounter = [];

    /**
     * @var object
     */
    private $container;

    /**
     * @var ProcessResolver
     */
    protected $resolver;

    /**
     * @var string
     */
    protected $channel;

    /**
     * @var BlueLog
     */
    public $log;
    /**
     * @var LoopInterface
     */
    protected $loop;

    protected $delayBetweenZombieProcessKills = 10;

    /** @var RedisMessageQueue */
    private $messageQueue;

    /** @var int */
    private $messagePullLimit = 20;

    /** @var DispatcherManager */
    private $dispatcherManager;

    /** @var RedisManager */
    private $redisManager;

    /** @var ?array */
    private $handlers;

    /** @var BlueSystem */
    private $blue_sys;

    /** @var float */
    private $messagePollingTime;

    /** @var Cgroup */
    private $agentCgroup;

    /** @var ProcessManager */
    private $processManager;

    /** @var ProcessAnalysisManager */
    private $processAnalysisManager;

    /**
     * The to-be-run workers' class name should be provided
     * in the $handlers variable in array.
     * @param BlueSystem $blueSys
     * @param array $handlers Workers' class name
     * @return void
     */
    public function __construct(BlueSystem $blueSys, $handlers = null)
    {
        $this->container = ContainerInstance::getInstance()->getContainer();
        $this->processManager = $this->container['process_manager'];
        $this->log = BlueLog::instance('blue.base.ProcessController');
        $this->createMessageQueue(true);
        $this->messagePollingTime = $this->container['config_manager']->getKey('general', 'message_polling_time', 2);
        $this->messagePullLimit = $this->container['config_manager']->getKey('general', 'message_pull_limit', 20);
        $this->loop = $blueSys->getLoop();
        $this->blue_sys = $blueSys;
        $this->handlers = $handlers;
        $this->dispatcherManager = $this->container['dispatcher_manager'];
        $this->dispatcherManager->isRunning();
        $this->redisManager = $this->container['redis_manager'];
        $this->redisManager->isRunning();
        $this->processAnalysisManager = $this->container['process_analysis'];

        $this->registerSignals();
        $this->resolver = new ProcessResolver();

        $this->agentCgroup = new Cgroup();
        $cgroupPath = Cgroup::CGROUPFS_ROOT . DIRECTORY_SEPARATOR . "cpu,cpuacct";
        $cgroupName = "cpu/bitninja_main";
        if (is_dir($cgroupPath) && !is_dir(Cgroup::CGROUPFS_ROOT . DIRECTORY_SEPARATOR . "cpu")) {
            $cgroupName = "cpu,cpuacct/bitninja_main";
        }
        if ($this->agentCgroup->getVersion() == Cgroup::CGROUP_VERSION_V1) {
            $this->agentCgroup->setName($cgroupName);
        } else {
            $cgroupName = "bitninja_main";
            $this->agentCgroup->setName($cgroupName);
        }
    }

    public function getLoop(): LoopInterface
    {
        return $this->loop;
    }

    public function getLog(): BlueLog
    {
        return $this->log;
    }

    public function getAllModuleConfigurations(?string $expectModuleName = null)
    {
        $promises = [];
        $modules = ConfigManager::instance()->getAvailableModules();
        foreach ($modules as $module) {
            if ($module == $expectModuleName) {
                continue;
            }
            $promises[$module] = $this->getModuleConfiguration($module);
        }
        return all($promises);
    }

    public function getModuleConfiguration($moduleName)
    {
        $workerName = 'Worker' . $moduleName;
        if (!$this->checkIfModuleExists($moduleName) || !array_key_exists($workerName, $this->handler_names)) {
            return resolve(null);
        }

        $cmd = new \BlueCommandExec("GetModuleConfig", "local." . $moduleName);
        return $cmd->rpcModuleCall(10)
            ->then(
                function ($result) {
                    return $result;
                }
            )->catch(
                function (\Throwable $e) {
                    $this->log->error($e->getMessage());
                    return $e->getMessage();
                }
            );
    }


    public function processMessages()
    {
        $this->messageQueue->getMessages($this->messagePullLimit)
            ->then(
                function ($messages) {
                    if (empty($messages)) {
                        return;
                    }
                    $this->log->info("Processing [" . count($messages) . "] messages waiting in the queue.");
                    foreach ($messages as $message) {
                        $this->handleMessage($message);
                    }
                }
            );
    }

    private function handleMessage(CommandMessage $message): void
    {
        $this->messageQueue->acknowledgeMessage($message);
        $message->setWorker($this);
        $this->log->info("Received command [{$message->getCommandClass()}].");
        try {
            if ($message->shouldRespond()) {
                $result = $message->invoke();

                if ($result instanceof PromiseInterface) {
                    $result
                        ->then(
                            function ($response) use ($message) {
                                $this->messageQueue->respond($message->getId(), $response);
                            }
                        )->catch(
                            function (\Throwable $e) {
                                $this->log->error("Error: " . $e->getMessage());
                            }
                        );
                } else {
                    $this->messageQueue->respond($message->getId(), $result);
                }
            } else {
                $result = $message->invoke();
            }
        } catch (\Throwable $ex) {
            $this->log->warn($ex->getMessage());
        }
    }


    /**
     * @param int $delayBetweenZombieProcessKills
     * @return self
     */
    public function setDelayBetweenZombieProcessKills(int $delayBetweenZombieProcessKills)
    {
        $this->delayBetweenZombieProcessKills = $delayBetweenZombieProcessKills;
        return $this;
    }

    /**
     * @param string $moduleName
     * @return void
     */
    protected function increaseCrashCountForModule($moduleName)
    {
        $moduleName = str_replace('Worker', '', $moduleName);
        if (!isset($this->crashCounter[$moduleName])) {
            $this->crashCounter[$moduleName] = 0;
        }
        $this->crashCounter[$moduleName]++;
    }

    /**
     * @param string $moduleName
     * @return integer
     */
    protected function getCrashCountForModule($moduleName)
    {
        $moduleName = str_replace('Worker', '', $moduleName);
        return isset($this->crashCounter[$moduleName]) ? $this->crashCounter[$moduleName] : 0;
    }

    /**
     * Unfortunately, the PHP is not good at handling signals, the script
     * could be very slow because of it. When they correct this error, the
     * the signal handling should be re-enabled.
     *
     * @return void
     */
    private function registerSignals()
    {
        $this->log->info('Registering signal handlers..');
        pcntl_signal(SIGTERM, array(
            $this,
            "signal_handler"
        ));
        pcntl_signal(SIGINT, array(
            $this,
            "signal_handler"
        ));
        pcntl_signal(SIGHUP, array(
            $this,
            "signal_handler"
        ));
        pcntl_signal(SIGQUIT, array(
            $this,
            "signal_handler"
        ));
    }

    /**
     * Starts the given handlers.
     *
     * @return void
     */
    public function start()
    {

        // Kill all previous modules
        $this->killOrphanModules();
        // Start the different handlers
        // var_dump($this->handlers);
        $confDelay = ConfigManager::instance()->getKey('general', 'delay_between_forks');
        $delayBetweenForks = (is_numeric($confDelay) && $confDelay >= 0 ? $confDelay : 0);

        $this->setupCgroups(true);

        if ($this->handlers) {
            foreach ($this->handlers as $class) {
                if (!($this->_checkEnabled($class) && $this->_checkLicence($class))) {
                    continue;
                }
                $this->start_process($class);
                sleep($delayBetweenForks);
            }
            $this->log->info('All subprocess started.');
        }
    }

    /**
     * Find and kill any orphan modules of bitninja.
     *
     */
    public function killOrphanModules()
    {
        $procname = '\(bitninja \[\)';
        $mypid = posix_getpid();
        $this->log->debug('Checking for orphaned bitninja module processes.');
        $cmd = new BlueCmdBuilder('ps', [
            'wwxau',
            '--no-headers',
            new BlueCmdBuilder('grep', [
                $procname
            ]),
            new BlueCmdBuilder('grep', [
                '-vE',
                '(grep|root[[:space:]]+' . $mypid . '[[:space:]])'
            ])
        ]);
        $out = $cmd->execute();
        // BlueExec::exec('/bin/ps wwxau --no-headers | /bin/grep '.$procname, $out);
        // $out example
        // root 28070 0.0 0.1 19468 2092 pts/1 Ss+ Jul13 0:01 bash -rcfile .bashrc
        // root 29322 0.0 0.1 71292 3608 ? Ss 13:59 0:01 sshd: root@pts/4
        // root 29370 0.0 0.1 21004 3716 pts/4 Ss 14:00 0:00 -bash
        // echo $cmd->getCommandStr() . "\n";
        // echo $out;
        // exit;
        if (count($out->getResult()) == 0) {
            $this->log->debug('No orphaned module processes found.');
            return;
        }
        $this->log->info("There are orphaned zombie processes. Giving them {$this->delayBetweenZombieProcessKills} seconds to finish before killing them..");
        $this->log->debug($cmd->getCommandStr());
        sleep($this->delayBetweenZombieProcessKills);

        $out = $cmd->execute();
        if (count($out->getResult()) == 0) {
            $this->log->debug('No orphaned module processes found.');
            return;
        }

        $zombies = array();
        foreach ($out->getResult() as $line) {
            // /bin/grep is just the checker process itself.
            if (strpos($line, '/bin/grep') !== false) {
                continue;
            }

            // Under Rpm systems the init script starts inside a bash
            if (strpos($line, 'bash') !== false) {
                continue;
            }

            $line = BlueExec::removeExtraWhitespaces($line);
            $info = explode(' ', $line);
            $zombies[$info[1]] = $line;
        }
        $kills = [];
        if (count($zombies) > 0) {
            foreach ($zombies as $pid => $line) {
                if (!posix_getpgid($pid)) {
                    continue;
                }
                if ($pid == posix_getpid()) {
                    continue;
                }

                $this->log->warn('Killing zombie process: [' . $line . ']');
                posix_kill($pid, SIGTERM);
                $kills[] = $pid;
            }
        }
        if (count($kills) > 0) {
            sleep($this->delayBetweenZombieProcessKills);
            foreach ($kills as $pid) {
                if (!posix_getpgid($pid)) {
                    continue;
                }
                if ($pid == posix_getpid()) {
                    continue;
                }

                $this->log->warn('Killing zombie process: [' . $line . ']');
                posix_kill($pid, SIGKILL);
            }
        }
        // Kill defunct processess
        // [bitninja] <defunct>
        //
        // kill -HUP $(ps -A -ostat,ppid | grep -e '[zZ]'| awk '{ print $2 }')
        //
        // $cmd = new BlueCmdBuilder('ps', ['wwxau', '--no-headers',
        // new BlueCmdBuilder('grep', [$procname])]);
    }

    /**
     * Check for allowed modules.
     * Do not edit this code as
     * the communication with bitninja server is under monitor.
     * Altering the code will result disabling your account!
     *
     * @param string $class
     * @return boolean
     */
    private function _checkLicence($class)
    {
        $licence_manager = BlueLicenceManager::instance();
        $moduleRestrictions = $licence_manager->getModuleRestrictions();
        if (empty($moduleRestrictions)) {
            return true;
        }
        $allowed_modules = $licence_manager->getAvailableRestictedWorkerNames();
        if (in_array($class, $allowed_modules)) {
            return true;
        }
        $this->log->warning('Module [' . $class . '] hasn\'t been started because of ' . $licence_manager->getLicence() . ' licence.');
        return false;
    }

    private function _checkEnabled($class)
    {
        $config = ConfigManager::instance()->getConfig('general');
        if (!(is_array($config) && array_key_exists("disabledModules", $config))) {
            return true;
        }
        $moduleName = preg_replace("#^Worker#", "", $class);
        if (in_array($moduleName, $config["disabledModules"])) {
            $this->log->warning('Module [' . $moduleName . '] not started because of user configuration.');
            return false;
        }
        return true;
    }

    public function getModuleName(): string
    {
        $reflect = new ReflectionClass(get_called_class());
        return str_replace('Worker', '', $reflect->getShortName());
    }

    /**
     * Stops all sub process.
     *
     * @return void
     */
    private function stop_all()
    {
        $container = \BitNinja\Framework\ContainerInstance::instance()->getContainer();
        if ($this->i_am_child) {
            if ($this->module !== null) {
                // FIXME this results in errors during shutdown,
                // because we close the connection before
                // the modules do their cleanup logic.
                // NOTE: placing this after onStop won't solve the
                // problem because of the event loop :)
                // Does not cause any issues for now and
                // it would need a bigger refactor.
                //$this->module->onShutDown();
                $redisClientManager = $container['redis_client'];
                $redisClientManager->close();
                $this->module->onStop();
            }
            return;
        }
        $this->shutting_down = true;

        $this->log->info('Stopping all subprocesses ...');
        if ($this->handler_names) {
            foreach ($this->handler_names as $class => $pid) {
                $this->stop_process($class, $pid);
            }

            $this->processAnalysisManager->stopService();
            $this->dispatcherManager->stopService();
            $this->redisManager->stopService();

            $this->log->info('All subprocesses stopped.');
        }

        $this->log->info('BitNinja agent is going to stop.');
        $this->log->info('BitNinja has been deactivated.');
        /** @var string */
        $mainPidFilePath = $container['main_pid_file'];
        if (is_file($mainPidFilePath)) {
            unlink($mainPidFilePath);
        }
        exit(0);
    }

    /**
     * @param string $class
     * @param integer $pid
     */
    private function stop_process($class, $pid)
    {
        $this->log->info('Stopping process [' . $class . ':' . $pid . ']');
        unset($this->handler_names[$class]);
        unset($this->handler_pids[$pid]);
        posix_kill((int) $pid, SIGTERM);
        $this->agentCgroup->removePid($pid);
        $this->log->info('Stopped child process [' . $class . ':' . $pid . ']');
    }

    /**
     * Requires a Worker class. Forks a new process, instantiates
     * a Worker, reinitialize the mysql and memcache connections
     * and runs on the child process the Worker's loop() function.
     *
     * @param string $class
     * @return void
     */
    private function start_process($class, $cliCommand = false)
    {
        if (is_null($class)) {
            return;
        }
        $this->log->info('Starting process [' . $class . ']');
        $pid = pcntl_fork();

        if ($pid == -1) {
            $this->log->error('Fork error! Could not fork module [' . $class . ']');
            die('could not fork');
        }
        if ($pid) {
            // We are the PARENT
            $this->handler_names[$class] = $pid;
            $this->handler_pids[$pid] = $class;
            $this->agentCgroup->addPid($pid, true);
            try {
                $this->resolver->assign($pid, $class);
            } catch (\Exception $e) {
                $this->log->error($e->getMessage());
            }
            return;
        }
        // We are the CHILD
        $this->i_am_child = true;
        $this->loop->stop();
        $module_name = str_replace('Worker', '', $class);
        cli_set_process_title('bitninja [' . $module_name . ']');
        ContainerInstance::getInstance()->getContainer()['module_name'] = $module_name;
        $logErrorPath = $this->getErrorLogPath($module_name);
        if ($logErrorPath) {
            ini_set('error_log', $logErrorPath);
        }

        $api = HeimdallHttpApi::instance();
        $api->onInit();
        $this->log->reinit();
        $this->module = new $class();
        $this->module->onStart();

        $configManager = ModuleConfigManager::instance();
        $configManager->setModuleName($module_name);
        $configManager->setDefaultModuleName($module_name);
        $configManager->onInit();
        ModuleConfigManager::instance($module_name)->setRemoteConfig($configManager->getRemoteConfig());
        ModuleConfigManager::instance($module_name)->onInit();

        // Renice process according to module config
        $nice_level = $configManager->getKey('module', 'nice_level');
        if ($nice_level !== null) {
            $this->log->debug('Renice process to [' . $nice_level . ']');
            proc_nice($nice_level);
        }

        $this->log->info('Starting child process [' . $class . ']');
        $this->module->loop();
        exit(0);
    }

    public function getErrorLogPath($moduleName)
    {
        $dirName = ConfigManager::instance()->getKey('general', 'log_dir', '/var/log/bitninja');
        $snakeCaseModuleName = BlueStringLib::fromCamelCase($moduleName);
        return $dirName . DIRECTORY_SEPARATOR . 'mod.' . $snakeCaseModuleName . '.error.log';
    }

    /**
     * After every process have started, the monitor should be called.
     * This waits till any of the child processes dies.
     * After that happens, restart the given process, unless it was a
     * WorkerMail type Worker. In that case, kills all the child processes and shuts down
     * because of compatibility issues.
     *
     * @return void
     */
    public function monitor()
    {
        $this->addSafePeriodicTimer($this->messagePollingTime, function () {
            $this->processMessages();
        });

        $this->addSafePeriodicTimer(0.1, function () {
            pcntl_signal_dispatch();
        });
        $this->addSafePeriodicTimer(1, function () {
            $pid = 0;
            $pid = pcntl_wait($status, WNOHANG); // Protect against Zombie children
            if ($pid <= 0) {
                return;
            }
            if (!isset($this->handler_pids[$pid])) {
                return;
            }
            $class = $this->handler_pids[$pid];
            if (is_null($class)) {
                unset($this->handler_pids[$pid]);
                return;
            }
            $this->log_crash($class, $pid);
            $this->increaseCrashCountForModule($class);
            $this->start_process($class);
            if ($this->shutting_down) {
                exit(0);
            }
        });
        $this->loop->run();
    }

    /**
     * Logs if a process shuts down in an unexpected way.
     *
     * @param string $class
     * @return void
     */
    private function log_crash($class, $pid)
    {
        if (BlueSystem::instance()->isDevelMode()) {
            $this->log->warning('Not sending crash log because of devel mode.');
            return;
        }

        // Class is not resolved, fallback to the process resolver.
        if (empty($class)) {
            try {
                if ($this->resolver->exists($pid)) {
                    $class = $this->resolver->resolve($pid);
                    $this->log->warn('Process ID [' . $pid . '] was missing from the handler!');
                }
            } catch (\Exception $e) {
                $this->log->error($e->getMessage());
            }
        }

        // Still cannot resolve the class name.
        if (empty($class)) {
            $this->log->error('Process ID [' . $pid . '] could not be resolved!');
            return;
        }

        $this->log->error('The following process has stopped:[' . $class . ']');
        $this->sendCrashReportToNewApi($class);
        // It it is not in debug mode, send email to the back office, too.
        // if (!$this->blue_sys->isDevelMode()){
        if (!$this->isCrashReportSendable($class)) {
            $this->log->debug('Crash report not sent to prevent report flood.');
            return;
        }
        $config = ConfigManager::instance()->getConfig('general');

        $msg = "A module of the Blue framework has crashed.\n\n";
        $msg .= "Module's name: [" . $class . " \n";
        $msg .= "Time: [" . date('Y-m-d H:i:s') . "]\n";
        $msg .= "Server's name: [" . ServerDataProvider::getHostName() . "]\n\n";

        if (file_exists("/var/log/syslog")) {
            $msg .= $this->crash_log_chunk('Syslog last 100 lines', 'tail -n 100 /var/log/syslog');
        }
        // $msg.=$this->crash_log_chunk('The supervisor blue-stderr's last 50 rows', 'tail -n 50 /var/log/supervisor/blue-stderr*');
        $msg .= $this->crash_log_chunk('BitNinja logs', 'tail -n 100 /var/log/bitninja/*.log');
        $msg .= $this->crash_log_chunk('BitNinja Process Analysis logs', 'tail -n 100 /var/log/bitninja-process-analysis/*.log');
        $msg .= $this->crash_log_chunk('BitNinja Reliable Auto Update logs', 'tail -n 100 /var/log/bitninja-reliable-auto-update/*.log');
        $msg .= $this->crash_log_chunk('Messages log last 100 lines', 'tail -n 100 /var/log/messages');
        $msg .= $this->crash_log_chunk('Uname', 'uname -a');
        $msg .= $this->crash_log_chunk('Network interface configurations', 'ifconfig');
        $msg .= $this->crash_log_chunk('IpTables rules', 'iptables -L -n | head -n 100');
        $msg .= $this->crash_log_chunk('Iptables nat', 'iptables -t nat -L -n | head -n 100');
        $msg .= $this->crash_log_chunk('Iptables mangle', 'iptables -t mangle -L -n | head -n 100');
        $msg .= $this->crash_log_chunk('Ipset [heimdall-greylist] size', 'ipset -L heimdall-greylist| wc -l');
        $msg .= $this->crash_log_chunk('Ipset [heimdall-blacklist] size', 'ipset -L heimdall-nt-blacklist| wc -l');
        $msg .= $this->crash_log_chunk('Ipset [heimdall-essentiallist] size', 'ipset -L heimdall-essentiallist| wc -l');
        $msg .= $this->crash_log_chunk('BitNinja processes', 'ps axo user,pid,ppid,pcpu,pmem,vsz,rss,tty,stat,start,time,args| grep bitninja');

        $api = HeimdallHttpApi::instance();
        $api->request('crashReport', [
            'message' => $msg
        ], 'post');

        $this->log->info('Crash report has been sent to BitNinja Central.');

        $this->last_message_sent[$class] = time();
    }

    /**
     * @param string $module_name
     * @return void
     */
    private function sendCrashReportToNewApi($moduleName)
    {
        try {
            $serverEndpoint = $this->container['server_endpoint'];
            $crashReport = $this->container['empty_crash_report'];
            $crashReport->setModuleName($moduleName);
            $response = $serverEndpoint->sendReport($crashReport);
            $this->log->debug('CrasReport sent. Respose was [' . var_export(json_decode($response->getBody(), true), true) . ']');
        } catch (Exception $e) {
            $this->log->error('Caught exception when sending crash report to API. Message [' . $e->getMessage() . ']');
        }
    }

    /**
     * @param string $title
     * @param string $cmd
     */
    private function crash_log_chunk($title, $cmd)
    {
        $msg = $title . ":\n\n";
        $msg .= "-------------------------------------------------------------------\n";
        exec($cmd, $result, $exitcode);
        $msg .= "  " . implode("\n  ", $result) . "\n\n";
        $msg .= "-------------------------------------------------------------------\n";
        return $msg;
    }

    /**
     * Returns if it is possible to send crash report.
     *
     * @param string $class Module's name
     * @return boolean
     */
    private function isCrashReportSendable($class)
    {
        if (!isset($this->last_message_sent[$class])) {
            return true;
        }
        // orankent egy processzhez kuldheto
        if (time() - $this->last_message_sent[$class] >= 3600) {
            return true;
        }

        return false;
    }

    /**
     * Since the current version of PHP handles signals very poorly, it is out of order at the moment.
     *
     * @param int $signal
     * @return void
     */
    public function signal_handler($signal)
    {
        switch ($signal) {
            case SIGTERM:
                $this->log->info('Caught SIGTERM signal. Exiting.');
                $this->stop_all();
                break;
            case SIGINT:
                $this->log->info('Caught SIGINT signal. Exiting.');
                $this->stop_all();
                break;
            case SIGHUP:
                $this->log->error('Caught SIGHUP signal. Exiting.');
                $this->stop_all();
                break;
            case SIGQUIT:
                $this->log->error('Caught SIGQUIT signal. Exiting.');
                $this->stop_all();
                break;
            default:
                $this->log->error('Caught unknown signal [' . $signal . '].');
                return;
        }
        exit(0);
    }

    /**
     * @param string $module_name
     * @return boolean
     */
    protected function checkIfModuleExists($moduleName)
    {
        if ($moduleName === 'Cli') {
            return false;
        }

        $workerName = 'Worker' . $moduleName;
        if (class_exists($workerName)) {
            return true;
        }
        if (is_file('modules/' . $moduleName . '/' . $workerName . '.php')) {
            $mm = ModuleManager::instance();
            $mm->initModule($moduleName);
            if (class_exists($workerName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Starts a new process for the given module
     *
     * @param string $moduleName
     *            Name of the module that should start
     * @return boolean True on success
     */
    public function startProcess($moduleName)
    {
        $workerName = 'Worker' . $moduleName;
        if (!$this->checkIfModuleExists($moduleName)) {
            $this->log->warn('Module not found or Worker class is missing.');
            return false;
        }
        if (array_key_exists($workerName, $this->handler_names)) {
            $this->log->warn($moduleName . ' module already started yet. Not trying to start it.');
            return false;
        }
        if (!$this->_checkLicence($workerName)) {
            return false;
        }
        $this->log->info('Starting process [' . $moduleName . ']');
        $this->start_process($workerName);
        return true;
    }

    /**
     * Stops the given module process.
     *
     * @param string $moduleName
     *            Name of the module.
     * @return boolean True on success.
     */
    public function stopProcess($moduleName)
    {
        $workerName = 'Worker' . $moduleName;
        if (!$this->checkIfModuleExists($moduleName)) {
            $this->log->warn('Module not found or Worker class is missing.');
            return false;
        }
        if (!array_key_exists($workerName, $this->handler_names)) {
            $this->log->warn($moduleName . ' module not started yet. Not trying to stop it.');
            return false;
        }

        $this->stop_process($workerName, $this->handler_names[$workerName]);
        return true;
    }

    /**
     * @param string $module_name
     * @return array
     */
    public function getStatus($moduleName = null)
    {
        $promises = [];
        $modules = ConfigManager::instance()->getAvailableModules();
        if (!is_null($moduleName)) {
            $modules = [$moduleName];
        }
        foreach ($modules as $module) {
            $promises[$module] = $this->getModuleStatus($module);
        }
        return all($promises);
    }

    public function mqStop()
    {
        $this->redisManager->stopService();
    }

    public function mqStart()
    {
        $this->redisManager->startService(true);
    }

    public function dispatcherStop()
    {
        $this->dispatcherManager->stopService();
    }

    public function dispatcherStart()
    {
        $this->dispatcherManager->startService();
    }

    /**
     * Reload All configurations.
     *
     * It reloads the main process and all sub process configurations.
     *
     * @return boolean
     */
    public function reloadAllConfig()
    {
        $this->log->info('Reloading all configurations');
        ConfigManager::instance()->reInit();
        $modules = ConfigManager::instance()->getAvailableModules();
        foreach ($modules as $module) {
            $cmd = new \BlueCommandExec("RunModuleOption", "local." . $module, 'reload', "cli");
            $cmd->queue()->catch(function ($e) {
                $this->log->error($e->getMessage());
            });
        }
        return true;
    }
    /**
     * Reloads the main process configuration
     *
     * @return boolean
     */
    public function reloadConfigs()
    {
        $this->log->info('Reloading Main process configuration');
        ConfigManager::instance()->reInit();

        // Some options are used by the main process in System (Cloud Config workaround)
        ModuleConfigManager::instance('System')->reInit();
        $this->setupCgroups(true);
        return true;
    }
    /**
     * @param string $module_name
     * @param LoopInterface $loop
     */
    public function getModuleStatus($moduleName)
    {
        $status = [
            'module' => $moduleName,
            'running' => false,
            'crashCount' => $this->getCrashCountForModule($moduleName)
        ];
        $workerName = 'Worker' . $moduleName;
        if (!$this->checkIfModuleExists($moduleName) || !array_key_exists($workerName, $this->handler_names)) {
            return resolve(null);
        }

        $cmd = new \BlueCommandExec("Status", "local." . $moduleName, 'status', "cli");
        return $cmd->rpcModuleCall(5)
            ->then(
                function ($result) use ($status) {
                    $status = $result + $status;
                    $status['running'] = true;
                    return $status;
                }
            )->catch(
                function (\Throwable $e) use ($status) {
                    $status['error'] = $e->getMessage();
                    return $status;
                }
            );
    }

    /**
     * Stops and start the given module process.
     *
     * @param string $moduleName
     *            Name of the module
     * @return boolean True on success.
     */
    public function restartProcess($moduleName)
    {
        $this->stopProcess($moduleName);
        return $this->startProcess($moduleName);
    }

    /**
     * Set the value of container
     *
     * @param string
     * @return ProcessController
     */
    public function setContainer($container)
    {
        $this->container = $container;

        return $this;
    }

    public function stop()
    {
        $this->stop_all();
    }

    public function createMessageQueue($reconnect = false)
    {
        // Just to make sure this does not get called in any of the modules
        if ($this->i_am_child) {
            return;
        }

        if ($reconnect) {
            ContainerInstance::getInstance()->createRedisClient();
        }

        $this->messageQueue = $this->container['message_queue']("framework");
        $this->messageQueue->open();
        $this->log->info("|Framework| - Connected to the message queue.");
    }

    /**
     * Adds a subprocess safe periodic timer to the ProcessController.
     * The resulting timer kills itself if it gets called in any of the child processes.
     */
    public function addSafePeriodicTimer($interval, callable $cb): void
    {
        if (isset($this->loop)) {
            $this->loop->addPeriodicTimer($interval, function ($timer) use ($cb) {
                if ($this->i_am_child) {
                    $this->loop->cancelTimer($timer);
                } else {
                    $cb($timer);
                }
            });
        }
    }

    /**
     * Adds a subprocess safe single run timer to the ProcessController.
     * The resulting timer will not run if it gets called in any of the child processes.
     */
    public function addSafeTimer($interval, callable $cb): void
    {
        if (isset($this->loop)) {
            $this->loop->addTimer($interval, function ($timer) use ($cb) {
                if (!$this->i_am_child) {
                    $cb($timer);
                }
            });
        }
    }

    private function setupCgroupsV1()
    {
        $this->agentCgroup->setAttribute("cpu.cfs_period_us", Cgroup::DEFAULT_CPU_PERIOD_MICROSECONDS);

        $cpuLimitPercentage = ModuleConfigManager::instance('System')->getKey('resources', 'cpuUsageLimit', 100);
        if (!is_numeric($cpuLimitPercentage) || ((int)$cpuLimitPercentage) >= 100) {
            $this->log->info("CPU limit not set.");
            $this->agentCgroup->setAttribute("cpu.cfs_quota_us", -1);
        } else {
            $cpuLimitPercentage = (int)$cpuLimitPercentage;
            if ($cpuLimitPercentage < 20) {
                $this->log->warn("Invalid CPU limit set in config [$cpuLimitPercentage%]. Reverting to the minimal value.");
                $cpuLimitPercentage = 20;
            }

            $this->log->info("General CPU limit set to [" . ($cpuLimitPercentage) . "%].");
            $this->agentCgroup->setAttribute("cpu.cfs_quota_us", $cpuLimitPercentage * 100);
        }
    }

    private function setupCgroupsV2()
    {

        $this->agentCgroup->setExtraAttribute("cgroup.subtree_control", "cpu");
        $cpuLimitPercentage = ModuleConfigManager::instance('System')->getKey('resources', 'cpuUsageLimit', 100);
        if (!is_numeric($cpuLimitPercentage) || ((int)$cpuLimitPercentage) >= 100) {
            $this->log->info("CPU limit not set.");
        } else {
            $cpuLimitPercentage = (int)$cpuLimitPercentage;
            if ($cpuLimitPercentage < 20) {
                $this->log->warn("Invalid CPU limit set in config [$cpuLimitPercentage%]. Reverting to the minimal value.");
                $cpuLimitPercentage = 20;
            }

            $this->log->info("General CPU limit set to [" . ($cpuLimitPercentage) . "%].");
            $this->agentCgroup->setAttribute("cpu.max", ($cpuLimitPercentage * 100 * 100) . " 1000000");
        }
    }

    private function setupCgroups($save = false): void
    {
        if ($this->agentCgroup->getVersion() == Cgroup::CGROUP_VERSION_V1) {
            $this->setupCgroupsV1();
        } else {
            $this->setupCgroupsV2();
        }

        if ($save) {
            $this->saveCgroups();
        }
    }

    private function saveCgroups($processes = false): void
    {
        $name = $this->agentCgroup->getName();
        $this->log->info("Saving Cgroup [$name].");

        if ($this->agentCgroup->save(false, $processes) && $this->agentCgroup->isSaved(false, $processes)) {
            $this->log->info("Cgroup [$name] saved.");
            $inotifyPids = $this->processManager->getPidsByProcessName('inotifywait', false);
            if (!empty($inotifyPids)) {
                $this->agentCgroup->addPid($inotifyPids[0], true);
            }
        } else {
            $this->log->warn("Failed to save Cgroup [$name]. Resource limitations were not applied.");
        }
    }

    public function pingMessageQueue(): void
    {
        $this->messageQueue->ping()
            ->then(
                function ($res) {
                    if (!$res) {
                        $this->log->warn("Could not ping the message queue, trying to reconnect. Result was: " . print_r($res, true));
                        $this->createMessageQueue(true);
                    }
                },
            )->catch(
                function (\Throwable $e) {
                    $this->log->warn("Could not ping the message queue, trying to reconnect. Error was: " . $e->getMessage());
                    $this->createMessageQueue(true);
                }
            );
    }
}
