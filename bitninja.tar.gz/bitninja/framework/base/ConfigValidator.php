<?php

namespace BitNinja\Framework\base;


use Opis\JsonSchema\{Validator, Schema};

/**
 * @author Peter Saller <peter.saller@bitninja.io>
 * @copyright © 2023 BitNinja Inc.
 * @package BitNinja
 */

class ConfigValidator
{
    private $log;

    public function __construct($log)
    {
        $this->log = $log;
    }

    public function validateModuleConfig($config, $module): bool
    {
        $schemaPath = DIRECTORY_SEPARATOR.implode(DIRECTORY_SEPARATOR,["opt","bitninja","Common","AgentConfigSchema",$module.".json"]);
        $config = json_decode($config);
        $result = $this->validateSchema($config, $schemaPath);
        if (empty($result)) {
            $this->log->info($module." configuration is valid.");
            return true;
        } else {
            $this->log->warn($module." configuration is invalid. Errors:");
            foreach ($result as $error){
                $this->log->warn($error);
            }
            return false;
        }
    }

    public function validateSchema($object, $schemaPath): array
    {
        $schema = Schema::fromJsonString(file_get_contents($schemaPath));
        $validator = new Validator();
        $result = $validator->schemaValidation($object, $schema, 5);
        $errors = array();
        if (!$result->isValid()){
            $catchedErrors = $result->getErrors();
            foreach ($catchedErrors as $catchedError){
                $errors[] = $this->formatError($catchedError);
            }
        }
        return $errors;
    }

    public function formatError($error, $depth = 0): string
    {
        $prefix = implode(" ", array_fill(0, $depth, ">>"));
        $pointer = implode("/", $error->dataPointer());
        $errorMessage = ($prefix . $pointer . " violated constraint: " . $error->keyword());
        $keywordArgs = $error->keywordArgs();
        if (count($keywordArgs) > 0) {
            $errorMessage .= ($prefix . " " . json_encode($error->keywordArgs(), JSON_PRETTY_PRINT));
        }
        if ($error->subErrorsCount() > 0) {
            foreach ($error->subErrors() as $subError) {
                $this->formatError($subError, $depth + 1);
            }
        }
        return  $errorMessage;
    }
}