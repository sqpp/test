<?php

use BitNinja\Framework\ContainerInstance;

/**
 * Per module config manager.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class ModuleConfigManager extends AbstractConfigManager
{

    /**
     * @var string
     */
    protected $module_name;

    /**
     * @var Object
     */
    protected static $instances;

    /**
     * @var string
     */
    protected static $default_module_name;

    /**
     * @var BlueLog
     */
    protected $log;
    /**
     * Module related user configuration downloaded from the API.
     *
     * @var \Illuminate\Config\Repository
     */
    protected $repository;

    /**
     * Return the instance
     *
     * @param string $module_name
     * @return ModuleConfigManager
     */
    final public static function instance($module_name = '')
    {
        $classname = get_called_class();

        return isset(static::$instances[$module_name]) ?
            static::$instances[$module_name] :
            static::$instances[$module_name] = new $classname($module_name);
    }

    /**
     * Final constructor.
     *
     * @param string $module_name
     * @return void
     */
    final private function __construct($module_name)
    {
        $this->setLicenseManager(ContainerInstance::instance()->getContainer()['license_manager']);
        $classname = get_called_class();
        $this->log = BlueLog::instance($this);
        if ($module_name !== '') {
            $this->setModuleName($module_name);
        }

        $this->onInit();
    }

    /**
     * Reinitialize the singleton's instance.
     *
     * @param string $module_name
     * @return ModuleConfigManager
     */
    final public static function resetInstance($module_name = '')
    {
        $classname = get_called_class();
        static::$instances[$module_name] = new $classname($module_name);
        return static::$instances[$module_name];
    }

    /**
     * @param string $module_name
     * @return void
     */
    public function setModuleName($module_name)
    {
        $this->module_name = $module_name;
    }

    /**
     * @return string
     */
    public function getEtcDir()
    {
        return "/etc/bitninja/{$this->module_name}";
    }

    /**
     * @param string $module_name
     * @return void
     */
    public function setDefaultModuleName($module_name)
    {
        $this->log->trace('Module config manager module name is [' . $module_name . ']');
        self::$default_module_name = $module_name;
    }

    /**
     * @return void
     */
    public function onInit()
    {
        if (!isset($this->module_name)) {
            $this->module_name = self::$default_module_name;
        }

        if (!isset($this->module_name)) {
            // $this->log->error('Module name not known.');
            // $this->log->backtrace();
            return;
        }

        $this->config = [];
        // Module level config
        $this->loadDefaultConfig();
        $loadedConfigFile = $this->loadSupportedConfigFileInDirectory('/etc/bitninja/' . $this->module_name);
        $this->log->trace('The loaded config file [' . $loadedConfigFile . ']');
    }
    protected function loadDefaultConfig()
    {
        $moduleDir = __DIR__ . '/../../modules/' . $this->module_name;
        $this->loadSupportedConfigFileInDirectory($moduleDir);
        if (isset($this->remoteConfig[$this->module_name])) {
            $this->config = static::arrayMergeRecursive($this->config, $this->remoteConfig[$this->module_name]);
        }
        if (isset($this->cloudConfig)) {
            $this->config = static::arrayMergeRecursive($this->config, $this->cloudConfig);
        }
    }


    /**
     * Parses a given config file and merges with
     * the current configuration, if there is any.
     *
     * @param string $configFilePath
     */
    public function parseConfig($configFilePath)
    {
        $this->_log('trace', 'Parsing config file [' . $configFilePath . ']');
        parent::parseConfig($configFilePath);
    }

    public function _log($level = "error", $message = "")
    {
        $this->log->$level($message);
    }
    /**
     * Returns the path of the config directory, or false if the directory doesn't exist
     *
     * @return bool|string
     */
    public function getConfigDir()
    {
        $moduleConfig = realpath(__DIR__ . '/../../modules/' . $this->module_name . '/config');
        return is_dir($moduleConfig) ? $moduleConfig : false;
    }

    /**
     * Reads the content of the config files to an array and returns it
     *
     * @return array
     */
    public function parseConfigFiles()
    {
        $content = [];
        if (!$this->getConfigDir()) {
            return $content;
        }
        $configParser = new PhpConfigParser();
        $configParser->addConfigDir($this->getConfigDir())->shouldValidatePhpArray(false);
        return $configParser->parseConfigs();
    }

    /**
     * Returns user configuration from API.
     *
     * @return \Illuminate\Config\Repository
     */
    public function getConfigRepository()
    {
        if (is_null($this->repository)) {
            $userConfig = ContainerInstance::instance()->getContainer()['user_config'];
            $this->repository = new \Illuminate\Config\Repository($userConfig->get("Modules.{$this->module_name}", []));
        }
        return $this->repository;
    }

    /**
     * This method will drop every loaded configuration, and reloads them from the file system.
     * @return void
     */
    public function reInit()
    {
        $this->config = $this->remoteConfig;
        $etcDir = ContainerInstance::instance()->getContainer()['etc_dir'];
        foreach ($this->parsedConfigs as $path => $config) {
            if (!empty($this->remoteConfig) && strpos($path, $etcDir) === false) {
                continue;
            }
            if (!empty($this->cloudConfig) && strpos($path, $etcDir) === false) {
                continue;
            }
            $this->parseConfig($config);
        }
    }
}
