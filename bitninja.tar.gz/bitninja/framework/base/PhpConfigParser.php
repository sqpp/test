<?php

/**
 * Some of our modules need extended configuration. Eg: SenseLog rule configurations.
 * This class helps to load configuration from php array files, and prevent fatal error when including syntax error config files.
 * If the same configuration loaded again. Like config belong to a user it will be updated with it.
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class PhpConfigParser
{

    /**
     * Directories which holds loadable configuration.
     *
     * @var array
     */
    protected $configDirs = [];

    /**
     * The loaded onfigurations
     *
     * @var array
     */
    protected $configs = [];

    /**
     * Logger
     *
     * @var BlueLog
     */
    protected $log;

    /**
     * @var boolean
     */
    protected $validateArray = true;

    /**
     * @return void
     */
    public function __construct()
    {
        $this->log = \BlueLog::instance($this);
    }


    /**
     * Enable or disable php array validation
     *
     * @param boolean $validateArray
     * @return PhpConfigParser
     */
    public function shouldValidatePhpArray($validateArray)
    {
        $this->validateArray = $validateArray;
        return $this;
    }

    /**
     * Add a directory to the config loading
     *
     * @param string $configDir
     * @return PhpConfigParser
     */
    public function addConfigDir($configDir)
    {
        if (!is_dir($configDir)) {
            $this->log->info('The given [' . $configDir . '] is not a directory. It will be ignored when loading configs');
            return $this;
        }
        $this->configDirs[] = $configDir;
        return $this;
    }

    /**
     * Add every sub directory to the config loading
     *
     * @param string $directory
     * @return PhpConfigParser
     */
    public function addEverySubDirToConfigDirs($directory)
    {
        if (!is_dir($directory)) {
            $this->log->info('The given [' . $directory . '] is not a directory. It will be ignored when loading configs');
            return $this;
        }
        foreach (glob($directory . DIRECTORY_SEPARATOR . '*', GLOB_ONLYDIR) as $configDir) {
            $this->log->debug("Adding [$configDir] to config directories");
            $this->addConfigDir($configDir);
        }
        return $this;
    }

    /**
     * Remove previously added config directories
     *
     * @return void
     */
    public function flushConfigDirs()
    {
        $this->configDirs = [];
    }

    /**
     * Try to load every php array config files from the added configuration directory.
     *
     * @return array
     */
    public function parseConfigs()
    {
        $configsParsed = [];
        foreach ($this->configDirs as $configDir) {
            $configFiles = glob("$configDir/*.php");
            foreach ($configFiles as $configFile) {
                $config = $this->include_config($configFile);
                if (!$config) {
                    continue;
                }
                foreach ($config as $category => $defination) {
                    if (isset($configsParsed[$category])) {
                        $this->log->debug("Config category [$category] will be overwriten");
                    }
                    $configsParsed[$category] = $defination;
                }
            }
        }
        $this->configs = $configsParsed;
        return $this->configs;
    }

    /**
     * @param string $configFile
     * @return array
     */
    public function include_config($configFile)
    {
        try {
            $config = false;
            if ($this->validateArray && !$this->isPhpArray($configFile)) {
                return $config;
            }
            $config = include($configFile);
        } catch (\Throwable $e) {
            $this->log->warn("Error in configuration file [$configFile] it will not be included.");
            $this->log->warn($e->getMessage());
            $config = false;
        } finally {
            return $config;
        }
    }

    /**
     * Validates if a given file only has php return array content
     *
     * @param string $file
     * @throws Exception
     * @return boolean
     */
    protected function isPhpArray($file)
    {
        if (!is_file($file)) {
            throw new Exception('Config file not exits [' . $file . ']');
            return false;
        }
        $fileContent = file_get_contents($file);
        if (preg_match('/^<\?php\s+return\s+\[(.|\s|\[|\]|\/|\*|\$|\-|\>)/m', $fileContent, $mat) == false) {
            throw new Exception('The given config file ' . $file . ' is not a php array');
            return false;
        }
        return true;
    }

    /**
     * Returns the parsed config
     * @return array
     */
    public function getConfigs()
    {
        return $this->configs;
    }

    /**
     * Returns part of the parse config
     *
     * @return array
     */
    public function getConfig($category)
    {
        if (!isset($this->configs[$category])) {
            return [];
        }
        return $this->configs[$category];
    }
}
