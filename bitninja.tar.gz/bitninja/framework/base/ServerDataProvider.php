<?php

/**
 * Provides data about the current server.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class ServerDataProvider
{
    use TraitSingleton;
    use TraitCommandHelper;

    /**
     * @var string
     */
    private static $_hostname;

    /**
     * @var string
     */
    private static $_os;

    /**
     * TreatSingleton calls init() when the constructor is called.
     * 
     * @return void
     */
    private function init()
    {
        $this->setHostName(gethostname());
        $this->setHostnameParam();
        $this->log->info('Hostname : [' . $this->getHostName() . ']');
        $this->runCommand('true', []);
    }

    /**
     * Set the hostname by a specified environment
     *
     * @return void
     */
    private function setHostnameEnv()
    {
        $env_hostname = getenv('ENV_HOSTNAME');
        if ($env_hostname) {
            $this->setHostName($env_hostname);
            $this->log->warning("Hostname changed by environment variable to [{$env_hostname}]");
        }
    }

    /**
     * Set the hostname if there is a parameter --hostname
     * 
     * @return void
     */
    private function setHostnameParam()
    {
        if ($hostnameparam = BlueParam::instance()->get('hostname')) {
            $this->setHostName($hostnameparam);
            $this->log->warning('Hostname changed by command line parameter to [' . $hostnameparam . ']');
        }
    }

    /**
     * Returns with the current hostname
     * 
     * @return string
     */
    public static function getHostName()
    {
        return self::$_hostname;
    }

    /**
     * Set the current hostname.
     * Used if a hostname is given by parameter or
     * if ypu would like to run tests with different hostname.
     * 
     * @param string $hostname
     * @return void
     */
    public static function setHostName($hostname)
    {
        self::$_hostname = $hostname;
    }

    /**
     * Returns true if the cureent operating system is debian based.
     * like debian, ubuntu, etc.
     * 
     * @return boolean
     */
    public function isDeb()
    {
        if (!isset(self::$_os)) {
            self::$_os = $this->getOs();
        }
        if (!isset(self::$_os['family'])) {
            if ($this->commandBuilder->locateCommand('dpkg', false) !== false) {
                return true;
            }
            return false;
        }

        if (self::$_os['family'] == 'deb') {
            return true;
        }
        return false;
    }

    /**
     * Returns true if the current operatng system is redhat based
     * (like redhat, centos)
     * 
     * @return boolean
     */
    public function isRpm()
    {
        if (!isset(self::$_os)) {
            self::$_os = $this->_getOs();
        }
        if (!isset(self::$_os['family'])) {
            if ($this->commandBuilder->locateCommand('rpm', false) !== false) {
                return true;
            }
            return false;
        }
        if (self::$_os['family'] == 'rpm') {
            return true;
        }
        return false;
    }

    /**
     * @return boolean
     */
    public function is32bit()
    {
        if (!isset(self::$_os)) {
            self::$_os = $this->_getOs();
        }
        if (self::$_os['arch'] == 'i386') {
            return true;
        }
        return false;
    }

    /**
     * @return boolean
     */
    public function is64bit()
    {
        if (!isset(self::$_os)) {
            self::$_os = $this->_getOs();
        }
        if (self::$_os['arch'] == 'x86_64') {
            return true;
        }
        return false;
    }

    /**
     * Is zypper package manager available
     *
     * @return boolean true if it is.
     */
    public function isZypper()
    {
        return $this->isCommamdAvailableAndNotALink('zypper');
    }

    /**
     * Is apt-get package manager available
     *
     * @return boolean true if it is.
     */
    public function isAptGet()
    {
        return $this->isCommamdAvailableAndNotALink('apt-get');
    }

    /**
     * Is apt package manager available
     *
     * @return boolean true if it is.
     */
    public function isApt()
    {
        return $this->isCommamdAvailableAndNotALink('apt');
    }

    /**
     * Is yum package manager available
     *
     * @return boolean true if it is.
     */
    public function isYum()
    {
        return $this->isCommamdAvailableAndNotALink('yum');
    }

    /**
     * return the detected os name and family
     * example return value:
     * array ('name'=> 'debian',
     * 'family'=>'deb',
     * 'version' '6.4'
     * 'version_major' => '6',
     * 'version_minor' => '4',
     * )
     * 
     * @return array
     */
    public function getOs()
    {
        if (!isset($this->osInfo)) {
            $this->osInfo = $this->_getOs();
            $this->log->debug(var_export($this->osInfo, true));
        }
        return $this->osInfo;
    }

    /**
     * @return array
     */
    private function _getOs()
    {
        $os = [];
        $known_os = array(
            'Ubuntu' => 'deb',
            'Debian' => 'deb',
            'Raspbian' => 'deb',
            'LinuxMint' => 'deb',
            'Parrot' => 'deb',
            'Kali' => 'deb',
            'Zorin' => 'deb',
            'CentOS' => 'rpm',
            'Red Hat' => 'rpm',
            'RedHat' => 'rpm',
            'SuSe' => 'rpm',
            'SuSE' => 'rpm',
            'Fedora' => 'rpm',
            'FedoraCore' => 'rpm',
            'Slackware' => 'rpm',
            'Unbreakable' => 'rpm',
            'CloudLinux' => 'rpm',
            'CloudLinuxServer' => 'rpm',
            'RedHatEnterpriseServer' => 'rpm',
            'OracleServer' => 'rpm',
            'Amazon' => 'rpm',
            'general-deb' => 'deb',
            'general-rpm' => 'rpm',
            'AlmaLinux' => 'rpm',
            'Virtuozzo' => 'rpm',
            'Rocky' => 'rpm'
        );

        $os = $this->getOsInfo();
        if (!empty($os)) {
            $os['name'] = $os['os_name'];
            $os['version'] = $os['os_version'];
            unset($os['os_name']);
            unset($os['os_version']);
            $version_array = explode('.', $os['version']);
            $os['version_major'] = $version_array[0];
            if (isset($version_array[1])) {
                $os['version_minor'] = $version_array[1];
            }
        }

        if (isset($os['name'])) {
            $os['family'] = $known_os[$os['name']];
        }

        if (!isset($os['name']) || $os['name'] == '' || $os == null || !isset($os['family']) || $os['family'] == '') {
            $this->log->debug("Cannot get OS information with lsb_release, trying to find by testing package managers...");
            $this->log->debug("Trying apt-get...");
            if ($this->isAptGet() || $this->isApt()) {
                // Ubuntu vagy Debian
                $this->log->debug("Found apt-get.");
                $os['name'] = isset($os['name']) ? $os['name'] : 'general-deb';
                $os['family'] = 'deb';
                return $os;
            }
            $this->log->debug("Could not find apt-get; trying yum...");
            // Nem Ubuntu vagy Debian
            if ($this->isYum()) {
                $this->log->debug("Found yum.");
                $os['name'] = isset($os['name']) ? $os['name'] : 'general-rpm';
                $os['family'] = 'rpm';
                return $os;
            }
            // hat... ha egyik sem, akkor telepiteni sem fog tudni...
            $this->log->error('Could not determine OS name. Got result [' . implode($os, "\n") . ']');
            $this->log->backtrace();
            // ex it;
        }

        return $os;
    }

    /**
     * This method tries to get os informations like os_name, os_version, arch
     *
     * @return array
     */
    public function getOsInfo()
    {
        $osInfo = [];
        $getArchCmd = $this->runCommand('uname', [
            '-m'
        ]);
        $arch = $getArchCmd->getLine(0);
        if (BlueStringLib::endsWith($arch, '86')) {
            $arch = 'i386';
        }
        $osInfo['arch'] = $arch;
        $getOpsysCmd = $this->runCommand('uname', [
            '-s'
        ]);
        if ($getOpsysCmd->getResult()[0] != 'Linux') {
            $this->log->debug('Unable to detect OS');
            return $osInfo;
        }
        $debianVersion = $this->getFileContents('/etc/debian_version');
        if ($debianVersion) {
            $lsbRelease = $this->getFileContents('/etc/lsb-release');
            if ($lsbRelease) {
                $osInfo['os_name'] = $this->getValueFromFile($lsbRelease, 'DISTRIB_ID');
                $osInfo['os_version'] = $this->getValueFromFile($lsbRelease, 'DISTRIB_RELEASE');
            } else {
                $osInfo['os_name'] = 'Debian';
                $getVersionCmd = $this->runCommand('head', [
                    '-1',
                    '/etc/debian_version'
                ]);
                $osInfo['os_version'] = $getVersionCmd->getLine(0);
            }
            switch ($osInfo['os_name']) {
                case 'Debian':
                    break;
                case 'Ubuntu':
                    break;
                default:
                    $this->log->debug('Unknown OS: ' . $osInfo['os_name'] . ' - ' . $osInfo['os_version'] . ' - ' . $arch);
            }
        } elseif ($this->getFileContents('/etc/SuSE-release')) {
            $osInfo['os_name'] = 'SuSE';
            $getVersionCmd = $this->runCommand('head', [
                '-1',
                '/etc/SuSE-release',
                new BlueCmdBuilder('sed', [
                    '-e',
                    's/[^0-9.]*\([0-9.]*\).*/\1/g'
                ])
            ]);
            $osInfo['os_version'] = $getVersionCmd->getLine(0);
        } elseif ($this->getFileContents('/etc/fedora-release')) {
            $osInfo['os_name'] = 'FedoraCore';
            $getVersionCmd = $this->runCommand('head', [
                '-1',
                '/etc/fedora-release',
                new BlueCmdBuilder('sed', [
                    '-e',
                    's/[^0-9.]*\([0-9.]*\).*/\1/g'
                ])
            ]);
            $osInfo['os_version'] = $getVersionCmd->getLine(0);
        } elseif ($this->getFileContents('/etc/redhat-release')) {
            $getOsCmd = $this->runCommand('awk', [
                '{print $1}',
                '/etc/redhat-release'
            ]);
            $osInfo['os_name'] = $getOsCmd->getLine(0);
            $getVersionCmd = $this->runCommand('head', [
                '-1',
                '/etc/redhat-release',
                new BlueCmdBuilder('sed', [
                    '-e',
                    's/[^0-9.]*\([0-9.]*\).*/\1/g'
                ])
            ]);
            $osInfo['os_version'] = $getVersionCmd->getLine(0); // substr($getVersionCmd->getLine(0), 0, strpos($getVersionCmd->getLine(0), '.'));
            $osinfoCombined = $osInfo['os_name'] . $osInfo['os_version'] . $arch;
            switch ($osinfoCombined) {
                case (preg_match('/CentOS4.*i386/', $osinfoCombined) ? true : false):
                    $osInfo['os_version'] = "4.2";
                    break;
                case (preg_match('/CentOS4.*x86_64/', $osinfoCombined) ? true : false):
                    $osInfo['os_version'] = "4.2";
                    break;
                case (preg_match('/(CentOS.*|Cloud.*|Virtuozzo.*)/', $osinfoCombined) ? true : false):
                    break;
                case (preg_match('/Red.*/', $osinfoCombined) ? true : false):
                    $osInfo['os_name'] = 'RedHat';
                    $osInfo['os_version'] = 'el' . $osInfo['os_version'];

                    break;
                default:
                    $this->log->debug('Unknown OS: ' . $osInfo['os_name'] . ' - ' . $osInfo['os_version'] . ' - ' . $arch);
            }
        } else {
            $this->log->debug('Unable to detect OS');
        }
        return $osInfo;
    }

    /**
     * Reterives value for a key from a file.
     * It can be used when we need to get a configuration value.
     *
     * @param string $content
     *            content of a file
     * @param string $key
     *            key which we are looking for
     * @return string value belong to the key
     */
    public function getValueFromFile($content, $key)
    {
        $contentWithoutComments = preg_replace("/^(\s*[#;]\s*.*)$/mi", '', $content);
        // preg_match("/($key(\s|=|:)*(?P<value>([\w\.\/-]*)))/i", $contentWithoutComments,$matches);
        preg_match("/($key(\s|=|:)*(?P<value>(.*)))/i", $contentWithoutComments, $matches);
        return isset($matches['value']) ? $matches['value'] : '';
    }

    /**
     * Returns the install package version, by querying the package manager.
     *
     * @param string $package
     * @return NULL string The version number of the package. Null if not installed.
     */
    public function getPackageVersion($package)
    {
        $res = null;
        if ($this->isDeb()) {
            $cmd = new \BlueCmdBuilder('dpkg-query', [
                '--showformat=${Version}',
                '--show',
                $package
            ]);
            $res = $cmd->execute();
        }
        if ($this->isRpm()) {
            $cmd = new \BlueCmdBuilder('rpm', [
                '--query',
                '--qf',
                '%{VERSION}',
                $package
            ]);
            $res = $cmd->execute();
        }
        return is_null($res) || $res->getReturnVar() != 0 ? $res : $res->getLine(0);
    }

    /**
     * Queries the package manager to see if a software installed at a specific version.
     *
     * @param string $package
     * @param string $version
     * @return boolean True if the software is installed and it's version number match. False otherwise.
     */
    public function checkInstalledSoftwareVersion($package, $version)
    {
        $installedVersion = $this->getPackageVersion($package);
        return is_null($installedVersion) || strpos($installedVersion, $version) === false ? false : true;
    }
}

$serverDataProvider = ServerDataProvider::instance();
