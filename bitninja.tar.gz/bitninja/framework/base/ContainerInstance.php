<?php

namespace BitNinja\Framework;

use BitNinja\Common\Messaging\Redis\RedisClientManager;
use BitNinja\Common\Messaging\Redis\RedisMessageQueue;
use BitNinja\Common\ServiceManager\CommandCommunicationManager;
use BitNinja\Common\ServiceManager\DispatcherManager;
use BitNinja\Common\ServiceManager\ProcessAnalysisManager;
use BitNinja\Common\ServiceManager\RedisManager;
use BitNinja\Common\ServiceManager\ThreatHuntingManager;
use BitNinja\Common\Util\ProcessManager;
use \Pimple\Container;
use BitNinja\Framework\Api\LoadApi;
use BitNinja\Framework\Api\Malware;
use BitNinja\Framework\networking\DomainResolver;
use BlueLicenceManager;
use BlueLog;
use BlueParam;
use Clue\React\Redis\RedisClient;
use ConfigManager;
use Exception;
use React\EventLoop\Loop;
use React\EventLoop\LoopInterface;
use Rx\Scheduler;
use Rx\Scheduler\EventLoopScheduler;

/**
 * @see https://pimple.symfony.com/
 * Pimple Container instace used for dependency injection.
 * When every occurence of new will be replace wtih DI, then this Singelton can be replace with an instance.
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package	BitNinja
 * @subpackage  Framework
 * @version     1.29.10
 */
class ContainerInstance
{
    /**
     * @var Container
     */
    protected $container;

    use \TraitSingleton;

    public function onInit()
    {
        $this->container = new Container();
        $this->initBaseDi();
    }

    /**
     * @return mixed
     */
    public function initBaseDi()
    {
        $this->container['config_manager'] = function ($c) {
            return \ConfigManager::instance();
        };
        $this->container['server_dataprovider'] = function ($c) {
            return \ServerDataProvider::instance();
        };
        $this->container['main_pid_file'] = "/var/run/bitninja.pid";
        $this->container['packed_config'] = file_exists('etc/config.mine.php') ? 'etc/config.mine.php' : 'etc/config.php';
        $this->container['devel_mode'] = false;
        $this->container['system_name'] = 'bitninja';
        $this->container['http_connection_timeout'] = 10;
        $this->container['http_timeout'] = 50;
        $this->container['default_etc_dir'] = null;
        //'/etc/' . $this->container['system_name'];
        $this->container['user_local_config'] = function ($c) {
            return file_exists($c['etc_dir'] . '/config.php') ? $c['etc_dir'] . '/config.php' : false;
        };
        $this->container['load_configs'] = function ($c) {
            $cm = $c['config_manager'];
            /** @var ConfigManager $cm */
            $cm->setDefaultConfigFile($c['packed_config']);
            $cm->parseConfig($c['packed_config']);
            if (!$cm->hasKey('general', 'etc_dir')) {
                $cm->setKey('general', 'etc_dir', '/etc/' . $c['system_name']);
            }
            if (!is_null($c['default_etc_dir'])) {
                $cm->setKey('general', 'etc_dir', $c['default_etc_dir']);
            }
            $loaded = $cm->loadSupportedConfigFileInDirectory($c['etc_dir']);
            if (!$cm->hasKey('general', 'http_connection_timeout')) {
                $cm->setKey('general', 'http_connection_timeout', $c['http_connection_timeout']);
            }
            if (!$cm->hasKey('general', 'http_timeout')) {
                $cm->setKey('general', 'http_timeout', $c['http_timeout']);
            }
        };
        $this->container['system_parameters'] = function ($c) {
            return BlueParam::instance();
        };
        $this->container['logger'] = function ($c) {
            return function ($category) {
                return BlueLog::instance($category);
            };
        };
        $this->container['license_manager'] = function ($c) {
            $licenseManager = BlueLicenceManager::instance();
            $licenseManager->setSysname($c['system_name']);
            $licenseManager->setGuzzleClient($c['v2_authless_client']);
            $licenseManager->setAppId($c['app_uuid']);
            $licenseManager->setHostName($c['hostname']);
            return $licenseManager;
        };
        $this->container['license_key'] = function ($c) {
            /** @var  BlueLicenceManager $licenseManager */
            $licenseManager = $c['license_manager'];
            //$licenseManager->getLicenseKey();
            $license = $licenseManager->getLicenseKey();
            if (is_null($license)) {
                $licenseManager->loadLicense();
                $license = $licenseManager->getLicenseKey();
            }
            return $license; //Manager->getLicenseKey();
        };
        $this->container['provision_key'] = function ($c) {
            /** @var  BlueLicenceManager $licenseManager */
            $licenseManager = $c['license_manager'];
            //$licenseManager->getLicenseKey();
            $provisionKey = $licenseManager->getProvisionKey();
            if (is_null($provisionKey)) {
                $licenseManager->loadLicense();
                $provisionKey = $licenseManager->getProvisionKey();
            }
            return $provisionKey;
        };

        $this->container['find_host_name'] = function ($c) {
            $serverDataProvider = $c['server_dataprovider'];
            $hostNameInConfig = $c['config_manager']->getKey('general', 'hostname');
            if ($hostNameInConfig !== null) {
                $serverDataProvider->setHostName($hostNameInConfig);
            }
            if (getenv("ENV_HOSTNAME")) {
                $serverDataProvider->setHostName(getenv('ENV_HOSTNAME'));
            }
            return $c['server_dataprovider']->getHostName();
        };
        $this->container['hostname'] = function ($c) {
            return $c['find_host_name'];
        };
        $this->container['var_dir'] = function ($c) {
            $varDir = $c['config_manager']->getVarDir();
            if (!is_dir($varDir)) {
                mkdir($varDir, 0750);
            }
            return $varDir;
        };
        $this->container['etc_dir'] = function ($c) {
            $etcDir = $c['config_manager']->getKey('general', 'etc_dir', $c['default_etc_dir']);
            if (!is_dir($etcDir)) {
                mkdir($etcDir, 0750);
            }
            return $etcDir;
        };
        $this->container['meta_file'] = function ($c) {
            return $c['etc_dir'] . DIRECTORY_SEPARATOR . 'server-meta.json';
        };
        $this->container['app_uuid'] = function ($c) {
            $varDir = $c['var_dir'];
            $olduuidPath = $varDir . 'app_id';
            $uuidPath = $c['etc_dir'] . '/app_id';
            if (is_file($olduuidPath)) {
                rename($olduuidPath, $uuidPath);
                chmod($uuidPath, 0400);
            }
            if (!is_file($uuidPath)) {
                file_put_contents($uuidPath, substr(sha1(microtime(true) . $c['hostname']), 0, 32));
                chmod($uuidPath, 0400);
            }
            return trim(file_get_contents($uuidPath));
        };
        $this->container['framework_dir'] = dirname(dirname(__FILE__));
        $this->container['framework_dir'];
        $this->container['apiUrl'] = function ($c) {
            $apiUrl = $c['config_manager']->getKey('general', 'api_url');
            return is_null($apiUrl) ? 'https://api.bitninja.io' : $apiUrl;
        };
        $this->container['apiUrl2'] = function ($c) {
            $apiUrl = $c['config_manager']->getKey('general', 'api2_url');
            return is_null($apiUrl) ? $c['apiUrl'] : $apiUrl;
        };
        $this->container['backupUrl'] = function ($c) {
            $apiUrl = $c['config_manager']->getKey('general', 'backup_url');
            return is_null($apiUrl) ? 'https://user-backup.bitninja.io/backup' : $apiUrl;
        };
        $this->container['license_file'] = function ($c) {
            $license = 'license-v2.json';
            return $c['apiUrl2'] === 'https://api.bitninja.io' ? $license : md5($c['apiUrl2']) . '-' . $license;
        };
        $this->container['agent_version'] = function ($c) {
            $version = $c['server_dataprovider']->getPackageVersion('bitninja');
            return is_string($version) ? $version : 'Unknown';
        };
        $this->container['user_config'] = function ($c) {
            return new \Illuminate\Config\Repository([]);
        };
        $this->container['server_config'] = function ($c) {
            return new \Illuminate\Config\Repository([]);
        };
        $this->container->register(new LoadApi());
        // Malware manager.
        $this->container['api.client.malware'] = function ($container) {
            return new Malware($container);
        };
        $this->container[LoopInterface::class] = function () {
            $loop = Loop::get();
            Scheduler::setDefaultFactory(function () use ($loop) {
                return new EventLoopScheduler($loop);
            });
            return $loop;
        };
        $this->container['redis_client_factory'] = $this->container->factory(function ($c) {
            $redisClientManager = new RedisClientManager($c['config_manager'], $c["logger"]("blue.base.ProcessController"));
            $redisClientManager->createRedisClient();
            return $redisClientManager;
        });
        $this->createRedisClient();
        $this->createRedisClientSub();
        $this->container['message_queue'] = function ($c) {
            return function (string $queueName, bool $subscribe = true, ?BlueLog $logger = null) {
                return new RedisMessageQueue($queueName, $subscribe, $logger);
            };
        };
        $this->container['command_communication_manager'] = function ($c) {
            return new CommandCommunicationManager($c["licence_client"]);
        };
        $this->container['redis_manager'] = function ($c) {
            return new RedisManager();
        };
        $this->container['dispatcher_manager'] = function ($c) {
            return new DispatcherManager();
        };
        $this->container['threat_hunting_manager'] = function ($c) {
            return new ThreatHuntingManager(false);
        };
        $this->container['process_analysis'] = function ($c) {
            return new ProcessAnalysisManager(false);
        };
        if (class_exists('\BitNinja\Common\Util\ProcessManager')) {
            $this->container['process_manager'] = function ($c) {
                return new ProcessManager();
            };
        }
        if (class_exists('\BitNinja\Common\Docker\CliClient')) {
            $this->container['docker_client'] = function ($c) {
                return new \BitNinja\Common\Docker\CliClient();
            };
        }
        if (class_exists('\BitNinja\Common\EnvironmentInfo')) {
            $this->container['environment_info'] = function ($container) {
                return \BitNinja\Common\EnvironmentInfo::instance();
            };
        }
        if (class_exists('\BitNinja\Common\ServiceDetector\LoadServiceDetector')) {
            $this->container->register(new \BitNinja\Common\ServiceDetector\LoadServiceDetector());
        }
        if (class_exists('\BitNinja\Common\FileSystem\SymlinkAttackProtector')) {
            $this->container['symlink_protector'] = function ($c) {
                return new \BitNinja\Common\FileSystem\SymlinkAttackProtector($c['devel_mode']);
            };
        }
        if (class_exists('BitNinja\modules\SenseLog\lib\SpooferProtector')) {
            $this->container['spoofer_protector'] = function ($c) {
                return new \BitNinja\modules\SenseLog\lib\SpooferProtector();
            };
        }
    }

    /**
     * Use this method for mocking
     *
     * @param Container $container
     */
    public function setContainer($container)
    {
        $this->container = $container;
    }

    /**
     * Use this method get DI container
     *
     * @return Container $container
     */
    public function getContainer()
    {
        return $this->container;
    }
    /**
     * @return \Psr\Container\ContainerInterface
     */
    public function getPSR11Container()
    {
        return new \Pimple\Psr11\Container($this->container);
    }

    // Thank for the following dependency injection code to Codeception team.
    // Some modification made to make this solution usable to us.
    const DEFAULT_INJECT_METHOD_NAME = '_inject';

    public function get($className, $autowire = false)
    {
        // normalize namespace
        $className = ltrim($className, '\\');
        return isset($this->container[$className]) ? $this->container[$className] :
            $autowire ? $this->instantiate($className) : null;
    }

    public function set($class)
    {
        $this->container[get_class($class)] = $class;
    }

    /**
     * @param string $className
     * @param array $constructorArgs
     * @param string $injectMethodName Method which will be invoked after object creation;
     *                                 Resolved dependencies will be passed to it as arguments
     * @throws \RuntimeException
     * @return null|object
     */
    public function instantiate(
        $className,
        $constructorArgs = null,
        $injectMethodName = self::DEFAULT_INJECT_METHOD_NAME
    ) {
        // normalize namespace
        $className = ltrim($className, '\\');

        // get class from container
        if (isset($this->container[$className])) {
            if ($this->container[$className] instanceof $className) {
                return $this->container[$className];
            }
            throw new \RuntimeException("Failed to resolve cyclic dependencies for class '$className'");
        }



        $this->container[$className] = false; // flag that object is being instantiated

        $reflectedClass = new \ReflectionClass($className);
        if (!$reflectedClass->isInstantiable()) {
            $traits = $reflectedClass->getTraitNames();
            if (!in_array('TraitSingleton', $traits)) {
                return null;
            }
            $object = $className::instance();
            if ($injectMethodName) {
                $this->injectDependencies($object, $injectMethodName, $constructorArgs);
            }

            $this->container[$className] = $object;
            return $object;
        }

        $reflectedConstructor = $reflectedClass->getConstructor();
        if (is_null($reflectedConstructor)) {
            $object = new $className;
        } else {
            try {
                if (!$constructorArgs) {
                    $constructorArgs = $this->prepareArgs($reflectedConstructor);
                }
            } catch (\Exception $e) {
                throw new \RuntimeException("Failed to create instance of '$className'. " . $e->getMessage());
            }
            $object = $reflectedClass->newInstanceArgs($constructorArgs);
        }

        if ($injectMethodName) {
            $this->injectDependencies($object, $injectMethodName);
        }

        $this->container[$className] = $object;
        return $object;
    }

    /**
     * @param $object
     * @param string $injectMethodName Method which will be invoked with resolved dependencies as its arguments
     * @throws \RuntimeException
     */
    public function injectDependencies($object, $injectMethodName = self::DEFAULT_INJECT_METHOD_NAME, $defaults = [])
    {
        if (!is_object($object)) {
            return;
        }
        $reflectedObject = new \ReflectionObject($object);
        if (!$reflectedObject->hasMethod($injectMethodName)) {
            return;
        }

        $reflectedMethod = $reflectedObject->getMethod($injectMethodName);
        try {
            $args = $this->prepareArgs($reflectedMethod, $defaults);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            if ($e->getPrevious()) { // injection failed because PHP code is invalid. See #3869
                $msg .= '; ' . $e->getPrevious();
            }
            throw new \RuntimeException(
                "Failed to inject dependencies in instance of '{$reflectedObject->name}'. $msg"
            );
        }

        if (!$reflectedMethod->isPublic()) {
            $reflectedMethod->setAccessible(true);
        }
        $reflectedMethod->invokeArgs($object, $args);
    }

    /**
     * @param \ReflectionMethod $method
     * @param $defaults
     * @throws \RuntimeException
     * @return array
     */
    protected function prepareArgs(\ReflectionMethod $method, $defaults = [])
    {
        $args = [];
        $parameters = $method->getParameters();
        foreach ($parameters as $k => $parameter) {
            $dependency = self::getClassFromParameter($parameter);
            if (is_null($dependency)) {
                if (!$parameter->isOptional()) {
                    if (!isset($defaults[$k])) {
                        throw new \RuntimeException("Parameter '$parameter->name' must have default value.");
                    }
                    $args[] = $defaults[$k];
                    continue;
                }
                $args[] = $parameter->getDefaultValue();
            } else {
                $arg = $this->instantiate($dependency);
                if (is_null($arg)) {
                    $arg = $defaults[$k] ?? null;
                }
                if (is_null($arg)) {
                    throw new \RuntimeException("Failed to resolve dependency '$dependency'.");
                }
                $args[] = $arg;
            }
        }
        return $args;
    }

    /**
     * Adapted from https://github.com/Behat/Behat/pull/1313
     *
     * @param ReflectionParameter $parameter
     * @return string|null
     */
    public static function getClassFromParameter(\ReflectionParameter $parameter)
    {
        if (PHP_VERSION_ID < 70100) {
            $class = $parameter->getClass();
            if ($class !== null) {
                return $class->name;
            }
            return $class;
        }

        $type = $parameter->getType();
        if ($type === null || $type->isBuiltin()) {
            return null;
        }
        $typeString = $type->getName();

        if ($typeString === 'self') {
            return $parameter->getDeclaringClass()->getName();
        } elseif ($typeString === 'parent') {
            return $parameter->getDeclaringClass()->getParentClass()->getName();
        }

        return $typeString;
    }

    public function createRedisClient(): void
    {
        unset($this->container['redis_client']);
        $this->container['redis_client'] = function ($c) {
            try {
                return $c['redis_client_factory'];
            } catch (Exception $ex) {
                $c["logger"]("blue.base.ProcessController")->error("Could not connect to the message queue. Module commands will not be executed.");
                return false;
            }
        };
    }

    public function createRedisClientSub(): void
    {
        unset($this->container['redis_client_sub']);
        $this->container['redis_client_sub'] = function ($c) {
            try {
                return $c['redis_client_factory'];
            } catch (Exception $ex) {
                $c["logger"]("blue.base.ProcessController")->error("Could not connect to the message queue. Module commands will not be executed.");
                return false;
            }
        };
    }
}
