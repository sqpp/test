<?php

/**
 * @author      Zoltan Toma <zoltan.toma@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */

class ProcessResolver
{
    /**
     * Hash map to collect process ids to childs.
     *
     * @var array
     */
    protected $map = [];

    /**
     * Check if the process id is assigned to any of the child.
     *
     * @param integer $pid
     * @return bool
     */
    public function exists(int $pid): bool
    {
        return (bool) $this->resolve($pid);
    }

    /**
     * Assign a process id to a child.
     *
     * @param integer $pid
     * @param string $child
     * @return void
     */
    public function assign(int $pid, string $child): void
    {
        // Validate the inputs before any change is commited.
        $this->validateChild($child);
        $this->validateProcessId($pid);

        $this->assertChild($child);

        // Assign the process id.
        $this->map[$child][] = $pid;
    }

    /**
     * Resolve the process id for a child process name.
     *
     * @param integer $pid
     * @return string|false Resolves to false if not associtated to any of the child.
     */
    public function resolve(int $pid)
    {
        // Validate the PID before a failing search.
        $this->validateProcessId($pid);

        foreach ($this->map as $child => $pids) {
            if (in_array($pid, $pids, true)) {
                return $child;
            }
        }

        return false;
    }

    /**
     * Validate the child's name for hash map usability.
     *
     * @throws Exception When the name is invalid.
     *
     * @param string $child
     * @return void
     */
    protected function validateChild(string $child): void
    {
        if (!is_string($child)) {
            throw new \Exception('Child [' . $child . '] is not a string.');
        }

        if (empty($child)) {
            throw new \Exception('Child is empty.');
        }
    }

    /**
     * Validate the process id.
     *
     * @param integer $pid
     * @return void
     */
    protected function validateProcessId(int $pid): void
    {
        if (!is_numeric($pid)) {
            throw new \Exception('Process ID [' . $pid . '] must be an integer.');
        }

        if ($pid < 1) {
            throw new \Exception('Process ID [' . $pid . '] is below range!');
        }
    }

    /**
     * Ensure a map record for the child.
     *
     * @param string $child
     * @return void
     */
    protected function assertChild(string $child): void
    {
        if (!array_key_exists($child, $this->map)) {
            $this->map[$child] = [];
        }
    }
}
