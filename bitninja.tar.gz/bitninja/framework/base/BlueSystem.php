<?php

use BitNinja\Common\ServiceManager\CommandCommunicationManager;
use BitNinja\Common\ServiceManager\DispatcherManager;
use BitNinja\Common\ServiceManager\ProcessAnalysisManager;
use BitNinja\Common\ServiceManager\ReliableAutoUpdateManager;
use BitNinja\Common\ServiceManager\RedisManager;
use BitNinja\Common\ServiceManager\ServiceManager;
use BitNinja\Framework\Api\V2\Agent\CheckIn;
use BitNinja\Framework\Api\V2\DTO\AgentCheckInRequestDTO;
use BitNinja\Framework\base\RemoteConfig;
use BitNinja\Framework\base\CloudConfig;
use BitNinja\Framework\ContainerInstance;
use BitNinja\Framework\TraitCommandBuilder;
use Pimple\Container;
use React\EventLoop\LoopInterface;
use React\Promise\Deferred;
use React\Promise\Promise;
use BitNinja\Framework\base\ConfigValidator;

use function React\Promise\resolve;

/**
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueSystem
{

    use TraitCommandBuilder;
    use TraitSingleton;

    const DISPATCHER_HEARTBEAT_MAX_RETRIES = 5;

    /**
     * @var boolean
     */
    private $_devel_mode;
    /**
     * @var string
     */
    private $_system_name;
    /**
     * @var string
     */
    private $_config_file;
    /**
     * @var boolean
     */
    private $_help_disabled = false;
    /**
     * @var string
     */
    private $_realPath;
    /**
     * @var string
     */
    protected $timezone;
    /**
     * @var Container
     */
    private $container;
    /**
     * @var string
     */
    protected $pidFile;

    /**
     * @var HeimdallHttpApi
     */
    protected $oldApiClient;
    /**
     * @var LoopInterface
     */
    protected $loop;

    /**
     * @var ProcessController
     */
    protected $processController;
    /**
     * @var integer
     */
    protected $delayBetweenApiRetry = 10;
    /**
     * @var RemoteConfig
     */
    protected $remoteConfigManager;

    /**
     * @var CloudConfig
     */
    private $cloudConfigManager;

    /**
     * @var bool
     */
    private $metadataSent = false;

    /** @var RedisManager */
    private $redisManager;

    /** @var DispatcherManager */
    private $dispatcherManager;

    /** @var CommandCommunicationManager */
    private $commandCommunicationManager;

    /** @var int */
    private $dispatcherHeartbeatRetries = 0;

    /** @var ProcessAnalysisManager */
    private $processAnalysisManager;

    /** @var ReliableAutoUpdateManager */
    private $reliableAutoUpdateManager;

    /**
     * Dependency injection helper function.
     *
     * @param LoopInterface $loop
     * @return void
     */
    public function _inject(LoopInterface $loop)
    {
        $this->loop = $loop;
    }
    /**
     * @param integer $delay
     * @return void
     */
    public function setDelayBetweenApiRetry(int $delay)
    {
        $this->delayBetweenApiRetry = $delay;
    }
    /**
     * This function provides the autoload of scripts and initializations. Do not overflow it with useless things!
     * Instead of that, use the modules initialization class that is mandatory for the current module's loading,
     * or make a class for it and declare it only in one call.
     *
     * @param ContainerInstance $container
     * @return void
     */
    public function initialize($container = null)
    {
        // The client can only be started as root
        if (is_null($container)) {
            $container = \BitNinja\Framework\ContainerInstance::instance()->getContainer();
            $container['load_configs'];
        }
        $develMode = $container['devel_mode'];
        $sysname = $container['system_name'];
        if ((posix_getuid() != 0) && ($develMode == false)) {
            echo "\n\t$sysname needs root privileges to start! Try sudo.\n";
            exit(3);
        }
        $parameterManager = $container['system_parameters'];

        $this->redisManager = $container["redis_manager"];
        $this->dispatcherManager = $container['dispatcher_manager'];
        $this->commandCommunicationManager = $container["command_communication_manager"];
        $this->processAnalysisManager = $container['process_analysis'];
        $this->reliableAutoUpdateManager = new ReliableAutoUpdateManager;

        $this->_devel_mode = $develMode;
        cli_set_process_title('bitninja [Main]');

        // Some system locales cause problems with case conversion so we have to set a default
        $this->setLocaleDefaults();

        // Register custom error handler.
        BlueErrorHandler::register($this->isDevelMode());
        $this->container = $container;
        $this->setTimezone('America/New_York');
        $this->pidFile = $this->container['main_pid_file'];
        $this->log = $container['logger']('blue.base.BlueSystem');

        if ($parameterManager->hasParam("daemonize")) {
            $this->log->info('Daemonizing process..');
            $this->_daemonize();
        }
        // Set hostname if accessable
        $hostname = $this->container['hostname'];

        $licence_manager = $container['license_manager'];
        $this->startAgentSession($hostname);
    }

    /**
     * This function provides the autoload of scripts and initializations. Do not overflow it with useless things!
     * Instead of that, use the modules initialization class that is mandatory for the current module's loading,
     * or make a class for it and declare it only in one call.
     *
     * @deprecated
     * @param boolean $devel_mode if set, more verbose logging
     * @param string $sysname Generates the config path by using the sysname parameter.
     *       example: if it is heimdall, config path is /etc/heimdall/heimdall.ini
     * @return void
     */
    public function bootstrap($devel_mode = false, $sysname = 'blue')
    {
        $container = \BitNinja\Framework\ContainerInstance::instance()->getContainer();
        $container['packed_config'] = $this->_config_file;
        $container['devel_mode'] = $devel_mode;
        $container['system_name'] = $sysname;
        $container['load_configs'];
        $this->log = BlueLog::instance('blue.base.BlueSystem');
        $this->log->warning("BlueSystem::bootstrap method is deprecated. Please use BlueSystem::initialize");
    }
    /**
     * Send a simple request to the BitNinja api to check if the
     * connection is successful and the API key works fine.
     *
     * @return void
     */
    public function pingApi()
    {

        $licence_manager = BlueLicenceManager::instance();
        /** @var BlueLicenceManager $licence_manager */
        $licence_manager->loadLicense();
        try {
            $checkin = $this->checkin($licence_manager);
            $this->container['user_config'];

            if (!$this->metadataSent) {
                $this->associateMetadata();
            }

            // Test HttpApi access and exit here if it fails.
            do {
                $url = "/v2/cloudConfig/server/" . $this->container['server_id'] . "/moduleConfigurations/all/settings";
                $client = $this->container['licence_client'];
                $response = $client->get($url);
                $rawresult = json_decode($response->getBody(), true);
                $result = $rawresult['result'];
                $hadError = false;
                if (!empty($result['errors'])) {
                    $hadError = true;
                }
                if ($hadError) {
                    $this->log->warning("Failed to access the API server. Retrying after {$this->delayBetweenApiRetry} seconds.");
                    $this->log->var_dump($result['errors'], "debug");
                    sleep($this->delayBetweenApiRetry);
                    continue;
                }
                if ($result === false) {
                    $this->missingLicenseExit("Invalid API key!");
                }
                if (!isset($result['license'])) {
                    $this->log->warning($rawresult);
                    $this->log->var_dump($result['errors'], "debug");
                    $hadError = true;
                    sleep($this->delayBetweenApiRetry);
                    continue;
                }
                $licence_manager->setLicence($result['license']);
                $moduleRestrictions = array();
                foreach ($result['modules'] as $module) {
                    if ($module['isAvailable']) {
                        $moduleRestrictions[] = $module['name'];
                    }
                }
                $licence_manager->setModuleRestrictions($moduleRestrictions);
            } while ($hadError);
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            if (!in_array($e->getResponse()->getStatusCode(), [403, 417])) {
                sleep($this->delayBetweenApiRetry);
                $this->log->warning($rawresult);
                $this->log->debug("The PingApi throw ClientException but the status code is not 403 or 417");
                return $this->pingApi();
            }

            $response = json_decode($e->getResponse()->getBody(), true);
            if (!(isset($response['message']) && in_array($response['message'], ['Forbidden', 'Expectation Failed']))) {
                sleep($this->delayBetweenApiRetry);
                $this->log->warning($rawresult);
                $this->log->debug("The PingApi throw ClientException but the status code is not 403 or 417");
                return $this->pingApi();
            }
            $this->missingLicenseExit($response['message']);
        } catch (\Throwable $e) {
            sleep($this->delayBetweenApiRetry);
            $this->log->warning($rawresult);
            $this->log->warning("The PingApi throw Any Exception: " . $e->getMessage());
            return $this->pingApi();
        }
    }

    /**
     * Checkin with the agent to API and update our status
     *
     * @param BlueLicenceManager $licence_manager
     * @return array
     */
    protected function checkin($licence_manager)
    {
        $tryAgain = false;
        do {
            try {
                $hostname = gethostname();
                $appId = $this->container['app_uuid'];
                $appIdFromApi = $this->container['server_info']['instanceId'];
                if ($appIdFromApi == null) {
                    throw new RuntimeException('InstanceId in Api response not set');
                }

                if ($appId != $appIdFromApi) {
                    $appId = $appIdFromApi;
                    file_put_contents("/etc/bitninja/app_id", $appIdFromApi);
                }
                $this->log->debug("Checkin hostname [$hostname] with appId [$appId]");
                $checkin = new CheckIn($this->container['licence_client']);
                $dto = new AgentCheckInRequestDTO($licence_manager->getLicenseKey(), $hostname, $appId, $licence_manager->getLicenseType());
                $response = json_decode($checkin->post($dto)->getBody(), true);
                if (!isset($response['status'])) {
                    $tryAgain = true;
                    throw new RuntimeException('Api response status not set');
                }
                if ($response['status'] === false) {
                    if (
                        isset($response['message'])
                        && $response['message'] === 'Server license is already in use. Please create a new server license!'
                    ) {
                        $this->log->info('Server license is already in use. Creating a new one.');
                        $EtcDir = $this->container['etc_dir'];
                        unlink($EtcDir . DIRECTORY_SEPARATOR . 'app_id');
                        unlink($EtcDir . DIRECTORY_SEPARATOR . $this->container['license_file']);
                        $allowedModules = ConfigManager::instance()->getKey('general', 'modules');
                        $this->log->debug('Restricting modules. Original allow module were:');
                        $this->log->var_dump($allowedModules);
                        $allowedModules = array_intersect(['System', 'DataProvider'], $allowedModules);
                        $this->log->debug('Restricted modules:');
                        $this->log->var_dump($allowedModules);
                        ConfigManager::instance()->setKey('general', 'modules', $allowedModules);
                        $cmd = new \BlueCommandExec('Restart', 'local.System', null, null);
                        $cmd->queue()->catch(function ($e) {
                            $this->log->error($e->getMessage());
                        });
                        return $response;
                    }
                    if (
                        isset($response['message'])
                        && $response['message'] === 'Server license is already in use. Please use the provided license!'
                        && isset($response['new_app_id'])
                        && isset($response['new_license'])
                        && isset($response['new_license_type'])

                    ) {
                        $this->log->info('Server license is already in use. Updating license with one that the API provided.');
                        $EtcDir = $this->container['etc_dir'];
                        file_put_contents($EtcDir . DIRECTORY_SEPARATOR . 'app_id', $response['new_app_id']);
                        file_put_contents($EtcDir . DIRECTORY_SEPARATOR . $this->container['license_file'], json_encode([
                            'type' => $response['new_license_type'],
                            'license' => $response['new_license'],
                        ], JSON_PRETTY_PRINT));
                        $allowedModules = ConfigManager::instance()->getKey('general', 'modules');
                        $this->log->debug('Restricting modules. Original allow module were:');
                        $this->log->var_dump($allowedModules);
                        $allowedModules = array_intersect(['System', 'DataProvider'], $allowedModules);
                        $this->log->debug('Restricted modules:');
                        $this->log->var_dump($allowedModules);
                        ConfigManager::instance()->setKey('general', 'modules', $allowedModules);
                        $cmd = new \BlueCommandExec('Restart', 'local.System', null, null);
                        $cmd->queue()->catch(function ($e) {
                            $this->log->error($e->getMessage());
                        });
                        return $response;
                    }
                    $tryAgain = true;
                    throw new RuntimeException('Api response message was invalid');
                }
                return $response;
            } catch (\Throwable $e) {
                $tryAgain = true;
                if (isset($response['message'])) {
                    $this->log->warning($response['message']);
                } else {
                    $this->log->warning("Failed to access the API server. Retrying after {$this->delayBetweenApiRetry} seconds.");
                }
                $this->log->warning($e->getMessage());
                $this->container->offsetUnset('server_info');
                ContainerInstance::instance()->getContainer()->register(new \BitNinja\Common\LoadServerInfo());
                sleep($this->delayBetweenApiRetry);
            }
        } while ($tryAgain);
    }

    /**
     * @param string $message
     * @return void
     */
    protected function missingLicenseExit($message)
    {
        $this->log->error($message);
        self::writeLicenseRequired();
        if (is_file($this->pidFile)) {
            unlink($this->pidFile);
        }
        exit(1);
    }

    /**
     * @return void
     */
    public static function writeLicenseRequired()
    {
        echo "\n-----------------------------------------------------------------------";
        echo "\n ";
        echo "\n In case you chose not to use the universal installer ";
        echo "\n please insert your license key by using the following command as root:";
        echo "\n ";
        echo "\n bitninja-config --set license_key=<your_license_key_here>";
        echo "\n ";
        echo "\n Please find your license key at https://admin.bitninja.io";
        echo "\n at the Settings/General menu.";
        echo "\n ";
        echo "\n-----------------------------------------------------------------------\n";
    }

    /**
     * Start the system by activating the modules defined in the confoig files
     * and run each module worker in a separate process. Than enter the main
     * process to monitoring mode, checking the module processes for
     * exit and restart them if needed.
     *
     * @return void
     */
    public function start()
    {
        $workers = $this->initModules();
        $this->singleRun();
        $this->ensureBitninjaUserExists();
        // Checking for zombie processes coused several problems
        // in autoupdater. Later
        $this->_checkOtherInstances();

        $this->logBanner($this->getSystemName());

        $this->startMessageQueue();

        if ($this->dispatcherManager->isRunning()) {
            $this->log->info("bitninja-dispatcher is already running, restarting.");
            $this->dispatcherManager->stopService();
        }
        $this->dispatcherManager->startService();
        $this->processAnalysisManager->startService();
        $this->reliableAutoUpdateManager->startService();

        $this->processController = ContainerInstance::instance()->instantiate(ProcessController::class, [$this, $workers]);
        $this->processController->setContainer($this->container);

        $this->redisManager->on(ServiceManager::EVENT_SERVICE_RECOVERED, function () {
            $this->log->info("Reconnecting to the message queue.");
            $this->log->info("Restarting dispatcher.");
            $this->dispatcherManager->stopService();
            $this->dispatcherManager->startService();
            $this->processController->createMessageQueue(true);
        });

        $this->processController->addSafePeriodicTimer(5, function () {
            $this->redisManager->checkHealth();
            $this->dispatcherManager->checkHealth();
            $this->processController->pingMessageQueue();
            $this->processAnalysisManager->checkHealth();
        });

        $this->processController->addSafePeriodicTimer(60, function () {
            $handler = function ($res) {
                if (!$res) {
                    $this->log->warn("Dispatcher heartbeat check failed.");
                    $this->dispatcherManager->logLastNLogLines(5);
                }
                $this->commandCommunicationManager->runService();
            };

            $this->dispatcherManager->checkAgentHeartBeat()
                ->then(
                    function ($result) use ($handler) {
                        $handler($result);
                    },
                )->catch(
                    function ($error) use ($handler) {
                        $this->log->error(($error instanceof \Throwable ? $error->getMessage() : print_r($error, true)));
                        $handler(false);
                    }
                );
        });

        $this->processController->start();
        $this->processController->monitor();
    }

    private function startMessageQueue()
    {
        while (!$this->redisManager->startService()) {
            $this->log->warn("Could not start the message queue, retrying in 10 seconds.");
            $this->redisManager->logLastNLogLines(5);
            $this->redisManager->reset();
            ModuleWorker::static_pcntl_sleep(10);
        }
    }

    protected function ensureBitninjaUserExists()
    {
        if (posix_getpwnam('bitninja') === false) {
            $this->log->info('Group [bitninja] does not exist, creating it.');
            shell_exec('useradd bitninja --system --shell=/bin/false');
        }
    }

    /**
     * Define the session ID for the agent, this can be salted
     * with the hostname to avoid the minor possibility where
     * multiple agent restarts at the same time but not neccessary!
     *
     * @param string $hostname
     * @return void
     */
    protected function startAgentSession($hostname = '')
    {
        if (!defined('AGENT_SESSION_ID')) {
            define('AGENT_SESSION_ID', substr(sha1(microtime() . $hostname . 'session-id' .  mt_rand()), 0, 32));
        }
    }

    /**
     * Runs on one thread a Command object.
     *
     * @return void
     */
    protected function singleRun()
    {
        $log = BlueLog::instance('framework.base.BlueSystem');
        $runclass = BlueParam::instance()->get('run');

        if ($runclass) {
            $config = ConfigManager::instance()->getConfig('general');
            chdir($config['base_dir']);

            // Parameterek kiszedese a --p1, --p2, stb. bol.
            $pnum = 1;
            $params = array();

            while ($param = BlueParam::instance()->get('p' . $pnum)) {
                $log->debug('Param' . $pnum . ' => [' . $param . ']');
                $params[] = $param;
                $pnum++;
            }

            PhpConsoleLogger::changeSyslogIdent('blue-cron');
            $cron = new $runclass();

            // Az alabbi call_user_func cucc ugyanezt csinalja mint a
            // $cron->run(); azzal a kulonbseggel, hofgy a $params tom elemeit atadja
            // parameterekkent.
            call_user_func_array(array($cron, 'run'), $params);
            exit(2);
        }
    }

    /**
     * Shows a banner in log during startup.
     *
     * @param string $msg1
     * @return void
     */
    protected function logBanner($msg1)
    {
        $log = BlueLog::instance('blue.base.BlueSystem');
        $log->info(str_repeat("*", 9 + strlen($msg1)));
        $log->info("*  " . $msg1 . "     *");
        $log->info(str_repeat("*", 9 + strlen($msg1)));
    }

    /**
     * @return array
     */
    public function initModules()
    {
        $config = ConfigManager::instance()->getConfig('general');
        $mm = ModuleManager::instance();
        foreach ($config['modules'] as $module) {
            $mm->initModule($module);
        }
        return $mm->getWorkers();
    }

    /**
     * Loads a module and executes it without the multi threading
     * the start method provides. It is an easy way to debug a module
     * on a single threaded fashion or use the framework on a single
     * thread way.
     *
     * @param string $name
     * @return void
     */
    public function runModuleAlone($name, $terminate = true)
    {
        $this->container['module_name'] = $name;
        if ($this->redisManager->isRunning()) {
            $this->commandCommunicationManager->setApiCommunicationChannel(CommandCommunicationManager::CURRENT_COMMUNICATION_CHANNEL_SOCKET);
        } else {
            $this->commandCommunicationManager->setApiCommunicationChannel(CommandCommunicationManager::CURRENT_COMMUNICATION_CHANNEL_HTTP);
        }

        $w = $this->getWorker($name);
        $w->setRealPath($this->getRealPath());
        if (method_exists($w, "shouldTerminate")) {
            $w->shouldTerminate($terminate);
        }
        $w->loop();
    }
    /**
     * @param string $name
     * @return ModuleWorker
     */
    public function getWorker($name)
    {
        $mm = ModuleManager::instance();
        $mm->initModule($name);
        $workers = $mm->getWorkers();
        return new $workers[$name]();
    }
    /**
     * @param string $config_file
     * @return void
     */
    public function setConfigFile($config_file)
    {
        $this->_config_file = $config_file;
    }

    /**
     * If we are in devel mode, this returns with true.
     *
     * @return boolean
     */
    public function isDevelMode()
    {
        return $this->_devel_mode;
    }

    /**
     * Retrun the system name.
     *
     * @return string
     */
    public function getSystemName()
    {
        return $this->_system_name;
    }

    /**
     * Set system name
     *
     * @param string $system_name
     * @return void
     */
    public function setSystemName($system_name)
    {
        $this->_system_name = $system_name;
    }

    /**
     * Disable the help message. Used by bitninjacli as it has it's own
     * handler for parameters. This implementation is not that nice...
     *
     * @return void
     */
    public function disableHelp()
    {
        $this->_help_disabled = true;
    }

    /**
     * Set the defaukt_timezone based on the linux system settings.
     *
     * @param string $default
     * @return string
     */
    private function setTimezone($default)
    {
        $timezone = "";
        // On many systems (Mac, for instance) "/etc/localtime" is a symlink
        // to the file with the timezone info
        if (is_link("/etc/localtime")) {
            // If it is, that file's name is actually the "Olsen" format timezone
            $filename = readlink("/etc/localtime");

            $pos = strpos($filename, "zoneinfo");

            if ($pos) {
                // When it is, it's in the "/usr/share/zoneinfo/" folder
                $timezone = substr($filename, $pos + strlen("zoneinfo/"));
            } else {
                // If not, bail
                $tz = $this->getServerTimezone($default);
                $timezone = $tz;
            }
        } else {
            // On other systems, like Ubuntu, there's file with the Olsen time
            // right inside it.
            if (is_file('/etc/timezone')) {
                $timezone = file_get_contents("/etc/timezone");
            }

            if (!strlen($timezone)) {
                $tz = $this->getServerTimezone($default);
                $timezone = $tz;
            }
        }
        $timezone = preg_replace("#^posix/#", "", trim($timezone));

        if ($timezone == '') {
            $this->log->info('Could not determine server timezone! Using default timezone [' . $default . ']');
            $timezone = $default;
        }

        date_default_timezone_set($timezone);
        $this->timezone = $timezone;
        $this->saveTimeZoneFile($this->timezone);
        $this->log->info('Timezone set to [' . $timezone . ']');
    }
    protected function saveTimeZoneFile($timezone)
    {
        file_put_contents(ConfigManager::instance()->getVarDir() . 'timezone', $timezone);
    }
    public function getServerTimezone($default)
    {
        if (!is_file('/etc/localtime')) {
            return '';
        }
        $shell = 'md5sum /etc/localtime';
        $q = shell_exec($shell);
        $shell = 'find /usr/share/zoneinfo -type f | xargs md5sum | grep ' . substr($q, 0, strpos($q, '/') - 2);
        $q = shell_exec($shell);
        $q = substr($q, strpos($q, 'info/') + 5, strpos($q, " "));
        $timezone = substr($q, 0, strpos($q, chr(10)));
        if ($timezone == 'posixrules') {
            $timezone = $default;
        }
        return $timezone;
    }

    /**
     * Check if an other instance of blue is running.
     * If so, log and stop bootstrap.
     * If only torn zombie processes are present, clean up them.
     *
     * @return void
     */
    private function _checkOtherInstances()
    {
        $container = \BitNinja\Framework\ContainerInstance::instance()->getContainer();
        /** @var string */
        $mainPidFilePath = $container['main_pid_file'];
        // Check if another process is already running
        if (!is_file($mainPidFilePath)) {
            return;
        }
        $this->log->debug('PID file already exists.');
        $pid = file_get_contents($mainPidFilePath);
        if (posix_getpgid($pid) && ($pid != posix_getpid())) {

            if (!$this->checkPIDContainsBitNinja($pid)) {
                $this->log->info("Stealth pid file detected and removed.");
                unlink($mainPidFilePath);
                return;
            }

            $this->log->error('Another instance is already running!');
            $this->log->error('Kill that one before starting a new instance!');
            exit(5);
        }
        return;
    }

    private function checkPIDContainsBitNinja($PID)
    {
        $cmd = 'ps';
        $param = ['-p', $PID, new \BlueCmdBuilder('grep', ["bitninja"])];
        $res = $this->runCommand($cmd, $param);
        return $res->isSuccessFull();
    }

    /**
     * Daemonize the program.
     *
     * @return boolean
     */
    private function _daemonize()
    {
        $this->_checkOtherInstances();

        // Fork process!
        if (!$this->_fork()) {
            return false;
        }

        // Set daemon mode for console logging (switch off console logging)
        BlueConsoleLogRouter::daemonMode();

        // Change umask
        @umask(0077);

        // Write PID file
        // Mentsuk el a foprocess pid jet

        $config = ConfigManager::instance()->getConfig('general');
        if (!is_dir($config['var_dir'])) {
            // create the var dir if not exists. rw for owner only. Recursive.
            mkdir($config['var_dir'], 0600, true);
            $this->log->info('BitNinja var directory does not exist. Created a new one.');
        }

        $container = \BitNinja\Framework\ContainerInstance::instance()->getContainer();
        /** @var string */
        $mainPidFilePath = $container['main_pid_file'];

        file_put_contents($mainPidFilePath, posix_getpid());
        $this->saveTimeZoneFile($this->timezone);
        $this->log->info('Program daemon started successfully.');
    }

    /**
     * Do the fork for daemonization
     *
     * @return boolean
     */
    private function _fork()
    {
        $pid = pcntl_fork();
        if ($pid === -1) {
            // Error
            $this->log->error('Process cannot be forked');
            return false;
        }
        if ($pid) {
            // Parent
            // Die without attracting attention
            exit(0);
        }
        // Child
        return true;
    }

    /**
     * @return string
     */
    public function getRealPath()
    {
        return $this->_realPath;
    }

    /**
     * @return BlueSystem
     */
    public function setRealPath($_realPath)
    {
        $this->_realPath = $_realPath;
        return $this;
    }
    public function getLoop()
    {
        return $this->loop;
    }

    /**
     * Stops BitNinja processes
     * @return void
     */
    public function stop()
    {
        if (!is_null($this->processController)) {
            $this->processController->stop();
        }
    }

    public function associateMetadata()
    {
        if (is_null($this->remoteConfigManager)) {
            $this->createRemoteConfigManager();
        }
        $this->metadataSent = $this->remoteConfigManager->associateMetadata();
    }

    public function downloadRemoteConfigs()
    {
        if (is_null($this->remoteConfigManager)) {
            $this->createRemoteConfigManager();
        }
        $this->remoteConfigManager->on(RemoteConfig::NEW_CONFIG, function ($allConfig) {
            ConfigManager::instance()->setRemoteConfig($allConfig['Main'])->reInit();
            unset($allConfig['Main']);
            ModuleConfigManager::instance()->setRemoteConfig($allConfig)->reInit();
        });
        $this->remoteConfigManager->downloadRemoteConfigs();
    }
    public function setMainCloudConfig(): void
    {
        $moduleName = 'Main';
        $cloudConfigPath = DIRECTORY_SEPARATOR . implode(DIRECTORY_SEPARATOR, ["var", "lib", "bitninja", "config", $moduleName . ".json",]);
        if (file_exists($cloudConfigPath)) {
            $configValidator = new ConfigValidator($this->log);
            $cloudConfig = file_get_contents($cloudConfigPath);
            if ($cloudConfig !== false || $configValidator->validateModuleConfig($cloudConfig, $moduleName)) {
                $cloudConfig = json_decode($cloudConfig, true);
                ConfigManager::instance()->setCloudConfig($cloudConfig)->reInit();
            }
        }
    }

    protected function createRemoteConfigManager(): void
    {
        $this->remoteConfigManager = ContainerInstance::instance()->instantiate(RemoteConfig::class, [
            $this->container['licence_client'],
            $this->container['server_id'],
            ConfigManager::instance()->getVarDir(),
            $this->log,
            $this->container['meta_file']
        ]);
    }
    public function downloadCloudConfigs(): void
    {
        if (is_null($this->cloudConfigManager)) {
            $this->createCloudConfigManager();
        }
        ModuleConfigManager::instance()->reInit();
        $this->cloudConfigManager->downloadCloudConfigs(false);
        if ($this->cloudConfigManager->isCloudConfigEnabled()) {
            $this->setMainCloudConfig();
        }
    }

    protected function createCloudConfigManager(): void
    {
        $this->cloudConfigManager = ContainerInstance::instance()->instantiate(CloudConfig::class, [
            $this->container['licence_client'],
            $this->log
        ]);
    }

    private function setLocaleDefaults(): void
    {
        // Some distros do not have 'en_US' by default, only 'en_US.UTF-8'
        $validLocales = [
            'en_US',
            'en_US.UTF-8'
        ];

        $result = false;
        $i = 0;
        do {
            $this->log->debug("Setting locale to [$validLocales[$i]]");
            $result = setlocale(LC_CTYPE, $validLocales[$i]);
            $i++;
        } while (!$result && $i < count($validLocales));

        if (!$result) {
            $this->log->warn("Could not set locale specific settings.");
        }
    }
}
