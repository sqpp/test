<?php

/**
 * This handles the autoload of the necessary files.
 * Usage:
 *
 * include('framework/base/Autoloader');
 *
 * It does the rest.
 * Important! The system expects the class name to be the same
 * as the .php file!
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class ModuleManager
{

    //use Singleton;

    /**
     * @var ModuleManager
     */
    protected static $instance;

    /** @var BlueLog */
    private $log;

    /**
     * @return ModuleManager
     */
    final public static function getInstance()
    {
        return isset(static::$instance) ? static::$instance : static::$instance = new static;
    }

    /**
     * @return ModuleManager
     */
    final public static function instance()
    {
        return static::getInstance();
    }

    /**
     * @return void
     */
    final private function __construct()
    {
        $this->init();
    }

    /**
     * @return void
     */
    protected function init()
    {
        $this->log = BlueLog::instance($this);
    }

    /**
     * @var array
     */
    private $workers;
    /**
     * @var array
     */
    private $modules;

    /**
     * A function that handles the loading of a module.
     * Saves the module and we can call the initialized workers with the getWorkers() function.
     *
     * @param string $module Name of the module. (The subdirectory name in the modules directory.)
     * @return void
     */
    public function initModule($module_name)
    {
        $autoloader = Autoloader::instance();
        $autoloader->addModulePath($module_name . '/lib');
        $autoloader->addModulePath($module_name . '/commands');

        $this->log->info('Activating module [' . $module_name . ']');
        $module = new Module($module_name);
        $module->init();
        $this->log->debug('Starting migration [' . $module_name . ']');
        // Futtassuk le a modul migralo kodjat ha szukseges.
        $module->migrateUp();

        if (is_file(dirname(dirname(__DIR__)) . '/modules/' . $module_name . '/Worker' . $module_name . '.php')) {
            $this->workers[$module_name] = $module->getWorkerClassName();
        }
        $this->modules[$module_name] = $module;

        $this->log->info('Module [' . $module_name . '] activated.');
    }

    /**
     * Retruns the name of the loaded modules' workers.
     *
     * @return array
     */
    public function getWorkers()
    {
        return $this->workers;
    }

    /**
     * Return the module object by the name of a module.
     *
     * @param string $name
     * @return Module
     */
    public function getModule($name)
    {
        return $this->modules[$name];
    }
}
