<?php

namespace BitNinja\Framework\base;

use BitNinja\Framework\Api\V2\Adapter\AdapterInterface;
use BlueLog;
use ConfigManager;
use Evenement\EventEmitterTrait;
use GuzzleHttp\Exception\ClientException;
use Throwable;

/**
 * @author Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright © 2021 BitNinja Inc.
 * @package BitNinja
 * @since 2.24.0
 */
class RemoteConfig
{
    use EventEmitterTrait;
    const NEW_CONFIG = 'newConfig';
    /**
     * @var AdapterInterface
     */
    protected $client;
    /**
     * @var integer
     */
    protected $serverId;
    /**
     * @var string
     */
    protected $outputDir;
    /**
     * @var string
     */
    protected $remoteConfigFileName = 'remote_config.json';
    /**
     * @var BlueLog
     */
    protected $log;

    /**
     * @var string|null
     */
    private $metaFile;

    /**
     * @var string
     */
    public static $remoteConfigFile;
    /**
     * @todo Allow injection annotation
     * @Inject({"client" = "licence_client"})
     * @Inject({"serverId" = "server_id"})
     * @Inject({"outputDir" = "var_dir"})
     * @param AdapterInterface $client
     * @param integer $serverId
     * @param string $outputDir
     * @param BlueLog $log
     * @param string|null $metaFile
     */
    public function __construct(AdapterInterface $client, int $serverId, string $outputDir, BlueLog $log, string $metaFile = null)
    {
        $this->client = $client;
        $this->serverId = $serverId;
        $this->outputDir = $outputDir;
        $this->log = $log;
        $this->metaFile = $metaFile;
        self::$remoteConfigFile = $this->outputDir  . $this->remoteConfigFileName;
    }

    /**
     * @return boolean
     */
    protected function isRemoteConfigEnabled()
    {
        return !!ConfigManager::instance()->getIntKey('general', 'download_remote_config', 1);
    }
    /**
     * @return void
     */
    public function downloadRemoteConfigs()
    {
        if (!$this->isRemoteConfigEnabled() || !$this->hasMetadata()) {
            return false;
        }
        try {
            $this->log->info('Downloading remote configs');
            $response = $this->client->get("/v2/agentConfig/ini/server/{$this->serverId}");
            $decoded = json_decode($response->getBody(), true);
            if (!$this->validateDecodedResponse($decoded)) {
                throw new \Exception(isset($decoded['message']) ? $decoded['message'] : "Decoded response is missing important information");
            }
            $this->saveRemoteConfigs($decoded['result']);
            $this->emit(self::NEW_CONFIG, [$decoded['result']]);
            $this->log->info('New remote config downloaded');
            return true;
        } catch (ClientException $e) {
            $this->log->warn('Error caught while downloading remote config');
            $decoded = json_decode((string)$e->getResponse()->getBody(), true);
            if (isset($decoded['message']) && is_string($decoded['message'])) {
                $this->log->warn($decoded['message']);
            }
        } catch (Throwable $e) {
            $this->log->warn("Error caught while downloading remote config [{$e->getMessage()}]");
        }

        if (file_exists(self::$remoteConfigFile)) {
            $this->log->info("Using local cached remote config: [" . self::$remoteConfigFile . "]");
            return $this->loadRemoteConfig();
        }

        $this->log->warn("Remote config download failed and no local copy could be found.");
        return false;
    }

    /**
     * @return bool
     */
    public function associateMetadata()
    {
        if (!$this->isRemoteConfigEnabled() || !$this->hasMetadata()) {
            return false;
        }

        try {
            $this->log->info("Sending association metadata");
            $this->client->post(
                "/v2/agentConfig/server/{$this->serverId}/metadataAssociation",
                json_decode(file_get_contents($this->metaFile), true),
            );
            return true;
        } catch (ClientException $e) {
            $this->log->error("Error caught while associating metadata");
            $decoded = json_decode((string)$e->getResponse()->getBody(), true);
            if (isset($decoded['message']) && is_string($decoded['message'])) {
                $this->log->error($decoded['message']);
            } else {
                $this->log->error($e->getMessage());
            }
        } catch (Throwable $e) {
            $this->log->error("Error caught while associating metadata [{$e->getMessage()}]");
        }

        return false;
    }

    /**
     * @param array $decoded
     * @return boolean
     */
    protected function validateDecodedResponse($decoded)
    {
        if (!is_array($decoded)) {
            return false;
        }
        if (!(isset($decoded['result']) && is_array($decoded['result']))) {
            return false;
        }
        if (!(isset($decoded['message']) && is_string($decoded['message']))) {
            return false;
        }
        if (!(isset($decoded['errors']) && is_array($decoded['errors']))) {
            return false;
        }
        $result = $decoded['result'];
        return $this->validateRemoteConfig($result);
    }
    /**
     * @param array $configs
     * @return int|false
     */
    protected function saveRemoteConfigs(array $configs)
    {
        if (!$configs) {
            throw new \Exception('Remote configs are empty.');
        }

        if (!is_dir($this->outputDir)) {
            mkdir($this->outputDir, 0750, true);
        }
        return file_put_contents($this->outputDir  . $this->remoteConfigFileName, json_encode($configs, JSON_PRETTY_PRINT));
    }
    /**
     * @return array|mixed
     */
    public static function getRemoteConfigs()
    {
        if (is_null(self::$remoteConfigFile)) {
            return null;
        }
        return json_decode(file_get_contents(self::$remoteConfigFile), true);
    }

    private function loadRemoteConfig(): bool
    {
        $rawConfig = file_get_contents(self::$remoteConfigFile);

        if (!$rawConfig) {
            $this->log->warn("Could not read remote config file: [" . self::$remoteConfigFile . "]");
            return false;
        }

        $config = json_decode($rawConfig, true);

        if (!$config || !$this->validateRemoteConfig($config)) {
            $this->log->warn("Remote config file is invalid: [" . self::$remoteConfigFile . "]");
            return false;
        }

        $this->emit(self::NEW_CONFIG, [$config]);
        return true;
    }

    private function validateRemoteConfig($config): bool
    {
        if (!(isset($config['Main']) && isset($config['System']))) {
            return false;
        }

        return true;
    }

    private function hasMetadata(): bool
    {
        return $this->metaFile && is_string($this->metaFile) && file_exists($this->metaFile);
    }
}
