<?php

namespace BitNinja\Framework\base;

use BitNinja\Framework\Api\V2\Adapter\AdapterInterface;
use BlueLog;
use GuzzleHttp\Exception\ClientException;
use Throwable;
use BlueCommandExec;
use ConfigManager;
use BitNinja\Framework\base\ConfigValidator;
use BitNinja\Framework\ContainerInstance;

/**
 * @author Peter Saller <peter.saller@bitninja.io>
 * @copyright © 2023 BitNinja Inc.
 * @package BitNinja
 */

class CloudConfig
{
    /**
     * @var AdapterInterface
     */
    private $client;
    /**
     * @var BlueLog
     */
    private $log;

    const OUTPUTDIR = DIRECTORY_SEPARATOR . "var" . DIRECTORY_SEPARATOR . "lib" . DIRECTORY_SEPARATOR . "bitninja" . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR;

    const ETCDIR = DIRECTORY_SEPARATOR . "etc" . DIRECTORY_SEPARATOR . "bitninja" . DIRECTORY_SEPARATOR;

    const CONFIGFILE = "config.ini";

    const WARNINGMESSAGE = "
    ; ########## WARNING ##########
    ; This is an automatically generated configuration file by BitNinja.
    ; Modifying the contents incorrectly can potentially lead to the malfunctioning of BitNinja.
    ; It is NOT recommended to change or modify any parameters by editing this file.
    ; Instead, it is recommended to change them on our dashboard:
    ; https://console.bitninja.io/configuration
    ; Any modifications should be done in accordance to our documentation: 
    ; https://doc.bitninja.io/docs/Cloudconfig
    ; ANY MODIFICATIONS ARE AT YOUR OWN RISK.
    ; ########## WARNING ##########
    ";

    public function __construct(AdapterInterface $client, BlueLog $log)
    {
        $this->client = $client;
        $this->log = $log;
    }

    /**
     * @return boolean
     */
    public function isCloudConfigEnabled(): bool
    {
        return !!ConfigManager::instance()->getIntKey('general', 'download_remote_config', 1);
    }


    public function getActiveCloudConfigModules(): array
    {
        $url = '/v2/cloudConfig/server/serverConfigurations/active';
        $cloudConfigActiveModules = array();
        try {
            $response = $this->client->get($url);
            $decoded = json_decode($response->getBody());
            if (!is_array($decoded->result)) {
                throw new \Exception(isset($decoded->message) ? $decoded->message : "Decoded response is missing important information");
            }
            $cloudConfigActiveModules = $decoded->result;
        } catch (ClientException $e) {
            $this->log->warn('Error occurred while getting active cloudconfig modules from the Cloud');
            $decoded = json_decode((string)$e->getResponse()->getBody(), true);
            if (isset($decoded['message']) && is_string($decoded['message'])) {
                $this->log->warn("Error was: " . $decoded["message"]);
            }
        } catch (Throwable $e) {
            $this->log->warn("Error occurred while getting active cloudconfig modules from the Cloud: " . $e->getMessage());
        }
        return $cloudConfigActiveModules;
    }

    public function getStatusFromApi()
    {
        $container = ContainerInstance::getInstance()->getContainer();
        $url = "/v2/cloudConfig/server/" . $container['server_id'] . "/moduleConfigurations/all/settings";
        try {
            $response = $this->client->get($url);
            $decoded = json_decode($response->getBody());

            if (!$this->validateDecodedResponse($decoded)) {
                throw new \Exception(isset($decoded->message) ? $decoded->message : "Decoded response is missing important information");
            }
            return $decoded->result;
        } catch (ClientException $e) {
            $this->log->warn('Error occurred while getting module statuses from the Cloud');
            $decoded = json_decode((string)$e->getResponse()->getBody(), true);
            if (isset($decoded['message']) && is_string($decoded['message'])) {
                $this->log->warn("Error was: " . $decoded["message"]);
            }
        } catch (Throwable $e) {
            $this->log->warn("Error occurred while getting module statuses from the Cloud: " . $e->getMessage());
        }
    }

    public function setStatusForModules(): void
    {
        $result = $this->getStatusFromApi();
        $config = \ConfigManager::instance()->getConfig('general');
        $varDir = $config['var_dir'];
        foreach ($result->modules as $moduleState) {
            if ($moduleState->isEditable) {
                $moduleStateFile = $varDir . DIRECTORY_SEPARATOR . implode(DIRECTORY_SEPARATOR, ["modules", $moduleState->name . ".state.dat"]);
                $actualModuleState = file_get_contents($moduleStateFile);
                if ((int)$actualModuleState !== (int)$moduleState->isEnabled) {
                    file_put_contents($moduleStateFile, (int)$moduleState->isEnabled);
                    $cmd = new BlueCommandExec("TurnOnOff", "local.{$moduleState->name}", (int)$moduleState->isEnabled, 'cli');
                    $cmd->queue()->catch(function ($e) {
                        $this->log->error($e->getMessage());
                    });
                }
            }
        }
    }

    public function downloadCloudConfigs(bool $reloadModules = true): bool
    {
        if ($this->beforeFirstTimeConfigSync()) {
            return false;
        }
        if (!$this->isCloudConfigEnabled()) {
            return false;
        }
        try {
            $this->log->info('Downloading Cloud configs');
            $response = $this->client->get("/v2/cloudConfig/server");
            $decoded = json_decode($response->getBody());
            if (!$this->validateDecodedResponse($decoded)) {
                throw new \Exception(isset($decoded->message) ? $decoded->message : "Decoded response is missing important information");
            }
            $this->persistCloudConfig($decoded->result, $reloadModules);
            $this->log->info("Cloud configuration downloaded.");
            return true;
        } catch (ClientException $e) {
            $this->log->warn('Error occurred while downloading configuration from the cloud.');
            $decoded = json_decode((string)$e->getResponse()->getBody(), true);
            if (isset($decoded['message']) && is_string($decoded['message'])) {
                $this->log->warn("Error was: " . $decoded["message"]);
                return false;
            }
        } catch (Throwable $e) {
            $this->log->warn("Error occurred while downloading configuration from the cloud: " . $e->getMessage());
            return false;
        }
    }

    private function beforeFirstTimeConfigSync(): bool
    {
        $migrationFile = self::OUTPUTDIR . "sync.dat";
        if (!file_exists($migrationFile)) {
            $this->dirExist();
            file_put_contents($migrationFile, " ");
            return true;
        }
        return false;
    }

    private function validateDecodedResponse(object $decoded): bool
    {
        if (!is_object($decoded)) {
            return false;
        }
        if (!(isset($decoded->result) && is_object($decoded->result))) {
            return false;
        }
        return true;
    }

    private function persistCloudConfig(object $config, bool $reloadModules = true): bool
    {
        if (!isset($config->config)) {
            return false;
        }
        $cloudConfigActiveModules = $this->getActiveCloudConfigModules();
        $configValidator = new ConfigValidator($this->log);
        foreach ($config->config as $moduleName => $configContent) {
            if (!empty($cloudConfigActiveModules) && !in_array($moduleName, $cloudConfigActiveModules)) {
                continue;
            }
            if ($this->dirExist()) {
                $jsonContent = json_encode($configContent, JSON_PRETTY_PRINT);
                if (!$configValidator->validateModuleConfig($jsonContent, $moduleName)) {
                    continue;
                }
                if ($this->compareWithPreviousConfig($moduleName, $jsonContent)) {
                    file_put_contents(self::OUTPUTDIR  . $moduleName . '.json', $jsonContent);
                    $this->persistCloudConfigIni($moduleName,  $jsonContent);
                    if ($reloadModules) {
                        $cmd = new \BlueCommandExec("RunModuleOption", "local." . $moduleName, "reload", "cli");
                        $cmd->queue()->catch(function ($e) {
                            $this->log->error($e->getMessage());
                        });
                    }
                }
            }
        }
        return true;
    }

    private function dirExist(): bool
    {
        if (is_dir(self::OUTPUTDIR)) {
            return true;
        }
        return mkdir(self::OUTPUTDIR, 0700, true);
    }

    private function compareWithPreviousConfig(string $moduleName, string $jsonContent): bool
    {
        $previusConfig = null;
        $configFile = self::OUTPUTDIR  . $moduleName . '.json';
        if (file_exists($configFile)) {
            $previusConfig = file_get_contents($configFile);
        }
        if ($previusConfig === $jsonContent) {
            return false;
        }
        return true;
    }

    private function persistCloudConfigIni(string $moduleName, $jsonConfigContent): void
    {
        if (!is_dir(self::ETCDIR . DIRECTORY_SEPARATOR . $moduleName)) {
            mkdir(self::ETCDIR . DIRECTORY_SEPARATOR . $moduleName, 0700, true);
        }
        $configContent = json_decode($jsonConfigContent, true);
        $iniData = self::WARNINGMESSAGE;
        $iniData .= $this->phpSerializedObjectToIniString($configContent);
        if (file_put_contents(self::ETCDIR . DIRECTORY_SEPARATOR . $moduleName . DIRECTORY_SEPARATOR . self::CONFIGFILE, $iniData)) {
            $this->log->info('Cloud configuration for ' . $moduleName . ' saved to ini format successfully');
            return;
        }
        $this->log->error('Failed to save ' . $moduleName . ' cloud configuration in ini format');
    }

    private function phpSerializedObjectToIniString(array $data, bool $hasMainParent = false): string
    {
        $iniFile = '';
        foreach ($data as $key => $value) {
            if (!$hasMainParent && is_array($value)) {
                $iniFile .= PHP_EOL . "[" . $key . "]" . PHP_EOL;
                $iniFile .= $this->phpSerializedObjectToIniString($value, true);
                continue;
            }
            if (is_array($value)) {
                foreach ($value as $subKey => $subValue) {
                    $newKey = is_numeric($subKey) ? "" :  $subKey;
                    if (is_numeric($subValue)) {
                        $iniFile .= $key . "[" . $newKey . "]=" . $subValue . PHP_EOL;
                    } else {
                        $iniFile .= $key . "[" . $newKey . "]='" . $subValue . "'" . PHP_EOL;
                    }
                }
                continue;
            }
            if (is_numeric($value)) {
                $iniFile .= $key . "=" . $value . PHP_EOL;
            } else {
                $iniFile .= $key . "='" . $value . "'" . PHP_EOL;
            }
        }
        return $iniFile;
    }
}
