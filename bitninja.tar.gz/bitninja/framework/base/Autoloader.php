<?php


/**
 * This is the parent class. The common functions should be written here.
 * This handles the autoload of the necessary files.
 * Usage:
 *
 * include('framework/base/Autoloader');
 *
 * It does the rest.
 * Important! The system expects the class name to be the same
 * as the .php file!
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class Autoloader
{
    /**
     * @var Autoloader
     */
    private static $instance;

    /**
     * Path to the system directories.
     * This can be expanded with the
     * addAutoloadPath($path) function.
     *
     * @var array
     */
    private static $system_dirs = array(
        'base',
        'log',
        'blue',
        'worker',
        'commands',
        'pattern',
        'rabbitmq',
        'heimdall',
        'systemCommands',
        'wrapper',
        'networking',
        'mpf',
        'scriptExecutor',
        'traits',
        'OsCommandWrappers',
        'IPCQueue',
    );

    /**
     * @var array
     */
    private $prefixLengthsPsr4 = array();

    /**
     * @var array
     */
    private $prefixDirsPsr4 = array();

    /**
     * @var \Nette\Loaders\RobotLoader
     */
    private $classfinder;

    /**
     * @param string $prefix
     * @param string $paths
     * @return void
     */
    public function addPsr4($prefix, $paths)
    {
        $length = strlen($prefix);
        $this->prefixLengthsPsr4[$prefix[0]][$prefix] = $length;
        $this->prefixDirsPsr4[$prefix] = (array)$paths;
    }

    /**
     * @return void
     */
    private function loadPsr4Prefixes()
    {
        $this->addPsr4('BitNinja\\Framework\\', dirname(dirname(__FILE__)));
        $this->addPsr4('BitNinja\\modules\\', dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . 'modules');
        $this->addPsr4('BitNinja\\Common\\', dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . 'Common');
    }

    /**
     * Because of the Singleton Pattern, the construct is private.
     * We only need 1 copy of this.
     *
     * @return void
     */
    private function __construct()
    {
        $this->loadPsr4Prefixes();
        spl_autoload_register(array('Autoloader', 'autoloadPsr4'));
        spl_autoload_register(array('Autoloader', 'autoload'), false, false);
        $this->loadContrib();
    }

    /**
     * Load the Contrib directory.
     * These are not used by all the processes, so
     * should be loaded only if needed.
     *
     * Usage:
     * Autoloader::loadContrib();
     *
     * @return void
     */
    public static function loadContrib()
    {
        include_once(__DIR__ . '/../contrib/vendor/autoload.php');
    }

    /**
     * Inlcude a file relative to the basedir of the project
     *
     * @param string $file
     * @return void
     */
    public function include_once_file($file)
    {
        include_once(__DIR__ . '/../../' . $file);
    }

    /**
     * Get the singleton instance.
     *
     * @return Autoloader
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            self::$instance = new Autoloader();
        }
        return self::$instance;
    }

    /**
     * @param string $class
     * @return boolean
     */
    public function autoloadPsr4($class)
    {
        $logicalPathPsr4 = strtr($class, '\\', DIRECTORY_SEPARATOR) . '.php';

        $first = $class[0];
        if (isset($this->prefixLengthsPsr4[$first])) {
            $subPath = $class;
            while (false !== $lastPos = strrpos($subPath, '\\')) {
                $subPath = substr($subPath, 0, $lastPos);
                $search = $subPath . '\\';
                if (isset($this->prefixDirsPsr4[$search])) {
                    $pathEnd = DIRECTORY_SEPARATOR . substr($logicalPathPsr4, $lastPos + 1);
                    foreach ($this->prefixDirsPsr4[$search] as $dir) {
                        if (file_exists($file = $dir . $pathEnd)) {
                            try {
                                include_once($file);
                            } catch (Exception $ex) {
                                echo $ex->getMessage();
                                die;
                            }

                            return class_exists($class, false) || interface_exists($class, false) || trait_exists($class, false);
                        }
                    }
                }
            }
        }
        return false;
    }
    /**
     * Autoload function for the corresponding class.
     *
     * @param string $className
     * @return boolean
     */
    public static function autoload($className)
    {
        //var_dump($className);

        /**
         * Try to guess the module based on the namespace
         */
        if (strpos($className, '\\') !== false) {
            $arr = explode('\\', $className);
            $arr_rev = array_reverse($arr);

            if (self::try_load(__DIR__ . '/../../modules/' . $arr_rev[1] . '/' . $arr_rev[0] . '.php')) {
                return class_exists($className, false) || interface_exists($className, false);
            }

            if (self::try_load(__DIR__ . '/../../modules/' . $arr_rev[1] . '/lib/' . $arr_rev[0] . '.php')) {
                return class_exists($className, false) || interface_exists($className, false);
            }

            if (self::try_load(__DIR__ . '/../../modules/' . $arr_rev[1] . '/commands/' . $arr_rev[0] . '.php')) {
                return class_exists($className, false) || interface_exists($className, false);
            }

            // Could not guess, go on with the classname.
            $className = $arr_rev[0];
        }


        foreach (self::$system_dirs as $dir) {
            if (self::try_load(__DIR__ . '/../' . $dir . '/' . $className . '.php')) {
                return class_exists($className, false) || interface_exists($className, false);
            }

            if ($dir[0] == '/') {
                if (self::try_load($dir . '/' . $className . '.php')) {
                    return class_exists($className, false) || interface_exists($className, false);
                }
            }
        }

        $autoloaders = spl_autoload_functions();
        if (count($autoloaders) > 1) {
            // There are further autoloaders, so we don't fail.
            return;
        }

        $exceptions = array('ClassLoader', 'PHPUnit_Extensions_Story_TestCase');
        if (in_array($className, $exceptions)) {
            return;
        }

        if (class_exists('BlueLog')) {
            $log = BlueLog::instance('blue.base.Autoloader');
            $log->error('Class [' . $className . '] cloud not be loaded.');
            $log->debug('Search paths:');
            foreach (self::$system_dirs as $dir) {
                $log->debug($dir);
            }
            return;
        }
        echo "Error! Class [" . $className . "] cloud not be loaded.\n";
        echo "Search path: \n";
        foreach (self::$system_dirs as $dir) {
            echo ($dir . "\n");
        }
    }

    /**
     * @param string $f_path
     * @return boolean
     */
    private static function try_load($f_path)
    {
        if (is_file($f_path)) {
            include_once($f_path);
            return true;
        }
        return false;
    }

    /**
     * Add more directories to the autoload path.
     *
     * @param string $path
     * @return void
     */
    public function addAutoloadPath($path)
    {
        self::$system_dirs[$path] = $path;
    }

    /**
     * Add more modules to the autoload path.
     *
     * @param string $path
     * @return void
     */
    public function addModulePath($path)
    {
        self::$system_dirs['../modules/' . $path] = '../modules/' . $path;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        $str = 'Autolading paths:' . "\n";
        foreach (self::$system_dirs as $dir => $v) {
            $str .= "  " . $dir . "\n";
        }
        return $str;
    }
    /**
     * @param boolean $refreshCache Should we refresh the stored class cache file
     * @param string $tmpDir Path where class list cache file are stored. Default is ConfigManager::instance()->getAgentTmpPath()
     * @return array<string, string>  class => filename
     */
    public function findAgentClasses($refreshCache = false, $tmpDir = false)
    {
        if (is_null($this->classfinder)) {
            $this->classfinder = new \Nette\Loaders\RobotLoader();
        }
        if (!$tmpDir) {
            $tmpDir = ConfigManager::instance()->getAgentTmpPath();
        }
        $agentDir = dirname(dirname(__DIR__));
        $this->classfinder->setTempDirectory($tmpDir . 'ClassCache');
        $this->classfinder->addDirectory($agentDir);
        $this->classfinder->excludeDirectory($agentDir . '/framework/contrib/');
        $this->classfinder->register();
        if ($refreshCache) {
            $this->classfinder->refresh();
        }
        return $this->classfinder->getIndexedClasses();
    }
    /**
     * @param string $parentClass
     * @param string $filterPath Eg.: /commands/
     * @param boolean $refreshCache Should we refresh the stored class cache file
     * @return  array<string, string>  class => filename
     */
    public function findAgentClassExtendingClass(string $parentClass, string $filterPath = null, $refreshCache = false)
    {
        $tmpdDir  = ConfigManager::instance()->getAgentTmpPath() . 'ClassCache';
        $tmpFile = $tmpdDir . DIRECTORY_SEPARATOR . md5($parentClass . $filterPath) . '.cache';
        if ($refreshCache === false && file_exists($tmpFile)) {
            return json_decode(file_get_contents($tmpFile), true);
        }
        $children = [];
        foreach ($this->findAgentClasses($refreshCache) as $class => $path) {
            if (!is_null($filterPath) && strpos($path, $filterPath) === false) {
                continue;
            }
            try {
                @$r = new \ReflectionClass('\\' . $class);
                if ($r->isSubclassOf($parentClass)) {
                    $children['\\' . $class] = $path;
                }
            } catch (Throwable $e) {
                continue;
            }
        }
        file_put_contents($tmpFile, json_encode($children, JSON_PRETTY_PRINT));
        return $children;
    }
}

$autoloader = Autoloader::instance();
