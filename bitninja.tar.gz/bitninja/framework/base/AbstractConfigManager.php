<?php

use Noodlehaus\Config;

/**
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author     Zsolt Egri <ezsolt@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.0
 */
abstract class AbstractConfigManager
{

    /**
     * Stores every loaded configuration
     *
     * @var array
     */
    protected $config = [];

    /**
     * Stores every loaded config file paths.
     * It can be used the reload them if needed.
     *
     * @var array
     */
    protected $parsedConfigs = [];
    protected $remoteConfig = [];
    public $cloudConfig = [];

    /**
     * @var ?BlueLicenceManager $licenseManager
     */
    private $licenseManager = null;

    /**
     * Parses a given config file and megreg with
     * the current configuration.if there is any.
     *
     * @param string $configFilePath
     * @return void
     */
    public function parseConfig($configFilePath)
    {
        $config = null;

        try {
            $config = Config::load($configFilePath);
        } catch (Exception $e) {
            $this->_log('error', $e->getMessage() . " [$configFilePath]");
        }
        if ($config == null) {
            $config = array();
        }
        $this->parsedConfigs[$configFilePath] = $configFilePath;
        $config = $this->loadSpecialConfig($configFilePath, $config);
        $this->config = static::arrayMergeRecursive($this->config, $config);
    }
    /**
     * If the server is noLicense then a custom config is given to MalwareDetection
     */
    public function loadSpecialConfig(string $configFilePath, $config)
    {
        if ($configFilePath == "/etc/bitninja/MalwareDetection/config.ini") {
            if ($this->getLicenseManager() != null && $this->getLicenseManager()->getLicence() == "inactive") {
                $noLicenseConfigPath = DIRECTORY_SEPARATOR . implode(DIRECTORY_SEPARATOR, ["opt", "bitninja", "modules", "MalwareDetection", "resources", "customConfig"]);
                $noLicenseEncodedConfig = file_get_contents($noLicenseConfigPath);
                $noLicenseDecodedConfig = base64_decode(str_rot13($noLicenseEncodedConfig));
                $cloudConfig = json_decode($noLicenseDecodedConfig, true);
                $config = $cloudConfig;
            }
        }

        return $config;
    }

    protected function _log($level = "error", $message = "")
    {
        echo "|$level| $message\n";
    }
    /**
     * Return the key, or null if it was not found.
     *
     * @param string $section
     * @param string $key
     * @param mixed $default
     * @return null|mixed
     */
    public function getKey($section, $key, $default = null)
    {
        $config = $this->getConfig($section);
        if (!isset($config[$key])) {
            if (isset($default)) return $default;
            return null;
        }
        return $config[$key];
    }
    /**
     * @param array $configs
     * @return static
     */
    public function setRemoteConfig(array $configs)
    {
        $this->remoteConfig = $configs;
        return $this;
    }

    /**
     * @return array
     */
    public function getRemoteConfig()
    {
        return $this->remoteConfig;
    }

    /**
     * @return array
     */
    public function getCloudConfig()
    {
        return $this->cloudConfig;
    }

    public function setCloudConfig(array $configs)
    {
        $this->cloudConfig = $configs;
        return $this;
    }

    public function loadSupportedConfigFileInDirectory($directory)
    {
        foreach (['ini', 'json', 'yml', 'yaml', 'xml', 'php'] as $ext) {
            $configFile = $directory . DIRECTORY_SEPARATOR . "config.$ext";
            if (is_file($configFile)) {
                $this->parseConfig($configFile);
                return $configFile;
            }
        }
    }
    /**
     * @todo The default configuration should be not stored as a actual configuration file. Instead we should add a config definition class.
     * @see https://packagist.org/packages/symfony/config
     * @see https://packagist.org/packages/symfony/options-resolver
     * @return void
     */
    abstract protected function loadDefaultConfig();

    /**
     *
     * @param string $section
     * @param string $key
     * @param mixed $value
     * @return static
     */
    public function setKey(string $section, string $key, $value)
    {
        if (empty($section) || empty($key)) {
            return null;
        }
        if (!isset($this->config[$section])) {
            $this->config[$section] = [];
        }
        $this->config[$section][$key] = $value;
        return $this;
    }
    /**
     *
     * @param string $section
     * @param string $key
     * @return boolean
     */
    public function hasKey(string $section, string $key)
    {
        return isset($this->config[$section][$key]);
    }
    /**
     * Helper function to get the all config from the singleton instance.
     *
     * @return array
     */
    protected function getAllConfig()
    {
        return $this->config;
    }

    /**
     * @param array $base
     * @param array $newData
     * @param bool $keepOrder
     * @return array
     */
    protected static function arrayMergeRecursive($base,  $newData, $keepOrder = false)
    {
        $result = $base;
        $count = 0;
        foreach ($newData as $newKey => $newElement) {
            $elementToInsert = $newElement;
            if (array_key_exists($newKey, $base) && is_array($base[$newKey]) && is_array($newElement)) {
                if (strpos($newKey, 'order') !== false) {
                    $keepOrder = true;
                }
                $elementToInsert = self::arrayMergeRecursive($base[$newKey], $newElement, $keepOrder);
            }
            if (!$keepOrder && isset($result[$newKey]) && is_int($newKey) && array_search($newKey, array_keys($result)) === $count) {
                $result[] = $elementToInsert;
                $result = array_unique($result);
            } else {
                $result[$newKey] = $elementToInsert;
            }
            $count++;
        }
        return $result;
    }

    /**
     * Return a part of the config.
     * The part can
     * be defined by the section variable.
     *
     * @param string $section
     * @param boolean $printError
     * @return Config|array
     */
    public function getConfig($section = null, $printError = true)
    {
        $config = $this->getAllConfig();
        if ($section === null) {
            return $config;
        }
        if (!isset($config[$section])) {
            // Don t use logging here as it can cause and infinite loop if there is no config file!
            // $this->log->warning('Error! Config section [' . $section . '] not found!');
            if ($printError) {
                echo ('Error! Config section [' . $section . '] not found!');
            }
            return [];
        }
        return $config[$section];
    }

    /**
     * Ensures that the given key is numeric.
     *
     * @param string $section Name of the ini section
     * @param string $key Name of the key
     * @param integer $default The deafult value if key not found or not numeric
     * @return integer
     */
    public function getIntKey($section, $key, $default = 0)
    {
        $key = $this->getKey($section, $key);
        return is_numeric($key) ? $key : $default;
    }

    /**
     * Ensures that the given key is sting from a list. Case insensive.
     *
     * @param string $section Name of the ini section
     * @param string $key Name of the key
     * @param array $availableOptions list of available options
     * @param string $default The deafult value if key not found
     * @return string the given key value in lower case, or the default value if not found.
     */
    public function getStringOptionFromOptionArray($section, $key, $availableOptions, $default = '')
    {
        if (!is_array($availableOptions) || !is_string($default)) {
            return '';
        }
        $key = strtolower(trim($this->getKey($section, $key)));

        return in_array($key, array_map('strtolower', $availableOptions)) ? $key : $default;
    }


    public function getLicenseManager()
    {
        return $this->licenseManager;
    }

    public function setLicenseManager(?BlueLicenceManager $licenseManager)
    {
        $this->licenseManager = $licenseManager;
        return $this;
    }
}
