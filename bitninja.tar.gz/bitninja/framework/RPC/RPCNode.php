<?php

namespace BitNinja\Framework\RPC;

use BitNinja\Framework\RPC\Exception\RequestRuntimeExceptionWrapper;
use BitNinja\Framework\RPC\Exception\RequestTimeout;
use hisorange\PosixRPC\Contract\IMessage;
use hisorange\PosixRPC\Message;
use hisorange\PosixRPC\Node;
use React\EventLoop\LoopInterface;
use React\Promise\PromiseInterface;
use React\Promise\Deferred;

use function React\Promise\Timer\timeout;

/**
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class RPCNode extends Node
{

    /**
     *
     * @inheritDoc
     * @param integer $timeout
     * @param callback $handler
     * @param int $timeout
     * @throws RequestTimeout
     * @return string
     */
    public function request(string $channel, $payload = null, callable $handler = null,  $timeout = 30)
    {
        $isSynchronous = $handler === null;
        if (!is_numeric($timeout) || $timeout < 0) {
            $timeout = 1;
        }
        $utimeout = microtime(true) + $timeout;
        // Synchronous call when no handler is provided.
        if ($isSynchronous) {
            $isArrived = false;
            $responseProxy = null;

            // Local handler to dispatch the proxied result.
            $handler = function (IMessage $response) use (&$isArrived, &$responseProxy) {
                $isArrived = true;
                $responseProxy = $response->getPayload();
            };
        }

        $request = new Message($payload, ['valid-till' => $utimeout]);

        $this->replyRouter->register($request, $handler);
        $this->publish($channel, $request);

        if ($isSynchronous) {
            while (!$isArrived) {
                if (microtime(true) > $utimeout) {
                    $this->logger->debug('Request timeout');
                    throw new RequestTimeout();
                }
                $this->tick();

                usleep(1000);
            }
            if (is_string($responseProxy) && strpos($responseProxy, 'O:63:"BitNinja\Framework\RPC\Exception\RequestRuntimeExceptionWrapper"') === 0) {
                $responseProxy = unserialize($responseProxy);
                $responseProxy->reThrow();
            }
            return $responseProxy;
        }
    }
    public function promiseTimeoutRequest(string $channel, LoopInterface $loop, $payload = null,  $timeout = 30): PromiseInterface
    {
        $deferred = new Deferred();
        if (!is_numeric($timeout) || $timeout < 0) {
            $timeout = 1;
        }
        $utimeout = microtime(true) + $timeout;
        $handler = function (IMessage $response) use (&$deferred, $utimeout) {
            if (microtime(true) > $utimeout) {
                $deferred->reject(new RequestTimeout());
            }
            $responseProxy = $response->getPayload();
            if (is_string($responseProxy) && strpos($responseProxy, 'O:63:"BitNinja\Framework\RPC\Exception\RequestRuntimeExceptionWrapper"') === 0) {
                $responseProxy = unserialize($responseProxy);
                $deferred->reject($responseProxy->getException());
                return;
            }
            $deferred->resolve($response->getPayload());
        };
        $request = new Message($payload, ['valid-till' => $utimeout]);

        $this->replyRouter->register($request, $handler);
        $this->publish($channel, $request);
        $that = $this;
        $that->tick();
        $timer = $loop->addPeriodicTimer(.1, function () use ($that) {
            $that->tick();
        });
        $promise = $deferred->promise();

        timeout($promise, $timeout, $loop)
            ->then(
                function ($result) use ($loop, $timer) {
                    $loop->cancelTimer($timer);
                    return $result;
                }
            )->catch(
                function ($e) use ($deferred, $loop, $timer) {
                    $loop->cancelTimer($timer);
                    $deferred->reject($e);
                }
            );
        return $promise;
    }
    /**
     * @inheritDoc
     */
    public function respond(string $channel, callable $handler): void
    {
        $this->transport->subscribe($channel, function (IMessage $request) use ($handler) {
            if (!is_null($utimeout = $request->getMeta('valid-till')) && (microtime(true) > $utimeout)) {
                //request timeout not need to response.
                return;
            }
            // Execute the handler to create the result.
            try {
                $response = $handler($request);
            } catch (\Throwable $e) {
                $response = new RequestRuntimeExceptionWrapper($e);
            }
            if (!($response instanceof PromiseInterface)) {
                $response = $response instanceof Message ? $response : is_object($response) ? new Message(serialize($response)) : new Message($response);

                // Associate the reply with the request message.
                $response->setMeta('reply-for', $request->getId());

                $this->publish($request->getMeta('reply-to'), $response);
                return;
            }
            $that = $this;
            $response
                ->then(
                    function ($response) use ($request, $that) {
                        if (!is_null($utimeout = $request->getMeta('valid-till')) && (microtime(true) > $utimeout)) {
                            //request timeout not need to response.
                            return;
                        }
                        // Execute the handler to create the result.
                        $response = $response instanceof Message ? $response : is_object($response) ? new Message(serialize($response)) : new Message($response);

                        // Associate the reply with the request message.
                        $response->setMeta('reply-for', $request->getId());

                        $that->publish($request->getMeta('reply-to'), $response);
                    }
                )->catch(function ($e) use ($request, $that) {
                    $response = new Message(serialize(new RequestRuntimeExceptionWrapper($e)));
                    $response->setMeta('reply-for', $request->getId());

                    $that->publish($request->getMeta('reply-to'), $response);
                });
        });
    }
}
