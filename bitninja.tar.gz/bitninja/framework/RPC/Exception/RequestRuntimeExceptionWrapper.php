<?php

namespace BitNinja\Framework\RPC\Exception;

use Reflection;
use ReflectionClass;

/**
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class RequestRuntimeExceptionWrapper
{
    /**
     * @var string
     */
    public $class;
    /**
     * @var string
     */
    public $message;
    /**
     * @var string
     */
    public $code;

    /**
     * @param string $exception
     * @throws Exception
     * @return void
     */
    public function __construct(\Throwable $exception)
    {
        $this->class = get_class($exception);
        $this->message = $exception->getMessage();
        $this->code = $exception->getCode();
    }

    /**
     * @throws Exception
     * @return void
     */
    public function reThrow()
    {
        if (!is_null($e = $this->getException())) {
            throw $e;
        }
    }

    /**
     * @return mixed
     */
    public function getException()
    {
        $class = $this->class;
        $ref = new ReflectionClass($class);
        if ($ref->isSubclassOf('Throwable')) {
            return new $class($this->message, $this->code);
        }
        return null;
    }
}
