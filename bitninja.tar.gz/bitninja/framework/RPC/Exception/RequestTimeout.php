<?php

namespace BitNinja\Framework\RPC\Exception;

use RuntimeException;

/**
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class RequestTimeout extends RuntimeException
{
    /**
     * @param string $message
     * @return void
     */
    public function __construct($message = "RPC request timeout")
    {
        parent::__construct($message);
    }
}
