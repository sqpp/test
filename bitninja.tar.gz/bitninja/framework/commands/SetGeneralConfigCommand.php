<?php

/**
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     Framework
 * @subpackage  Commands
 * @version     2.24.0
 */
class SetGeneralConfigCommand extends \BlueBaseCommand
{

    /**
     * Modifies the run time general configuration
     *
     * @param string $section
     * @param string $key
     * @param mixed $value
     * @return boolean
     */
    public function run($section = null, $key = null, $value = null)
    {
        ConfigManager::instance()->setKey($section, $key, $value);
        return ConfigManager::instance()->hasKey($section, $key);
    }
}
