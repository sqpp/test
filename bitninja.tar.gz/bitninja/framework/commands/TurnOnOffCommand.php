<?php

/**
 * Turning module MalwareDetection on/off
 * https://bitninja.io
 *
 * @usage Enable/diable MalwareDetection
 * <code>
 * bitninjacli --module=MalwareDetection --enabled
 * bitninjacli --module=MalwareDetection --disabled
 * </code>
 *
 * @author      Jozsef Palfi <joseph@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     MalwareDetection
 * @subpackage  Commands
 * @version     1.11.0
 */
class TurnOnOffCommand extends \BlueBaseCommand
{

    /**
     * Command entry point
     *
     * @param int    $module_state Enable or disable module; 1|0
     * @param string $from         Source of command; admin|cli
     *
     * @return void
     */
    public function run($module_state, $from)
    {
        $worker = $this->getCommandMessage()->getWorker();
        if (!$worker->canTurnOnOrOff()) {
            $this->log->debug('Module can\'t be enabled or disabled');
            return false;
        }
        $cm = \ConfigManager::instance();
        $module_state_file = $cm->getKey("general", "var_dir") . DIRECTORY_SEPARATOR . "modules" .
            DIRECTORY_SEPARATOR . $worker->getModuleName() . ".state.dat";

        file_put_contents($module_state_file, $module_state);
        $worker->setEnabled($module_state);

        if ($from == "cli") {
        }
        return true;
    }
}
