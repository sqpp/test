<?php

/**
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     Framework
 * @subpackage  Commands
 * @version     1.18.9
 */
class StatusAllCommand extends \BlueBaseCommand
{

    /**
     * Add an IP to the fail2ban service.
     *
     * @param string $moduleName
     * @return string
     */
    public function run($moduleName = null)
    {
        /** @var ModuleWorker */
        $worker = $this->getCommandMessage()->getWorker();
        return $worker->getStatus($moduleName);
    }
}
