<?php

/**
 * This command will download CaptchaHttp configuration.
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package	BitNinja
 * @subpackage  CaptchaHttp
 * @version     1.18.9
 */

class DownloadModuleConfigCommand extends \BlueBaseCommand
{

    /**
     * @param string $config_type
     * @param string $download_link
     * @return boolean
     */
    public function run($config_type, $download_link)
    {
        $worker = $this->getCommandMessage()->getWorker();
        $module_name = $worker->getModuleName();
        $this->log->info('Downloading ' . $module_name . ' config files.');
        $dirname = \ConfigManager::instance()->getConfig('general')['var_dir'] . DIRECTORY_SEPARATOR . $module_name;
        $fname = $dirname . '/' . $module_name . '-' . $config_type . '.tar.gz';

        if (!is_dir($dirname)) {
            mkdir($dirname, 0700, true);
            $this->log->info('Data directory [' . $dirname . '] is created.');
        }

        $api = \HeimdallHttpApi::instance();
        if (!$api->stream_download_config($download_link, $fname)) {
            $this->error("Can't download $module_name configrations.");
            return false;
        }
        $unTarDir = '/var/lib/bitninja/' . $module_name . '/conf';
        if (!is_dir($unTarDir)) {
            mkdir($unTarDir);
        }
        $cmd = new \BlueCmdBuilder('tar', [
            'xvzf',
            $fname,
            '-C',
            $unTarDir
        ]);
        $cmd->execute();


        $workdir = "/etc/bitninja/{$module_name}";

        if (!is_dir($workdir)) {
            mkdir($workdir, 0700, true);
        }

        if (method_exists($worker, 'downloadConfig')) {
            $workdir = $worker->downloadConfig($config_type, $unTarDir);
        }

        \BlueExec::exec("cp -afR $unTarDir/* $workdir");
        $this->success("$module_name configuration downloaded.");
        \BlueExec::exec("rm -fR $unTarDir/*");
        $worker = $this->getCommandMessage()->getWorker();
        $this->log->info('Reloading configurations');
        $worker->reloadConfigs();
    }
}
