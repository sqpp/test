<?php

/**
 * @author      Jancsik Balázs <balazs.jancsik@bitninja.io>
 * @copyright   © 2022 BitNinja Inc.
 * @package     Framework
 * @subpackage  Commands
 * @version     2.38.5
 */
class MqStartCommand extends \BlueBaseCommand
{

    public function run()
    {
        /** @var ProcessController */
        $worker = $this->getCommandMessage()->getWorker();
        return $worker->mqStart();
    }
}
