<?php

/**
 * Command class to ping a module.
 *
 * @author     Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright  © 2021 BitNinja Inc.
 * @package    BitNinja
 * @subpackage Framework
 * @version    2.23.3
 */
class PingCommand extends \BlueBaseCommand
{

    public function run()
    {
        $worker = $this->getCommandMessage()->getWorker();
        return $worker->ping();
    }
}
