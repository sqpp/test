<?php

use BitNinja\Common\Module\Contract\IWorker;

/**
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     Framework
 * @subpackage  Commands
 * @version     1.18.9
 */
class StatusCommand extends \BlueBaseCommand
{

    /**
     * Add an IP to the fail2ban service.
     *
     * @return string
     */
    public function run()
    {
        /** @var IWorker */
        $worker = $this->getCommandMessage()->getWorker();
        return $worker->getStatus();
    }
}
