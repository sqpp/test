<?php
/**
 * This command will send a download configuration request to API, when no configuration file available.
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  DosDetection
 * @version     1.18.9
 */

class GetConfigCommand extends \BlueBaseCommand
{
    /**
     * @param string $module_name
     * @param string $config_type
     * @return void
     */
    public function run($module_name, $config_type)
    {
        $this->log->info('Getting downloadable config file from API.');
        $api = \HeimdallHttpApi::instance();
        $hash = $api->request('triggerConfig', [
            'module_name' => $module_name,
            'config_type' => $config_type
        ], 'post');
        $this->log->debug('Response was [' . var_export($hash, true) . ']');
    }
}
