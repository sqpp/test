<?php

/**
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     Framework
 * @subpackage  Commands
 * @version     2.24.0
 */
class GetModuleConfigCommand extends \BlueBaseCommand
{
    /**
     * Returns the run time module configuration.
     *
     * @param string $section
     * @return array
     */
    public function run($section = null)
    {
        $worker = $this->getCommandMessage()->getWorker();
        return $worker->getModuleConfig($section);
    }
}
