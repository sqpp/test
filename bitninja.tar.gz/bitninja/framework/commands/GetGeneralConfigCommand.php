<?php

/**
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     Framework
 * @subpackage  Commands
 * @version     2.24.0
 */
class GetGeneralConfigCommand extends \BlueBaseCommand
{

    /**
     * Returns the run time general configuration
     * @param string $section
     * @return string
     */
    public function run($section = null)
    {
        return ConfigManager::instance()->getConfig($section);
    }
}
