<?php

/**
 * Run module options
 * https://bitninja.io
 *
 * @usage Examle usage: reload AntiFlood configs
 * <code>
 * bitninjacli --module=AntiFlood --reload
 * </code>
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     AntiFlood
 * @subpackage  Commands
 * @version     1.18.9
 */
class RunModuleOptionCommand extends \BlueBaseCommand
{

    /**
     * Command entry point
     *
     * @param int    $module_state reload; 1
     * @param string $from         Source of command; admin|cli
     *
     * @return void
     */
    public function run($module_state, $from)
    {
        $worker = $this->getCommandMessage()->getWorker();

        if ($module_state === 0 || $module_state === 'reload') {
            $this->log->info('Reloading config');
            $worker->reloadConfigs();
            return;
        }
    }
}
