<?php

use GuzzleHttp\Exception\ClientException;

/**
 * Run Process options on a module. Modules can be started stoped and restarted by this command.
 * https://bitninja.io
 *
 * @usage start/stop/restart module
 * <code>
 * bitninjacli --module=ModuleName --start
 * bitninjacli --module=ModuleName --stop
 * bitninjacli --module=ModuleName --restart
 * * </code>
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     Framework
 * @subpackage  Commands
 * @version     1.18.9
 */
class RunProcessOptionsCommand extends \BlueBaseCommand
{

    /**
     * Command entry point
     *
     * @param string $moduleName   Name of the module
     * @param string $moduleState  start,stop or restart  module
     * @param string $from         Source of command; admin|cli default is cli
     *
     * @return void
     */
    public function run($moduleName, $moduleState, $from = 'cli')
    {
        /** @var ProcessController $worker */
        $worker = $this->getCommandMessage()->getWorker();
        switch ($moduleState) {
            case 'stop':
                $this->log->info('Stopping ' . $moduleName . ' module from ' . $from);
                $this->callApi($moduleName, false);
                return $worker->stopProcess($moduleName);
            case 'start':
                $this->log->info('Starting ' . $moduleName . ' module from ' . $from);
                $this->callApi($moduleName, true);
                return $worker->startProcess($moduleName);
            case 'restart':
                $this->log->info('Restarting ' . $moduleName . ' module from ' . $from);
                return $worker->restartProcess($moduleName);
            default:
                $this->log->warn("Tried to run an unknown process option: $moduleState");
                return false;
        }
    }

    private function callApi($moduleName, $state, $retry = 0)
    {

        $params['isEnabled'] = $state;
        $params['sendToServer'] = false;
        $container = \BitNinja\Framework\ContainerInstance::instance()->getContainer();
        $client = $container['licence_client'];
        try {
            $client->post("/v2/cloudConfig/tags/server/" . $container['server_id'] . "/moduleConfigurations/" . $moduleName . "/settings", $params);
        } catch (ClientException $e) {
            $this->log->warn('Error occurred while send new status to Bitninja Certal');
            $decoded = json_decode((string)$e->getResponse()->getBody(), true);
            if (isset($decoded['message']) && is_string($decoded['message'])) {
                $this->log->warn("Error was: " . $decoded["message"]);
                $retry = $retry + 1;
                if ($retry <= 10) {
                    sleep(5);
                    return $this->callApi($moduleName, $state, $retry);
                }
            }
        } catch (Throwable $e) {
            $this->log->warn("Error occurred while sending new status to Bitninja Central: " . $e->getMessage());
            $retry =  $retry + 1;
            if ($retry <= 10) {
                sleep(5);
                return $this->callApi($moduleName, $state, $retry);
            }
        }
    }
}
