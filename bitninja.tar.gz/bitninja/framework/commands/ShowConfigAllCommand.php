<?php

/**
 * Send agent logs to API.
 * https://bitninja.io
 * 
 * @author     Gyula Hosszú <gyula.hosszu@bitninja.io>
 * @copyright  © 2023 BitNinja Inc.
 * @subpackage  Commands
 */
class ShowConfigAllCommand extends \BlueBaseCommand
{

    public function run(?string $moduleName = null)
    {
        /** @var ProcessController */
        $worker = $this->getCommandMessage()->getWorker();
        return $worker->getAllModuleConfigurations($moduleName);
    }
}
