<?php

/**
 * @author      Daniel Bettenbuk <daniel.bettenbuk@bitninja.io>
 * @copyright   © 2023 BitNinja Inc.
 */
class ReloadMainProcessCommand extends \BlueBaseCommand
{

    /**
     * Reloads all configurations related to the main process
     *
     * @return boolean
     */
    public function run()
    {
        /** @var ProcessController $worker */
        $worker = $this->getCommandMessage()->getWorker();
        return $worker->reloadConfigs();
    }
}
