<?php

/**
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     Framework
 * @subpackage  Commands
 * @version     2.24.0
 */
class SetModuleConfigCommand extends \BlueBaseCommand
{

    /**
     * Modifies a module's run time module configuration
     *
     * @param string $section
     * @param string $key
     * @param mixed $value
     * @return boolean
     */
    public function run($section = null, $key = null, $value = null)
    {
        $worker = $this->getCommandMessage()->getWorker();
        $worker->setModuleConfigKey($section, $key, $value);
    }
}
