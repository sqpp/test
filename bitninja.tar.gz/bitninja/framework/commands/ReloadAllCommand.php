<?php

/**
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     Framework
 * @subpackage  Commands
 * @version     2.27.0
 */
class ReloadAllCommand extends \BlueBaseCommand
{

    /**
     * Reloads all configuration
     *
     * @return boolean
     */
    public function run()
    {
        /** @var ProcessController $worker */
        $worker = $this->getCommandMessage()->getWorker();
        return $worker->reloadAllConfig();
    }
}
