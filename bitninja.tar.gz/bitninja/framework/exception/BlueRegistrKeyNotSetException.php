<?php

/**
 *  BitNinja Server Security
 *  All rights reserved.
 *  https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BlueRegistrKeyNotSetException
{
    /**
     * @var string
     */
    private $key;
    
    /**
     * @param string $key
     * @return void
     */
    public function __construct($key)
    {
        $this->key = $key;
    }
}
