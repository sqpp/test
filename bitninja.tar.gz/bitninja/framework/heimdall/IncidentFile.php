<?php

/**
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Toma Zoltan <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentFile implements \JsonSerializable
{
    use TraitAccessors;

    /**
     * The path to file.
     * 
     * @var string
     */
    protected $filePath;
    /**
     * @var string
     */
    protected $directory;
    /**
     * @var string
     */
    protected $fileName;
    /**
     * @var int
     */
    protected $size;
    /**
     * @var string
     */
    protected $owner;
    /**
     * @var string
     */
    protected $group;
    /**
     * @var string
     */
    protected $aTime;
    /**
     * @var string
     */
    protected $mTime;
    /**
     * @var string
     */
    protected $cTime;
    /**
     * @var string
     */
    protected $access;
    /**
     * @var string
     */
    protected $md5_hash;

    /**
     * @var string
     */
    protected $uid;
    /**
     * @var string
     */
    protected $gid;

    /**
     * @return array
     */
    protected function attributes()
    {
        return [
            'filePath',
            'directory',
            'fileName',
            'size',
            'owner',
            'group',
            'aTime',
            'mTime',
            'cTime',
            'access',
            'md5_hash',
            'uid',
            'gid'
        ];
    }

    /**
     * @param string $dir
     * @param string $filename
     * @return void
     */
    public function __construct($dir = null, $fileName = null)
    {
        if (!is_null($dir) && !is_null($fileName)) {
            $this->setByDirAndFilename($dir, $fileName);
        }
    }

    /**
     * @return boolean
     */
    public function isNotSet()
    {
        return is_null($this->fileName);
    }

    /**
     * Set attributes by directory and filename
     *
     * @param string $dir
     * @param string $fileName
     * @return void
     */
    public function setByDirAndFilename($dir, $fileName)
    {
        $this->reset();
        $this->directory = $dir;
        $this->fileName = $fileName;
        $this->filePath = $dir . '/' . $fileName;
        if (is_link($this->filePath)) {
            $this->filePath = readlink($this->filePath);
        }
        if (is_file($this->filePath)) {
            $owner = posix_getpwuid(fileowner($this->filePath));
            unset($owner['passwd'], $owner['gid'], $owner['gecos'], $owner['dir'], $owner['shell']);
            $this->owner = $owner;
            $group = posix_getgrgid(filegroup($this->filePath));
            unset($group['passwd'], $group['members']);
            $this->group = $group;
            $this->aTime = fileatime($this->filePath);
            $this->mTime = filemtime($this->filePath);
            $this->cTime = filectime($this->filePath);
            $this->access = fileperms($this->filePath);
            $this->size = filesize($this->filePath);
            $this->md5_hash = md5_file($this->filePath);
            $this->uid = fileowner($this->filePath);
            $this->gid = filegroup($this->filePath);
        }
    }

    /**
     * @return void
     */
    public function reset()
    {
        $this->filePath = null;
        $this->directory = null;
        $this->fileName = null;
        $this->size = null;
        $this->owner = null;
        $this->group = null;
        $this->aTime = null;
        $this->mTime = null;
        $this->cTime = null;
        $this->access = null;
        $this->md5_hash = null;
        $this->uid = null;
        $this->gid = null;
    }
    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = '';
        return $msg;
    }

    /**
     * @return string
     */
    public function getFilePath()
    {
        return $this->filePath;
    }

    /**
     * @return string
     */
    public function getFileName()
    {
        return $this->fileName;
    }

    /**
     * @return string
     */
    public function getOwner()
    {
        return $this->owner;
    }

    /**
     * @return string
     */
    public function getGroup()
    {
        return $this->group;
    }

    /**
     * @return string
     */
    public function getATime()
    {
        return $this->aTime;
    }

    /**
     * @return string
     */
    public function getMTime()
    {
        return $this->mTime;
    }

    /**
     * @return string
     */
    public function getCTime()
    {
        return $this->cTime;
    }

    /**
     * @return string
     */
    public function getAccess()
    {
        return $this->access;
    }

    /**
     * @param string $filePath
     * @return void
     */
    public function setFilePath($filePath)
    {
        $this->filePath = $filePath;
    }

    /**
     * @param string $fileName
     * @return void
     */
    public function setFileName($fileName)
    {
        $this->fileName = $fileName;
    }

    /**
     * @param string $owner
     * @return void
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;
    }

    /**
     * @param string $group
     * @return void
     */
    public function setGroup($group)
    {
        $this->group = $group;
    }

    /**
     * @param string $aTime
     * @return void
     */
    public function setATime($aTime)
    {
        $this->aTime = $aTime;
    }

    /**
     * @param string $mTime
     * @return void
     */
    public function setMTime($mTime)
    {
        $this->mTime = $mTime;
    }

    /**
     * @param string $cTime
     * @return void
     */
    public function setCTime($cTime)
    {
        $this->cTime = $cTime;
    }

    /**
     * @param string $access
     * @return void
     */
    public function setAccess($access)
    {
        $this->access = $access;
    }

    /**
     * @return string
     */
    public function getDirectory()
    {
        return $this->directory;
    }

    /**
     * @param string $directory
     * @return void
     */
    public function setDirectory($directory)
    {
        $this->directory = $directory;
    }

    /**
     * @return int
     */
    public function getSize()
    {
        return $this->size;
    }

    /**
     * @param int $size
     * @return void
     */
    public function setSize($size)
    {
        $this->size = $size;
    }

    /**
     * @return string
     */
    public function getMd5Hash()
    {
        return $this->md5_hash;
    }

    /**
     * @param string $md5_hash
     * @return void
     */
    public function setMd5Hash($md5_hash)
    {
        $this->md5_hash = $md5_hash;
    }

    /**
     * @return string
     */
    public function getUid()
    {
        return $this->uid;
    }

    /**
     * @param string $uid
     * @return void
     */
    public function setUid($uid)
    {
        $this->uid = $uid;
    }

    /**
     * @return string
     */
    public function getGid()
    {
        return $this->gid;
    }

    /**
     * @param string $gid
     * @return void
     */
    public function setGid($gid)
    {
        $this->gid = $gid;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return !is_null($this->fileName) ? $this->getAttributes() : [];
        // return get_object_vars($this);
    }
}
