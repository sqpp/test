<?php

/**
 * CloudProtection packaging class for manual blacklisting.
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 * 
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentPayloadCloudProtection extends IncidentPayload
{
    /**
     * @var string
     */
    protected $remote_addr;
    /**
     * @var string
     */
    protected $type;
    /**
     * @var int
     */
    protected $user_id;
    /**
     * @var string
     */
    protected $comment;

    use TraitAccessors;

    /**
     * @param string $ip
     * @return void
     */
    public function __construct($ip)
    {
        $this->remote_addr = $ip;
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = 'CloudProtection triggered.';
        $msg .= parent::__toString();
        return $msg;
    }
}
