<?php

/**
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentPayloadWaf extends IncidentPayload
{

    use TraitAccessors;

    /**
     * @var string
     */
    private $query;

    /**
     * @var string
     */
    private $host;

    /**
     * @var string
     */
    private $resource;

    /**
     * Disabled for now, as the IPC message queue can't send large messages. We may increase it's size.
     * 
     * @var string
     */
    // private $msgBody;
    
    /**
     * @var array
     */
    private $getParams;

    /**
     * @var array
     */
    private $postParams;

    /**
     * @var string
     */
    private $protocol;

    /**
     * @var array
     */
    private $headers;

    /**
     * @var string
     */
    private $locationPattern;

    /**
     * ModSecurity message
     *
     * @var string
     */
    private $msg;

    /**
     * ModSecurity logdata
     *
     * @var string
     */
    private $logdata;

    /**
     * ModSecurity revision
     *
     * @var int
     */
    private $revision;

    /**
     * ModSecurity severity
     *
     * @var int
     */
    private $severity;

    /**
     * IncidentPayloadWaf constructor.
     *
     * @param \BitNinja\WAF\ProtocolHttpRequest $protocolRequest
     */
    public function __construct($protocolRequest)
    {
        $this->setModuleName('WAF');

        if ($protocolRequest instanceof \BitNinja\WAF\ProtocolHttpRequest) {
            $this->setupHttpIncident($protocolRequest);
        }
    }

    /**
     * @param \BitNinja\WAF\ProtocolHttpRequest $protocolRequest
     */
    public function setupHttpIncident($protocolRequest)
    {
        $this->protocol = 'HTTP';
        $this->remote_addr = $protocolRequest->getRemoteAddress();
        $this->query = $protocolRequest->getMatched();
        $this->host = $protocolRequest->getHeader('host');
        $this->associated_domain_name = $protocolRequest->getHeader('host');
        $this->resource = $protocolRequest->getRequestStringWithoutParams();
        $this->getParams = $protocolRequest->getGetParams();
        $this->postParams = $protocolRequest->getPostParams();
        $this->headers = $protocolRequest->getRequestHeadersArray();

        $this->rule_id = $protocolRequest->getRule('ruleId');
        $this->log_type = 'prod';
        $this->msg = $protocolRequest->getRule('message');
        $this->logdata = $protocolRequest->getRule('match');
        $this->revision = $protocolRequest->getRule('rev');
        $this->severity = $protocolRequest->getRule('severity');
    }

    /**
     * @return string
     */
    public function __toString()
    {
        $res = parent::__toString();
        $res .= "Segment caught by WAF: [" . $this->query . "]\n";
        // $res.="Recieved message body: [".$this->msgBody."]";
        return $res;
    }

    /**
     * @return string
     */
    public function getQuery()
    {
        return $this->query;
    }

    /**
     * @param string $query
     * @return void
     */
    public function setQuery($query)
    {
        $this->query = $query;
    }

    /**
     * @return string
     */
    public function getHost()
    {
        return $this->host;
    }

    /**
     * @param string $host
     * @return void
     */
    public function setHost($host)
    {
        $this->host = $host;
    }

    /**
     * @return string
     */
    public function getResource()
    {
        return $this->resource;
    }

    /**
     * @param string $resource
     * @return void
     */
    public function setResource($resource)
    {
        $this->resource = $resource;
    }

    /**
     * @return array
     */
    public function getGetParams()
    {
        return $this->getParams;
    }

    /**
     * @param array $getParams
     * @return void
     */
    public function setGetParams($getParams)
    {
        $this->getParams = $getParams;
    }

    /**
     * @return array
     */
    public function getPostParams()
    {
        return $this->postParams;
    }

    /**
     * @param array $postParams
     * @return void
     */
    public function setPostParams($postParams)
    {
        $this->postParams = $postParams;
    }

    /**
     * @return string
     */
    public function getProtocol()
    {
        return $this->protocol;
    }

    /**
     * @param string $protocol
     * @return void
     */
    public function setProtocol($protocol)
    {
        $this->protocol = $protocol;
    }

    /**
     * @return array
     */
    public function getHeaders()
    {
        return $this->headers;
    }

    /**
     * @param array $headers
     * @return void
     */
    public function setHeaders($headers)
    {
        $this->headers = $headers;
    }

    /**
     * @return string
     */
    public function getLocationPattern()
    {
        return $this->locationPattern;
    }

    /**
     * @param string $locationPattern
     * @return IncidentPayloadWaf
     */
    public function setLocationPattern($locationPattern)
    {
        $this->locationPattern = $locationPattern;
        return $this;
    }
}
