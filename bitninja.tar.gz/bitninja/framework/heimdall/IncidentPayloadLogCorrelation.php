<?php
/**
 * Simple incident payload for log correlation data.
 * This section is a part of file incident.
 * 
 * @author      Joseph Konnyu <joseph.konnyu@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentPayloadLogCorrelation extends IncidentPayload
{
    use TraitAccessors;

    /**
     * Array of log lines
     * 
     * @var array
     */
    private $raw_http_access_log;
    /**
     * Array of log lines
     * 
     * @var array
     */
    private $raw_ftp_log;
    /**
     * Array of log lines
     * 
     * @var array
     */
    private $raw_controlpanel_log;
    /**
     * Array of log lines
     * 
     * @var array
     */
    private $raw_waf_log;
    /**
     * Array of ips
     * 
     * @var array
     */
    private $extracted_ips_http;
    /**
     * Array of ips
     * 
     * @var array
     */
    private $extracted_ips_ftp;
    /**
     * Array of ips
     * 
     * @var array
     */
    private $extracted_ips_controlpanel;
    /**
     * Array of ips
     * 
     * @var array
     */
    private $extracted_ips_waf;
    /**
     * Array of domains
     * 
     * @var array
     */
    private $domains;
    /**
     * The name of the Control Panel user
     * 
     * @var string
     */
    private $controlpanel_user;
    /**
     * If is true, then the BitNinja create a password reset request about the Control Panel
     * 
     * @var boolean
     */
    private $controlpaner_user_passwordreset;

    /**
     * @return array
     */
    protected function attributes()
    {
        return [
            'raw_http_access_log',
            'raw_ftp_log',
            'raw_controlpanel_log',
            'raw_waf_log',
            'extracted_ips_http',
            'extracted_ips_ftp',
            'extracted_ips_controlpanel',
            'extracted_ips_waf',
            'domains',
            'controlpanel_user',
            'controlpaner_user_passwordreset',
        ];
    }

    /**
     * @param array $fileinfo_data
     * @param array $defense_robot_data
     * @return void
     */
    public function __construct($fileinfo_data = [], $defense_robot_data = [])
    {
        $file_incident = new IncidentFile;
        $file_incident->setAttributes($fileinfo_data);
        $this->addFile($file_incident);

        foreach ($defense_robot_data as $key => $value) {
            if (in_array($key, $this->attributes())) {
                $this->$key = $value;
            }
        }

        $this->remote_addr = 'defense_robot';
    }

    /**
     * @return array
     */
    public function getRawHttpAccessLog()
    {
        return $this->raw_http_access_log;
    }

    /**
     * @param array $raw_http_access_log
     * @return void
     */
    public function setRawHttpAccessLog($raw_http_access_log)
    {
        $this->raw_http_access_log = $raw_http_access_log;
    }

    /**
     * @return array
     */
    public function getRawFtpLog()
    {
        return $this->raw_ftp_log;
    }

    /**
     * @param array $raw_ftp_log
     * @return void
     */
    public function setRawFtpLog($raw_ftp_log)
    {
        $this->raw_ftp_log = $raw_ftp_log;
    }

    /**
     * @return array
     */
    public function getRawControlpanelLog()
    {
        return $this->raw_controlpanel_log;
    }

    /**
     * @param array $raw_controlpanel_log
     * @return void
     */
    public function setRawControlpanelLog($raw_controlpanel_log)
    {
        $this->raw_controlpanel_log = $raw_controlpanel_log;
    }

    /**
     * @return array
     */
    public function getRawWafLog()
    {
        return $this->raw_waf_log;
    }

    /**
     * @param array $raw_waf_log
     * @return void
     */
    public function setRawWafLog($raw_waf_log)
    {
        $this->raw_waf_log = $raw_waf_log;
    }

    /**
     * @return array
     */
    public function getExtractedIpsHttp()
    {
        return $this->extracted_ips_http;
    }

    /**
     * @param array $extracted_ips_http
     * @return void
     */
    public function setExtractedIpsHttp($extracted_ips_http)
    {
        $this->extracted_ips_http = $extracted_ips_http;
    }

    /**
     * @return array
     */
    public function getExtractedIpsFtp()
    {
        return $this->extracted_ips_ftp;
    }

    /**
     * @param array $extracted_ips_ftp
     * @return void
     */
    public function setExtractedIpsFtp($extracted_ips_ftp)
    {
        $this->extracted_ips_ftp = $extracted_ips_ftp;
    }

    /**
     * @return array
     */
    public function getExtractedIpsControlpanel()
    {
        return $this->extracted_ips_controlpanel;
    }

    /**
     * @param array $extracted_ips_controlpanel
     * @return void
     */
    public function setExtractedIpsControlpanel($extracted_ips_controlpanel)
    {
        $this->extracted_ips_controlpanel = $extracted_ips_controlpanel;
    }

    /**
     * @return array
     */
    public function getExtractedIpsWaf()
    {
        return $this->extracted_ips_waf;
    }

    /**
     * @param array $extracted_ips_waf
     * @return void
     */
    public function setExtractedIpsWaf($extracted_ips_waf)
    {
        $this->extracted_ips_waf = $extracted_ips_waf;
    }

    /**
     * @return array
     */
    public function getDomains()
    {
        return $this->domains;
    }

    /**
     * @param array $domains
     * @return void
     */
    public function setDomains($domains)
    {
        $this->domains = $domains;
    }

    /**
     * @return string
     */
    public function getControlpanelUser()
    {
        return $this->controlpanel_user;
    }

    /**
     * @param string $controlpanel_user
     * @return void
     */
    public function setControlpanelUser($controlpanel_user)
    {
        $this->controlpanel_user = $controlpanel_user;
    }

    /**
     * @return string
     */
    public function getControlpanerUserPasswordreset()
    {
        return $this->controlpaner_user_passwordreset;
    }

    /**
     * @param string $controlpaner_user_passwordreset
     * @return void
     */
    public function setControlpanerUserPasswordreset($controlpaner_user_passwordreset)
    {
        $this->controlpaner_user_passwordreset = $controlpaner_user_passwordreset;
    }
}