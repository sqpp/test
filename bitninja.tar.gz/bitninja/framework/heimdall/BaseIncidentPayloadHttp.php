<?php

/**
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class BaseIncidentPayloadHttp extends IncidentPayload
{
    /**
     * @var string
     */
    protected $remote_addr;
    /**
     * @var int
     */
    protected $remote_port;
    /**
     * @var string
     */
    protected $request_uri;
    /**
     * @var string
     */
    protected $http_user_agent;
    /**
     * @var string
     */
    protected $http_referer;
    /**
     * @var array
     */
    protected $headers;
    /**
     * @var string
     */
    protected $http_host;
    /**
     * @var string
     */
    protected $post;
    /**
     * @var string
     */
    protected $get;
    /**
     * @var string
     */
    protected $protocol;
    /**
     * @var array
     */
    protected $localIps;

    use TraitAccessors;
    use TraitNetworkingHelper;

    /**
     * @return array
     */
    public function getLocalIps()
    {
        if (is_null($this->localIps)) {
            $this->localIps = $this->getInetAddrsLogLess();
        }
        return $this->localIps;
    }

    /**
     * @return void
     */
    public function __construct()
    {
        $this->protocol = 'http';
    }

    /**
     * Loads data from the current $_SERVER values.
     *
     * @return void
     */
    public function autoPopulate()
    {
        $this->remote_addr = $_SERVER['REMOTE_ADDR'];
        $this->request_uri = $_SERVER['REQUEST_URI'];
        $this->http_user_agent = $_SERVER['HTTP_USER_AGENT'];
        $this->http_referer = $_SERVER['HTTP_REFERER'];
        $this->http_host = $_SERVER['HTTP_HOST'];
        $this->post = $_POST;
        $this->get = $_GET;
        $this->protocol = 'http';
    }

    /**
     * @param HTTPRequest $req
     * @return void
     */
    public function populateFromRequest($req)
    {
        @$this->setData([
            'remote_addr' => $req->remote_addr,
            'remote_port' => $req->remote_port,
            'request_uri' => $req->request_uri,
            'http_host' => $req->get_header('Host'),
            'post' => $req->getPost(),
            'get' => $req->getGet(),
            'associated_domain_name' => $req->get_header('Host')
        ]);
        if (($referer = $req->get_header('Referer')) != '') {
            $this->setData(['http_referer' => $referer]);
        }
        if (($agent = $req->get_header('User-Agent')) != '') {
            $this->setData(['http_user_agent' => $agent]);
        }
        $this->setData(["remote_addr" => $req->getRemoteAddress()]);
        $this->headers = $req->headers;
    }

    /**
     * Sets the privte values from the $data array.
     *
     * @param array $data
     * @return void
     */
    public function setData($data)
    {
        foreach ($data as $key => $value) {
            $this->$key = $value;
        }
    }

    /**
     * @return string
     */
    public function getRequestUri()
    {
        return $this->request_uri;
    }

    /**
     * @return string
     */
    public function getGetStr()
    {
        return print_r($this->get, true);
    }

    /**
     * @return string
     */
    public function getPostStr()
    {
        return print_r($this->post, true);
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = parent::__toString();
        $msg .= ' uri: [' . $this->request_uri . ']';
        return $msg;
    }

    /**
     * @return array
     */
    public function getHeaders()
    {
        return $this->headers;
    }

    /**
     * @return BaseIncidentPayloadHttp
     */
    public function setHeaders($headers)
    {
        $this->headers = $headers;
        return $this;
    }
}
