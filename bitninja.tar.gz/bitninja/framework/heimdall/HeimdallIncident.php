<?php

/**
 * Framework class to represent a Heimdall Incident.
 * This is the rewrite of the original HeimdallQuery class.
 * The original class is now deprecated. Use this class instead.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class HeimdallIncident  implements \JsonSerializable
{
    /**
     * Auto generated UUID for lifetime tracking.
     *
     * @var string
     */
    protected $id;

    /**
     * @var string
     */
    private $type;

    /**
     * @var int
     */
    private $timestamp;

    /**
     *
     * @var \IncidentPayload
     */
    private $payload;
    /**
     * @var string
     */
    private $server_name;
    /**
     * @var int
     */
    private $server_id;
    /**
     * @var int
     */
    private $user_id;
    /**
     * @var string
     */
    private $server_trust_point;
    /**
     * @var string
     */
    protected $type_name;

    /**
     * @var string
     */
    private $host;

    /**
     * @var string
     */
    private $remote_ip;


    /**
     *
     * @var BlueLog
     */
    private $log;

    /**
     * @return void
     */
    public function __construct()
    {
        $this->log = BlueLog::instance($this);
        $this->timestamp = time();
        $this->server_name = ServerDataProvider::getHostName();
    }

    /**
     * Get the ID in UUIDv3 format, hexa 32 character WITHOUT the hypens.
     *
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Get the ID in UUIDv3 format, hexa 32 character WITH the hypens in 8-4-4-4-12 format.
     * 
     * @return string
     */
    public function getUuid()
    {
        if (is_null($this->id)) {
            $this->id = substr(sha1(microtime() . 'id' .  mt_rand()), 0, 32);
        }
        return preg_replace('%^([\da-f]{8})([\da-f]{4})([\da-f]{4})([\da-f]{4})([\da-f]{12})$%', '$0-$1-$2-$3-$4', $this->id);
    }

    /**
     * Get the ID in GUID format 22 char URL safe base64 encoded format.
     *
     * @return string
     */
    public function getGuid()
    {
        return strtr(rtrim(base64_encode(pack('H*', $this->id)), '='), ['+' => '-', '/' => '_']);
    }

    /**
     * @return mixed
     */
    public function getRemoteAddr()
    {
        if (isset($this->payload)) {
            return $this->payload->getRemoteAddr();
        }
        return false;
    }

    /**
     * @return string
     */
    public function getServerName()
    {
        return $this->server_name;
    }

    /**
     * Set the server id. The server id is set by the api processor.
     *
     * @param int $server_id
     * @return void
     */
    public function setServerId($server_id)
    {
        $this->server_id = $server_id;
    }

    /**
     * Return the server id.
     * 
     * @return int
     */
    public function getServerId()
    {
        return $this->server_id;
    }

    /**
     * Set the user id. The user id is set by the api processor.
     *
     * @param int $user_id
     * @return void
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }

    /**
     * Return the user id.
     *
     * @return int
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * Set the incident sender server's trust point.
     * The server's trust point is set by the api processor.
     *
     * @param int $server_trust_point
     * @return void
     */
    public function setServerTrustPoint($server_trust_point)
    {
        $this->server_trust_point = $server_trust_point;
    }

    /**
     * Return the incident sender server's trust point.
     *
     * @return int
     */
    public function getServerTrustPoint()
    {
        return $this->server_trust_point;
    }

    /**
     * @param IncidentBase $payload The payload
     * @return void
     */
    public function setPayload($payload)
    {
        $this->payload = $payload;
    }

    /**
     * @return IncidentPayload
     */
    public function getPayload()
    {
        return $this->payload;
    }

    /**
     * Returns the new payload field values (module name, rule id, log type) in an array
     *
     * @return array
     */
    public function getAdditionalFieldsFromPayload()
    {
        return [
            'module_name' => $this->payload->getModuleName(),
            'rule_id' => $this->payload->getRuleid(),
            'log_type' => $this->payload->getLogType()
        ];
    }

    /**
     * Send the incident to the hemdall central server for further
     * analysis.
     *
     * @param boolean $lazy If the sendig can happen in a lazy fashion.
     * @return void
     */
    public function sendToHeimdallCentral($lazy = false)
    {
        $this->getUuid();
        if ($lazy == true) {
            IncidentTransporter::instance()->sendLazy($this);
            return;
        }
        IncidentTransporter::instance()->sendNow($this);
    }

    /**
     * Set the type of the incident. You can only set types
     * from the consts of the IncidentType class.
     *
     * @param int $type The type constant.
     * @return void
     */
    public function setType($type)
    {
        $this->type = $type;
        $this->setTypeNameByType($type);
    }

    /**
     * @param string $type
     * @return string
     */
    public function setTypeNameByType($type)
    {
        $class = new ReflectionClass('IncidentType');
        $constants = $class->getConstants();
        $constants = array_flip($constants);
        $this->type_name = $constants[$type];
    }

    /**
     * @param string $typeName
     * @return void
     */
    public function setTypeName($typeName)
    {
        $this->type_name = $typeName;
    }

    /**
     * @return string
     */
    public function getTypeName()
    {
        if (is_null($this->type_name)) {
            $this->setTypeNameByType($this->type);
        }
        return $this->type_name;
    }

    /**
     * Returns the integer value of the reason.
     *
     * @return int
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Return the hostname of the remote IP.
     * Use this, because it only queries once, and caches the result.
     *
     * @return string
     */
    public function getRemoteHostName()
    {
        if (!isset($this->host)) {
            $this->host = gethostbyaddr($this->remote_ip);
        }
        return $this->host;
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = 'ip: [' . $this->getRemoteAddr() . '] id: [' . $this->getUuid() . '] ' . $this->payload;
        return $msg;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
