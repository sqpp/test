<?php
/**
 * ExternalBL Incident packaging class.
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentPayloadExternalBL extends IncidentPayload
{
    /**
     * @var string
     */
    protected $ip;
    /**
     * @var string
     */
    protected $listname;
    /**
     * @var string
     */
    protected $listlink;

    use TraitAccessors;

    /**
     * @param string $data
     * @return void
     */
    public function __construct($data)
    {
        $this->ip = $data['ip'];
        $this->listname = $data['listname'];
        $this->listlink = $data['listlink'];
    }
}
