<?php

/**
 * Cnc server incident packaging class. 
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Jozsef Konnyu <jozsi@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentPayloadCnc extends IncidentPayload
{
    /**
     * @var string
     */
    protected $ip;
    /**
     * @var string
     */
    protected $domain;
    /**
     * @var string
     */
    protected $reason;

    use TraitAccessors;

    /**
     * @param string $data
     * @return void
     */
    public function __construct($data)
    {
        $this->ip = $data['ip'];
        $this->domain = $data['domain'];
        $this->reason = $data['reason'];
    }
}
