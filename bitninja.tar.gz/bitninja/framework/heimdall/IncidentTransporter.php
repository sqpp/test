<?php

/**
 * This class manages the sneding process of HeimdallIncident objects to
 * Bitninja Central.
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentTransporter
{
    use TraitSingleton;

    /**
     * The timestamp of last send
     * 
     * @var integer
     */
    protected $lastSendTimestamp = 0;

    /**
     * @var array
     */
    protected $incidentQueue = [];

    /**
     * Array to store delistable IPs
     *
     * @var array
     */
    protected $delistableIps = [];

    /** @var int */
    protected $sendLimit = 30;

    /**
     * Max size of serialized incidents should not except 1Mb (1024*1024)
     *
     * @var integer
     */
    protected $maxMessageSize = 1048576;

    /** @var HeimdallHttpApi */
    protected $api;

    public function onInit()
    {
        $this->api = HeimdallHttpApi::instance();
    }

    /**
     * @param HeimdallIncident $incident
     * @return boolean
     */
    public function sendLazy(HeimdallIncident $incident)
    {
        if (!$this->validate($incident)) {
            return false;
        }

        $this->queueIncident($incident);
        $this->processQueue(count($this->incidentQueue) >= $this->sendLimit);
    }

    /**
     * @param boolean $force
     * @return PromiseInterface
     */
    public function processQueue($force = false)
    {
        if (!($force || (time() - $this->lastSendTimestamp) > 10)) {
            return 0;
        }
        return $this->sendQueue();
    }

    /**
     * @return int
     */
    protected function sendQueue()
    {
        $this->lastSendTimestamp = time();
        if (count($this->incidentQueue) == 0) {
            $this->log->debug('Incident queue is empty.');
            return 0;
        }

        // if the IP is in the delistable array and the incident is of type BL_, it won't be sent to the queue
        $queue = array_splice($this->incidentQueue, 0, $this->sendLimit);
        foreach ($queue as $incident) {
            if (in_array($incident->getRemoteAddr(), $this->delistableIps, false) && strpos($incident->getTypeName(), 'BL_') === 0) {
                $incident->getPayload()->setLogType(IncidentPayload::LOGTYPE_LOG);
            }
        }

        $serializedIncidents = serialize($queue);
        if (strlen($serializedIncidents) > $this->maxMessageSize) {
            $serializedIncidents = $this->adjustIncidentMessagesToSizeLimit($queue, $this->maxMessageSize);
        }
        if ($this->api->request('newIncidentBulk', ['incidents' => $serializedIncidents], 'post') === false) {
            $this->log->info('Api is unreachable. Requeuing incidents...');
            $this->incidentQueue = array_merge($this->incidentQueue, $queue);
            return 0;
        }
        $this->log->info('Incident queue sent to BitNinja Central with [' .
            count($queue) . '] incidents.');
        $queueSize = count($this->incidentQueue);
        if ($queueSize === 0) {
            $this->delistableIps = [];
        }
        return $queueSize;
    }

    /**
     * @param array $queue
     * @param int $maxSize
     * @return array
     */
    protected function adjustIncidentMessagesToSizeLimit($queue, $maxSize)
    {
        $messages = [];
        $overallSize = 0;
        foreach ($queue as $message) {
            /** @var HeimdallIncident $message */
            $messageLen = strlen(serialize($message));
            if ($messageLen > $maxSize) {
                $this->log->warn("Oversized incident about [{$message->getRemoteAddr()}] type [{$message->getTypeName()}] size [$messageLen]");
                continue;
            }
            if (($overallSize + $messageLen) > $maxSize) {
                $this->incidentQueue[] = $message;
                continue;
            }
            $messages[] = $message;
            $overallSize += $messageLen;
        }
        return serialize($messages);
    }

    /**
     * @param HeimdallIncident $incident
     * @return void
     */
    protected function queueIncident(HeimdallIncident $incidnet)
    {
        // if the incident type is WL_ => delist, it goes to the array
        if (strpos($incidnet->getTypeName(), 'WL_') === 0) {
            $this->delistableIps[] = $incidnet->getRemoteAddr();
        }
        $this->incidentQueue[] = $incidnet;
        $this->log->info('Incident about [' . $incidnet->getRemoteAddr() . '] added to incident queue.');
    }

    /**
     * Admin-side incident sender
     *
     * @param HeimdallIncident $incident
     * @return void
     */
    public function sendNow(HeimdallIncident $incident)
    {
        $this->api->request('newIncident', ['incident' => serialize($incident)], 'post');
        $this->lastSendTimestamp = time();
        $this->log->info('Incident about [' . $incident->getRemoteAddr() . '] sent to BitNinja Central.');
    }

    /**
     * Check if the incident is ready for sending.
     *
     * @param HeimdallIncident $incident
     * @return boolean
     */
    protected function validate(HeimdallIncident $incident)
    {
        if ($incident->getPayload() == null) {
            $this->log->error('Payload cannot be null!');
            $this->log->backtrace();
            return false;
        }

        if ($incident->getRemoteAddr() == null) {
            $this->log->error('Payload remote_addr cannot be null!');
            $this->log->backtrace();
            return false;
        }
        return true;
    }
}
