<?php

/**
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentPayloadOutboundWaf extends IncidentPayload
{
    use TraitAccessors;

    /**
     * @var string
     */
    private $query;

    /**
     * @var string
     */
    private $host;

    /**
     * @var string
     */
    private $resource;

    /**
     * @var array
     */
    private $getParams;

    /**
     * @var array
     */
    private $postParams;

    /**
     * @var string
     */
    private $protocol;

    /**
     * @var array
     */
    private $headers;

    /**
     * @param \BitNinja\OutboundWAF\OProtocolHttpRequest $prtocolRequest
     * @return void
     */
    public function __construct($protocolRequest)
    {
        if ($protocolRequest instanceof \BitNinja\OutboundWAF\OProtocolHttpRequest) {
            $this->setupHttpIncident($protocolRequest);
        }
    }

    /**
     * @param \BitNinja\OutboundWAF\OProtocolHttpRequest $protocolRequest
     * @return void
     */
    protected function setupHttpIncident($protocolRequest)
    {
        $pid = $protocolRequest->getScriptPID();
        $this->protocol = 'HTTP';
        $process = $protocolRequest->getProcess();
        $process->removeUnUsedFileObjects();
        $process->converFilesInCwdIncidentFileObjectsToArray();
        if (!is_null($process->getPid())) {
            $this->setProcess($process);
        }
        $this->remote_addr = $protocolRequest->getRemoteAddress();
        $this->query = $protocolRequest->getMatched();
        $this->host = $protocolRequest->getHeader('host');
        $this->resource = $protocolRequest->getRequestStringWithoutParams();
        $this->getParams = $protocolRequest->getGetParams();
        $this->postParams = $protocolRequest->getPostParams();
        $this->headers = $protocolRequest->getRequestHeadersArray();
    }

    /**
     * @return string
     */
    public function __toString()
    {
        $res = parent::__toString();
        $res .= "Segment caught by OutboundWAF: [" . $this->query . "]\n";
        return $res;
    }

    /**
     * @return array
     */
    public function getGetParams()
    {
        return $this->getParams;
    }

    /**
     * @return array
     */
    public function getPostParams()
    {
        return $this->postParams;
    }

    /**
     * @return string
     */
    public function getQuery()
    {
        return $this->query;
    }

    /**
     * @param string $query
     * @return void
     */
    public function setQuery($query)
    {
        $this->query = $query;
    }

    /**
     * @return string
     */
    public function getHost()
    {
        return $this->host;
    }

    /**
     * @param string $host
     * @return void
     */
    public function setHost($host)
    {
        $this->host = $host;
    }

    /**
     * @return string
     */
    public function getResource()
    {
        return $this->resource;
    }

    /**
     * @param string $resource
     * @return void
     */
    public function setResource($resource)
    {
        $this->resource = $resource;
    }

    /**
     * @param array $getParams
     * @return void
     */
    public function setGetParams($getParams)
    {
        $this->getParams = $getParams;
    }

    /**
     * @param array $postParams
     * @return void
     */
    public function setPostParams($postParams)
    {
        $this->postParams = $postParams;
    }

    /**
     * @return string
     */
    public function getProtocol()
    {
        return $this->protocol;
    }

    /**
     * @param string $protocol
     * @return void
     */
    public function setProtocol($protocol)
    {
        $this->protocol = $protocol;
    }

    /**
     * @return array
     */
    public function getHeaders()
    {
        return $this->headers;
    }

    /**
     * @param array $headers
     * @return void
     */
    public function setHeaders($headers)
    {
        $this->headers = $headers;
    }
}
