<?php

use BitNinja\Framework\Api\V2\JWT\Jwt;
use BitNinja\Framework\ContainerInstance;
use Evenement\EventEmitterTrait;
use GuzzleHttp\Exception\ClientException;
use Monolog\Logger;

use GuzzleHttp\HandlerStack;
use Namshi\Cuzzle\Middleware\CurlFormatterMiddleware;
use Monolog\Handler\TestHandler;
use React\EventLoop\LoopInterface;
use React\Promise\Deferred;
use React\Promise\PromiseInterface;

/**
 * Wrapper class for accessing the Heimdall HTTP API
 * usage:
 *
 * $api = HeimdallHttpApi::instance();
 * $api->request('register', ['user' => 'someuser']);
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class HeimdallHttpApi
{
    const TOKEN_CHANGED = 'tokenUpdate';
    const NEW_TOKEN = 'newToken';
    /**
     * @var GuzzleHttp\Client
     */
    private $client;
    /**
     * @var GuzzleHttp\Client
     */
    protected $asyncClient;
    /**
     * @var boolean
     */
    private $hadErrorOnSend = false;
    /**
     * @var string
     */
    private $apiKey;
    /**
     * @var string
     */
    private $appId;
    /**
     * @var int
     */
    private $timeout = 50;
    /**
     * @var integer
     */
    private $connectionTimeOut = 10;
    /**
     *
     * @var Jwt
     */
    protected $jwtService;
    /**
     * @var string
     */
    protected $token;
    /**
     * @var array
     */
    protected $headers = [];

    /** @var array */
    private $params = [];
    // private $cookiejar;
    // Singleton
    use TraitSingleton;
    use EventEmitterTrait;

    /**
     * @var object
     */
    protected $testHandler;
    /**
     * @var ReactHandlerStack
     */
    protected $handler;
    /**
     * @var object
     */
    protected $asyncHandler;
    /**
     *
     * @var LoopInterface
     */
    protected $loop;

    /**
     * @param LoopInterface $loop
     * @return void
     */
    public function setLoop(LoopInterface $loop)
    {
        $this->loop = $loop;
    }
    /**
     *
     * @return GuzzleHttp\Client
     */
    public function getClient()
    {
        return $this->client;
    }
    /**
     *
     * @return ReactHandlerStack
     */
    public function getHandler()
    {
        return $this->handler;
    }

    /**
     * @param ReactHandlerStack $handler
     * @return void
     */
    public function setHandler($handler)
    {
        $this->handler = $handler;
        $this->createClient();
    }

    /**
     * @param LoopInterface $loop
     * @return void
     */
    public function bindReactLoop(LoopInterface $loop)
    {
        $this->setLoop($loop);
        $this->asyncHandler = ReactHandlerStack::bindReactPhpPromiseTicker($loop);
        $that = $this;
        $this->on(self::TOKEN_CHANGED, function () use ($that) {
            $that->createAsyncClient();
        });
        $this->on(self::NEW_TOKEN, function () use ($that) {
            $that->createAsyncClient();
        });
        $this->updateToken();
        $that->createAsyncClient();
    }
    /**
     * Initialize the Http client.
     *
     * @return void
     */
    public function onInit()
    {
        $container = ContainerInstance::getInstance()->getContainer();
        $this->appId = $container['app_uuid'];
        $this->jwtService = $container['jwt_service'];
        $this->headers['X-BitNinja-Agent-Version'] = $container['agent_version'];
        $this->timeout = $container['http_timeout'];
        $this->connectionTimeOut = $container['http_connection_timeout'];
        // $this->createDumpHandler();
        $that = $this;
        $this->on(self::TOKEN_CHANGED, function () use ($that) {
            $that->createClient();
        });
        $this->on(self::NEW_TOKEN, function () use ($that) {
            $that->createClient();
        });
        $this->updateToken();
        $this->createClient();
    }

    /**
     * @return void
     */
    protected function createDumpHandler()
    {
        $logger = new Logger('guzzle.to.curl'); // initialize the logger
        $testHandler = new TestHandler(); // test logger handler
        $logger->pushHandler($testHandler);
        $handler = HandlerStack::create();
        $handler->after('cookies', new CurlFormatterMiddleware($logger));
        $this->handler = $handler;
        $this->testHandler = $testHandler;
    }

    /**
     * @return void
     */
    public function createClient()
    {
        $this->client = new GuzzleHttp\Client(['cookies' => true, 'headers' => $this->headers, 'handler' => $this->handler]);
    }

    /**
     * @return void
     */
    public function createAsyncClient()
    {
        $this->asyncClient = new GuzzleHttp\Client(['cookies' => true, 'headers' => $this->headers, 'handler' => $this->asyncHandler]);
    }

    /**
     * @return boolean
     */
    protected function updateToken()
    {

        $token = $this->jwtService->getToken();
        if ($this->token === $token) {
            return false;
        }
        $this->token = $token;
        $this->headers['Authorization'] = "bearer $token";
        $this->emit(self::TOKEN_CHANGED, []);
        return true;
    }

    /**
     * @return void
     */
    protected function getNewToken()
    {
        if ($this->updateToken()) {
            return;
        }
        $token = $this->jwtService->getNewToken();
        $this->token = $token;
        $this->headers['Authorization'] = "bearer $token";
        $this->log->info($this->headers['Authorization']);
        $this->emit(self::NEW_TOKEN, []);
    }

    /**
     * Used by unit tests.
     *
     * @param SubscriberInterface $subscriber
     * @return void
     */
    public function attachToEmitter($subscriber)
    {
        $this->client->getEmitter()->attach($subscriber);
    }

    /**
     * @return string
     */
    public function hadErrorOnPreviousSend()
    {
        return $this->hadErrorOnSend;
    }

    /**
     * @param string $postFix
     * @return void
     */
    protected function dumpRequest($postFix = 'normal')
    {
        if (is_null($this->testHandler)) {
            return;
        }
        $dumpFile = "/vagrant/api-dump/$postFix.http";
        $trace = $this->log->backtrace('debug');
        foreach ($this->testHandler->getRecords() as $log) {
            $message = "\n\n";
            $message .= "\n# TimeStamp: [" . time() . "]";
            $message .= "\n# Time: [" . date('Y-m-d H:i:s', time()) . "]";
            $message .= "\n# Trace:";
            foreach ($trace as $line) {
                $message .= "\n# $line";
            }
            $message .= "\n\n###\n{$log['message']}";
            file_put_contents($dumpFile, $message, FILE_APPEND);
        }
        $this->testHandler->clear();
    }

    /**
     * Send a request to the heimdall HTTP api using the server name
     * and api_key automatically. Returns with an array, the json decoded
     * result.$api can be in the format of Controller.apiFunction
     *
     * @param string $method The name of the method to cal
     * @param array  $params The parameters
     * @return mixed return value in text format.
     */
    public function request($api, $params = array(), $method = 'get')
    {
        $this->hadErrorOnSend = false;
        if (!is_array($params)) {
            $this->log->error('The $params argument must be an array!');
            $this->log->backtrace('debug');
        }

        $this->params = $params;

        $fromUrl = $this->createUrlFromRequestedApi($api);
        $query = $this->_auth_query($params, $method);
        try {
            $this->updateToken();
            $res = '';
            if (!in_array($method, ['get', 'post'])) {
                $this->log->error('HeimdallHttpApi $method should be GET or POST. [' . $method . '] is given.');
                $this->log->backtrace('debug');
                return false;
            }
            $res = $this->client->post($fromUrl, [
                ($method === 'get' ? 'query' : 'form_params') => $query,
                'timeout' => $this->timeout,
                'connect_timeout' => $this->connectionTimeOut,
                //'cookies' => true, //$this->cookiejar,
                'verify' => __DIR__ . '/../contrib/certs/ca-bundle.crt'
            ]);
            if (!is_object($res)) {
                $this->log->error('Response received from API should be a GuzzleHttp object. [' . var_export($res, true) . '] received.');
                $this->log->backtrace('debug');
                return false;
            }
            $res_str = $res->getBody();
        } catch (ClientException $e) {
            $this->dumpRequest('ClientException');
            if ($e->getResponse()->getStatusCode() == 401) {
                $this->getNewToken();
                return $this->request($api, $params, $method);
            }
            $res = $e->getResponse();
            $res_str = $res->getBody();
        } catch (GuzzleHttp\Exception\RequestException $e) {
            $this->dumpRequest('RequestException');
            $this->hadErrorOnSend = true;
            $this->log->backtrace('debug');
            $this->log->error('RequestException!');
            $this->log->info('URL: [' . $fromUrl . ']');
            $this->log->debug('Query:' . var_Export($query, true));
            return false;
        } catch (GuzzleHttp\Exception\BadResponseException $e) {
            $this->dumpRequest('BadResponseException');
            $this->hadErrorOnSend = true;
            $this->log->backtrace('debug');
            $this->log->info('URL: [' . $fromUrl . ']');
            $this->log->debug('Query:' . var_Export($query, true));
            $response = $e->getResponse()->getBody()->getContents();
            if (strpos($response, '<h2>Error') !== false) {
                $response = substr($response, strpos($response, '<h2>Error'));
                $response = substr($response, 0, strpos($response, '</div>'));
            }
            $this->log->info('BadResponseException');
            $this->log->debug($response);
            return false;
        } catch (Exception $e) {
            $this->dumpRequest('Exception');
            $this->hadErrorOnSend = true;
            $this->log->backtrace('debug');
            $this->log->info('URL: [' . $fromUrl . ']');
            $this->log->debug('Query:' . var_export($query, true));
            $this->log->info('Exception message:' . $e->getMessage());
            return false;
        }
        if (strpos($res_str, 'Invalid API key') !== false) {
            $this->dumpRequest('Invalid-API-key');
            return false;
        }
        // If there are other text like debug messages than cut it form the result string.
        $res_str = substr($res_str, strpos($res_str, '<!--DATA START-->') + 18);
        // And cut everything after DATA_END
        $res_str = substr($res_str, 0, strpos($res_str, '<!--DATA END-->'));
        $res_objs = unserialize($res_str);
        if ($res_objs === false) {
            $this->dumpRequest('unserialization-error');
            $this->log->warn("Error while unserialization");
            $this->log->info('URL: [' . $fromUrl . ']');
            $this->log->debug('Query:' . var_export($query, true));
            $this->log->debug('Result: ' . var_export($res, true));
            $this->hadErrorOnSend = true;
            return false;
        }
        $this->dumpRequest($api);
        return $res_objs;
    }

    /**
     * @param string $api
     * @return string
     */
    protected function createUrlFromRequestedApi(string $api)
    {
        $controller = 'api';
        $requestedApi = $api;
        if (strpos($requestedApi, '.') !== false) {
            list($controller, $api_new) = explode('.', $requestedApi);
            $controller = 'api' . $controller;
            $requestedApi = $api_new;
        }

        $config = ConfigManager::instance()->getConfig('general');
        $apiUrl = 'https://api.bitninja.io';
        if (isset($config['api_url'])) {
            $apiUrl = $config['api_url'];
        }

        return $apiUrl . '/' . $controller . '/' . $requestedApi;
    }

    /**
     * @param string $api
     * @param array $params
     * @param string $method
     * @return PromiseInterface
     */
    public function asyncRequest(string $api, array $params = [], string $method = 'get'): PromiseInterface
    {
        if (!in_array($method, ['get', 'post', 'put', 'patch', 'delete'])) {
            $deferred = new Deferred();
            $deferred->reject(new \InvalidArgumentException('Request method must be get, post, put, patch, or delete'));
            return $deferred->promise();
        }
        if (is_null($this->asyncClient)) {
            $deferred = new Deferred();
            $deferred->reject(new RuntimeException('Reach loop must bind before sending async requests', 222));
            return $deferred->promise();
        }
        $asyncMethod = 'postAsync';
        $fromUrl = $this->createUrlFromRequestedApi($api);
        $query = $this->_auth_query($params, $method);
        $this->updateToken();
        return ReactHandlerStack::guzzleToReactPromise($this->asyncClient->$asyncMethod($fromUrl, [
            ($method === 'get' ? 'query' : 'form_params') => $query,
            'timeout' => $this->timeout,
            'connect_timeout' => $this->connectionTimeOut,
            //'cookies' => true, //$this->cookiejar,
            'verify' => __DIR__ . '/../contrib/certs/ca-bundle.crt'
        ]));
    }
    /**
     * @return boolean
     */
    protected function autoApiWhitelist()
    {
        $this->log->info('Running auto API whitelist process..');
        $query = $this->_auth_query([], 'post');
        /** @var string */
        $res = $this->client->post('http://apt.bitninja.io/autowl/fgGRE234.php', [
            'form_params' => $query,
            'timeout' => $this->timeout,
            'connect_timeout' => $this->connectionTimeOut,
        ]);

        if (strpos($res, 'Successful whitelisting') !== false) {
            return true;
        }
        return false;
    }

    /**
     * Check if the actually used IP is greylisted.
     *
     * @return boolean
     */
    protected function amIGreylisted()
    {
        $query = $this->_auth_query([], 'post');
        try {
            /** @var string */
            $res = $this->client->post('https://api.bitninja.io', [
                'form_params' => $query,
                'timeout' => $this->timeout,
                'connect_timeout' => $this->connectionTimeOut,
            ]);
        } catch (Exception $ex) {
            $this->log->info('Cannot connect to API server.');
            return false;
        }

        if (strpos($res, 'anti-robot')) {
            // IP is greylisted
            $this->log->info('Outgoing IP address greylisted.');
            return true;
        }

        $this->log->info('Outgoing IP address not greylisted.');
        return false;
    }

    /**
     * @return void
     */
    public function dump_logs()
    {
        $query = $this->_auth_query($this->params, 'post');
        $this->log->info('Query:' . var_Export($query, true));
    }

    /**
     * Invokes the given api call and downloads the result streaming it to disk
     *
     * @param string $api
     * @param array $params
     * @param string $to_file
     * @return boolean
     */
    public function stream_download($api, $params = array(), $to_file)
    {
        $config = ConfigManager::instance()->getConfig('general');
        $apiUrl = 'https://api.bitninja.io';
        if (isset($config['api_url'])) {
            $apiUrl = $config['api_url'];
        }

        $fromUrl = $apiUrl . '/api/' . $api;
        $query = $this->_auth_query($params, 'get');
        try {
            $this->log->debug('Downloading to [' . $to_file . '] file');
            $request = $this->client->post($fromUrl, [
                'query' => $query,
                'save_to' => $to_file,
                'verify' => __DIR__ . '/../contrib/certs/ca-bundle.crt'
            ]);
            //$request->setResponseBody($to_file);
            //$response = $request->send();
            $this->dumpRequest('download');
            return true;
        } catch (Exception $e) {
            // Log the error or something
            $this->dumpRequest('download-error');
            $this->log->error($e);
            return false;
        }
    }

    /**
     * Invokes the given config service call and downloads the result streaming it to disk
     *
     * @param string $downloadUrl
     * @param string $to_file
     * @return boolean
     */
    public function stream_download_config($downloadUrl, $to_file)
    {
        try {
            $this->log->debug('Downloading to [' . $to_file . '] file');
            $request = $this->client->get($downloadUrl, [
                'save_to' => $to_file,
                'verify' => __DIR__ . '/../contrib/certs/ca-bundle.crt'
            ]);
            $this->dumpRequest('config');
            return true;
        } catch (Exception $e) {
            // Log the error or something
            $this->log->error($e);
            $this->dumpRequest('config-error');
            return false;
        }
    }

    /**
     * Construct the authentication query for the api calls.
     *
     * @param array  $params The request params
     * @param string $method The request method
     * @return array
     */
    private function _auth_query($params, $method)
    {
        $params['server_name'] = ServerDataProvider::getHostName();
        $params['app_uuid'] = $this->appId;
        return $params;
    }
}
