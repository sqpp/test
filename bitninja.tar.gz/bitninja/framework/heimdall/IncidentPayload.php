<?php

/**
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentPayload implements \JsonSerializable
{
    const LOGTYPE_PROD = 'prod';
    const LOGTYPE_LOG = 'log';
    const LOGTYPE_TEST = 'test';

    /**
     * The remote IP address.
     *
     * @var string
     */
    protected $remote_addr;
    /**
     * @var array
     */
    protected $files = [];
    /**
     * @var string
     */
    protected $process;
    /**
     * @var string
     */
    protected $associated_domain_name;

    /**
     * Array of SA-MD5 malware signatures. Related to this incident.
     * @var array
     */
    protected $malware_signature_hash = [];

    /**
     * @var string
     *
     * Name of the module that generated the incident.
     *
     * @var string
     */
    protected $module_name;

    /**
     * Identifier of the specific rule that triggered the incident.
     *
     * @var string
     */
    protected $rule_id;

    /**
     * Type of the incident: prod | log | test
     *
     * @var string
     */
    protected $log_type;

    /**
     * @param string
     */
    public function setModuleName($module_name)
    {
        $this->module_name = $module_name;
        return $this;
    }

    /**
     * Getter for module name
     *
     * @return string
     */
    public function getModuleName()
    {
        return $this->module_name;
    }

    /**
     * Setter for rule id
     *
     * @param string $rule_id
     * @return void
     */
    public function setRuleId($rule_id)
    {
        $this->rule_id = $rule_id;
    }

    /**
     * Getter for rule id
     *
     * @return string
     */
    public function getRuleid()
    {
        return $this->rule_id;
    }

    /**
     * Setter for log type
     *
     * @param string $log_type
     * @return void
     */
    public function setLogType($log_type)
    {
        $this->log_type = $log_type;
    }

    /**
     * Getter for log type
     *
     * @return string
     */
    public function getLogType()
    {
        return $this->log_type;
    }

    /**
     * @return string
     */
    public function getRemoteAddr()
    {
        return $this->remote_addr;
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = '';
        return $msg;
    }
    /**
     * Getter for incidentFile-s
     *
     * @return IncidentFile[]
     */
    public function getFiles()
    {
        return $this->files;
    }

    /**
     * @return IncidentProcess
     */
    public function getProcess()
    {
        return $this->process;
    }

    /**
     * @param string $file
     * @return void
     */
    public function addFile($file)
    {
        if ($file instanceof IncidentFile) {
            $this->files[] = $file->getAttributes();
        }
    }

    /**
     * @param string $process
     * @return void
     */
    public function setProcess($process)
    {
        if ($process instanceof IncidentProcess) {
            $this->process = $process->getAttributes();
        }
    }

    /**
     * getter process related incidentFile-s
     *
     * @return IncidentFile[]
     */
    public function getFilesOfIncidentProcess()
    {
        if (is_null($this->process)) {
            return [];
        }
        if ($this->process instanceof IncidentProcess) {
            return $this->process->getFilesInCwd();
        }
        if (is_array($this->process) && array_key_exists('filesInCwd', $this->process)) {
            return $this->process['filesInCwd'];
        }
        return [];
    }

    /**
     * Return associated domain name
     *
     * @return string
     */
    public function getAssociatedDomainName()
    {
        return $this->associated_domain_name;
    }

    /**
     * Set domain association if possible.
     *
     * @param string $domainName
     * @return IncidentPayload
     */
    public function setAssociatedDomainName($domainName)
    {
        $this->associated_domain_name = $domainName;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    /**
     * Get the value of malware_signature_hash
     *
     * @return  string
     */
    public function getMalwareSignatureHash()
    {
        return $this->malware_signature_hash;
    }

    /**
     * Set the value of malware_signature_hash
     *
     * @param  string  $malwareSignatureHash
     *
     * @return  self
     */
    public function setMalwareSignatureHashes(array $malwareSignatureHash)
    {
        $this->malware_signature_hash = $malwareSignatureHash;
        return $this;
    }

    /**
     * Add a new malware signature hash to malware_signature_hash
     *
     * @param  string  $malwareSignatureHash
     *
     * @return  self
     */
    public function addMalwareSignatureHash(string $malwareSignatureHash)
    {
        if (!in_array($malwareSignatureHash, $this->malware_signature_hash)) {
            $this->malware_signature_hash[] = $malwareSignatureHash;
        }
        return $this;
    }
}
