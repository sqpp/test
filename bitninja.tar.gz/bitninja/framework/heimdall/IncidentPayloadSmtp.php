<?php

/**
 * Smtp Incident packaging class.
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 *
 */
class IncidentPayloadSmtp extends IncidentPayload
{
    /**
     * @var string
     */
    protected $protocol;
    /**
     * @var string
     */
    protected $from;
    /**
     * @var array
     */
    protected $recipients = array();
    /**
     * @var string
     */
    protected $headers = "";
    /**
     * @var string
     */
    protected $message_body = "";
    /**
     * @var string
     */
    protected $data;
    /**
     * @var string
     */
    protected $helo;
    /**
     * @var object
     */
    protected $command_error;
    /**
     * @var string
     */
    protected $server_addr;

    use TraitAccessors;

    /**
     * @return void
     */
    public function __construct()
    {
        $this->protocol = 'smtp';
    }

    /**
     * @param object $request
     * @return void
     */
    public function populateFromRequest($request)
    {
        $this->from = $request->from;
        $this->recipients = $request->rcpt;
        // $this->data = substr($request->data,0,2056);
        $this->setData($request->data);
        $this->helo = $request->helo;
        $this->command_error = $request->commandError;
        $this->remote_addr = $request->remote_addr;
        $this->server_addr = $request->server_addr;
    }

    /**
     * @param string $data
     * @return void
     */
    public function setData($data)
    {
        $this->headers = substr($data, 0, strpos($data, "\r\n\r\n"));
        $mess = substr($data, strpos($data, "\r\n\r\n") + 4, 128);
        if (strpos($mess, 'multi-part message') !== false) {
            $this->headers .= "\r\n" . substr($data, strlen($this->headers) + 4, (strpos($data, "\r\n\r\n", strlen($this->headers) + 4) - strlen($this->headers)));
            $mess = substr($data, strlen($this->headers) + 2, 128);
        }
        $this->message_body = $mess;
    }

    /**
     * @return string
     */
    public function getRCPT()
    {
        $rcpt = "";
        foreach ($this->recipients as $recipiant) {
            $rcpt .= "RCPT TO:" . $recipiant . "\n";
        }
        return $rcpt;
    }

    /**
     * @return string
     */
    public function getCommandErrorStr()
    {
        $rcmd = "";
        foreach ($this->command_error as $cmd) {
            $rcmd .= $cmd . "\n";
        }
        return $rcmd;
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = parent::__toString();
        $msg .= ' from: [' . $this->from . ']';
        return $msg;
    }
}
