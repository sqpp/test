<?php

/**
 * Http Incident packaging class.
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 *
 */
class IncidentPayloadDistributedLog extends IncidentPayload
{
    /**
     * @var string
     */
    protected $remote_addr;
    /**
     * @var string
     */
    protected $protocol;

    /**
     * Logs about the incident.
     * 
     * @var string
     */
    protected $logs;

    use TraitAccessors;

    /**
     * @param string $ip
     * @return void
     */
    public function __construct($ip)
    {
        $this->remote_addr = $ip;
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = 'Distributed log analysis event';
        $msg .= parent::__toString();
        return $msg;
    }
}
