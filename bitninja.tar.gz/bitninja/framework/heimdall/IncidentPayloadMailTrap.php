<?php

/**
 * MailTrap Incident packaging class.
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Konnyu Jozsef <jozsi@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentPayloadMailTrap extends IncidentPayload
{
    protected $from;
    protected $delivery_date;
    protected $reason;
    protected $full_header;

    use TraitAccessors;

    public function __construct($data)
    {
        $this->from = $data['from'];
        $this->delivery_date = $data['delivery_date'];
        $this->reason = $data['reason'];
        $this->full_header = $data['full_header'];
    }
}
