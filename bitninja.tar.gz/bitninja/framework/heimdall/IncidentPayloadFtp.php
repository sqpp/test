<?php

/**
 * Smtp Incident packaging class.
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentPayloadFtp extends IncidentPayload
{
    /**
     * @var string
     */
    protected $protocol;
    /**
     * @var string
     */
    protected $fileName;
    /**
     * @var string
     */
    protected $fileSize;
    /**
     * @var string
     */
    protected $method;

    use TraitAccessors;

    /**
     * @param string $ip
     * @param string $fileName
     * @param string $fileSize
     * @param string $method
     * @return void
     */
    public function __construct($ip, $fileName, $fileSize, $method)
    {
        $this->protocol = 'ftp';
        $this->setModuleName('CaptchaFtp');
        $this->remote_addr = $ip;
        $this->fileName = $fileName;
        $this->fileSize = $fileSize;
        $this->method = $method;
    }

    /**
     * @return string
     */
    public function getFileName()
    {
        return $this->fileName;
    }

    /**
     * @return string
     */
    public function getMethod()
    {
        return $this->method;
    }

    /**
     * @return string
     */
    public function getFileSize()
    {
        return $this->fileSize;
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = parent::__toString();
        $msg .= 'File name: [' . $this->fileName . '] Size: [' . $this->fileSize . ']';
        return $msg;
    }
}
