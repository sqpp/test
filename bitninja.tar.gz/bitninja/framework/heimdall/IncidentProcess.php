<?php

/**
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Toma Zoltan <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */
class IncidentProcess  implements \JsonSerializable
{
    use TraitAccessors;

    /**
     * @var int
     */
    protected $pid;

    /**
     * @var string
     */
    protected $cwd;

    /**
     * @var string
     */
    protected $cmdline;

    /**
     * @var string
     */
    protected $environment;

    /**
     * @var string
     */
    protected $exe;

    /**
     * @var array
     */
    protected $filesInCwd;

    /**
     * @var int
     */
    protected $filesInCwdLimit = 10;

    /**
     * @var int
     */
    protected $parentPID;

    /**
     * @var string
     */
    protected $start_time;

    /**
     * @param int $pid
     * @return void
     */
    public function __construct($pid = null)
    {
        $this->setByPid($pid);
        $this->initFilesInCwd();
    }

    /**
     * @return array
     */
    protected function attributes()
    {
        return [
            'pid',
            'cwd',
            'cmdline',
            'environment',
            'exe',
            'filesInCwd',
            'parentPID',
            'start_time'
        ];
    }

    /**
     * @param int $pid
     * @return void
     */
    public function setByPid($pid = null)
    {
        $this->reset();
        if (! is_null($pid) && is_dir('/proc/' . $pid . '/task/' . $pid)) {
            $this->pid = $pid;
            $this->setCmdline(file_get_contents("/proc/$pid/task/$pid/cmdline"));
            $this->setEnvironment(file_get_contents("/proc/$pid/task/$pid/environ"));
            $this->setCwd(@readlink("/proc/$pid/task/$pid/cwd"));
            $this->setExe(@readlink("/proc/$pid/task/$pid/exe"));
            $this->start_time = filectime("/proc/$pid/task/$pid/");
            $this->setParentPID($this->getParentPidByStat($pid));
            $this->setFilesInCwd($this->getCwd());
        }
    }

    /**
     * @param int $pid
     * @return string
     */
    public function getParentPidByStat($pid)
    {
        $statFile=file_get_contents("/proc/$pid/task/$pid/stat");
        $statExploded=explode(" ", $statFile);
        return isset($statExploded[3])?$statExploded[3]:null;
    }

    /**
     * @return void
     */
    public function reset()
    {
        $this->pid = null;
        $this->cmdline = null;
        $this->environment = null;
        $this->cwd = null;
        $this->exe = null;
        $this->start_time = null;
        $this->parentPID = null;
        $this->initFilesInCwd();
        ;
    }

    /**
     * @return array
     */
    public function getFilesInCwd()
    {
        return $this->filesInCwd;
    }

    /**
     * @return void
     */
    public function initFilesInCwd()
    {
        for ($i=0; $i<$this->filesInCwdLimit; $i++) {
            if (!isset($this->filesInCwd[$i])) {
                $this->filesInCwd[] = new IncidentFile();
                continue;
            }
            if ($this->filesInCwd[$i] instanceof IncidentFile) {
                $this->filesInCwd[$i]->reset();
                continue;
            }
            if (is_array($this->filesInCwd[$i])) {
                $this->converFilesInCwdArrayToIncidentFileObjects();
            }
        }
    }

    /**
     * @return void
     */
    public function removeUnUsedFileObjects()
    {
        foreach ($this->filesInCwd as $key => $file) {
            if ($file->isNotSet()) {
                unset($this->filesInCwd[$key]);
            }
        }
    }

    /**
     * @return void
     */
    public function converFilesInCwdIncidentFileObjectsToArray()
    {
        $fileArray=[];
        foreach ($this->filesInCwd as $file) {
            $fileArray[]=$file->getAttributes();
        }
        $this->filesInCwd = $fileArray;
    }

    /**
     * @return void
     */
    public function converFilesInCwdArrayToIncidentFileObjects()
    {
        $fileArray=[];
        foreach ($this->filesInCwd as $file) {
            $fileObject= new IncidentFile();
            $fileObject->setAttributes($file);
            $fileArray[]=$fileObject;
        }
        $this->filesInCwd = $fileArray;
    }

    /**
     * @param string $cwdsPath
     * @return void
     */
    public function setFilesInCwd($cwdsPath)
    {
        if (is_dir($cwdsPath)) {
            $lastAccessedFiles = $this->getLastAccessedFilesInDir($cwdsPath, $this->filesInCwdLimit);
            $i=0;
            foreach ($lastAccessedFiles as $file) {
                $this->filesInCwd[$i]->setByDirAndFilename($cwdsPath, $file);
                $i++;
            }
        }
    }

    /**
     * @param string $dir
     * @param int $limit
     * @return array
     */
    public function getLastAccessedFilesInDir($dir, $limit)
    {
        $files = array();
        foreach (scandir($dir) as $file) {
            $path=$dir . DIRECTORY_SEPARATOR . $file;
            if (is_dir($path)) {
                continue;
            }
            if (is_link($path)) {
                $files[$file] = fileatime(readlink($path));
                continue;
            }
            $files[$file] = fileatime($path);
        }
        arsort($files);
        $files = array_slice(array_keys($files), 0, $limit);
        return ($files) ? $files : [];
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = '';
        return $msg;
    }

    /**
     * @return int
     */
    public function getPid()
    {
        return $this->pid;
    }

    /**
     * @return string
     */
    public function getCwd()
    {
        return $this->cwd;
    }

    /**
     * @return string
     */
    public function getCmdline()
    {
        return $this->cmdline;
    }

    /**
     * @return string
     */
    public function getEnvironment()
    {
        return $this->environment;
    }

    /**
     * @return string
     */
    public function getExe()
    {
        return $this->exe;
    }

    /**
     * @param int $pid
     * @return void
     */
    public function setPid($pid)
    {
        $this->pid = $pid;
    }

    /**
     * @param string $cwd
     * @return void
     */
    public function setCwd($cwd)
    {
        $this->cwd = $cwd;
    }

    /**
     * @param string $cmdline
     * @return void
     */
    public function setCmdline($cmdline)
    {
        $this->cmdline = str_replace("\x00", " ", $cmdline);
    }

    /**
     * @param string $environment
     * @return void
     */
    public function setEnvironment($environment)
    {
        $this->environment = str_replace("\x00", " ", $environment);
    }

    /**
     * @param string $exe
     * @return void
     */
    public function setExe($exe)
    {
        $this->exe = $exe;
    }

    /**
     * @return int
     */
    public function getFilesInCwdLimit()
    {
        return $this->filesInCwdLimit;
    }

    /**
     * @param int $filesInCwdLimit
     * @return IncidentProcess
     */
    public function setFilesInCwdLimit($filesInCwdLimit)
    {
        $this->filesInCwdLimit = $filesInCwdLimit;
        return $this;
    }

    /**
     * @return int
     */
    public function getParentPID()
    {
        return $this->parentPID;
    }

    /**
     * @param int $parentPID
     * @return IncidentProcess
     */
    public function setParentPID($parentPID)
    {
        $this->parentPID = $parentPID;
        return $this;
    }

    /**
     * @return string
     */
    public function getStartTime()
    {
        return $this->start_time;
    }

    /**
     * @param string $start_time
     * @return IncidentProcess
     */
    public function setStartTime($start_time)
    {
        $this->start_time = $start_time;
        return $this;
    }

    /**
     * @return array
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
