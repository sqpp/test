<?php

/**
 * Payload for DefenseRobot incident
 * 
 * @author      Joseph Easy <joseph.easy@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */

class IncidentPayloadDefenseRobot extends IncidentPayload
{
    use TraitAccessors;

    /**
     * Array of the correlated logs by log type
     * 
     * @var array
     */
    private $correlated_logs;

    /**
     * The path of the malware
     * 
     * @var string
     */
    private $malware_file_path;

    /**
     * Name of the malware
     * 
     * @var string
     */
    private $malware_name;

    /**
     * IncidentPayloadDefenseRobot constructor.
     * 
     * @param array $correlated_logs
     * @param string $malware_file_path
     * @param string $malware_name
     * @return void
     */
    public function __construct($correlated_logs, $malware_file_path, $malware_name)
    {
        $this->correlated_logs = $correlated_logs;
        $this->malware_file_path = $malware_file_path;
        $this->malware_name = $malware_name;
    }

    /**
     * @return array
     */
    public function getCorrelatedLogs()
    {
        return $this->correlated_logs;
    }

    /**
     * @param string $correlated_logs
     * @return void
     */
    public function setCorrelatedLogs($correlated_logs)
    {
        $this->correlated_logs = $correlated_logs;
    }

    /**
     * @return string
     */
    public function getMalwareFilePath()
    {
        return $this->malware_file_path;
    }

    /**
     * @param string $malware_file_path
     * @return void
     */
    public function setMalwareFilePath($malware_file_path)
    {
        $this->malware_file_path = $malware_file_path;
    }

    /**
     * @return string
     */
    public function getMalwareName()
    {
        return $this->malware_name;
    }

    /**
     * @param string $malware_name
     * @return void
     */
    public function setMalwareName($malware_name)
    {
        $this->malware_name = $malware_name;
    }
}
