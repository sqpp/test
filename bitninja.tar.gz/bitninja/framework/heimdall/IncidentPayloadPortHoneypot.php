<?php

/**
 * Smtp Incident packaging class.
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 */

class IncidentPayloadPortHoneypot extends IncidentPayload
{
    /**
     * @var array
     */
    protected $messages = array();
    /**
     * @var string
     */
    protected $server_addr;
    /**
     * @var string
     */
    protected $remote_addr;
    /**
     * @var string
     */
    protected $server_port = "";
    /**
     * @var string
     */
    protected $remote_port = "";

    use TraitAccessors;

    /**
     * @param object $request
     * @return void
     */
    public function populateFromRequest($request)
    {
        $this->messages = $request->messages;
        $this->server_port = $request->server_port;
        $this->remote_port = $request->remote_port;
        $this->remote_addr = $request->remote_addr;
        $this->server_addr = $request->server_addr;
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $msg = parent::__toString();
        $msg .= 'Connection from: [' . $this->remote_addr . $this->remote_port . ']';
        return $msg;
    }
}
