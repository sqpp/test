<?php

/**
 * Http Incident packaging class.
 * 
 * BitNinja Server Security
 * All rights reserved.
 * https://bitninja.io
 *
 * @author      Zsolt Egri <ezsolt@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     2.0
 *
 */
class IncidentPayloadWebHoneypot extends \IncidentPayload
{
    /**
     * @var string
     */
    protected $post;
    /**
     * @var string
     */
    protected $get;
    /**
     * @var string
     */
    protected $file;
    /**
     * @var int
     */
    protected $pid;
    /**
     * @var int
     */
    protected $uid;
    /**
     * @var string
     */
    protected $server;

    use TraitAccessors;

    /**
     * @param \BitNinja\SenseWebHoneypot\HoneyRequest $request
     * @return void
     */
    public function __construct(\BitNinja\SenseWebHoneypot\HoneyRequest $request)
    {
        $this->remote_addr = $request->getIp();
        $this->post = $request->getPost();
        $this->get = $request->getGet();
        $this->file = $request->getFile();
        $this->pid = $request->getPid();
        $this->uid = $request->getUid();
        $this->server = $request->getServer();
        if (isset($this->server['HTTP_HOST'])) {
            $this->associated_domain_name = $this->server['HTTP_HOST'];
        }
    }

    /**
     * Returns with the string representation of this incident.
     *
     * @return string
     */
    public function __toString()
    {
        $post_size = strlen(serialize($this->post));
        $p_append = 'Post size [' . $post_size . ']';

        $get_size = strlen(serialize($this->get));
        $g_append = 'Get size [' . $get_size . ']';

        $msg = 'WebHoney [' . $this->remote_addr . '] ' . $p_append . $g_append;
        $msg .= parent::__toString();
        return $msg;
    }
}
