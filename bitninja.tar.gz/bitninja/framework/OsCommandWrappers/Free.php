<?php
namespace BitNinja\Framework;
/**
 * Wrapper class for free Linux command.
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  FrameWork
 * @version     1.29.2
 */
class Free
{
    use TraitCommandBuilder;

    /**
     * Returns the available free memory in Mega bytes on the system
     *
     * @return integer
     */
    public function getFreeMemoryInMegaBytes()
    {
        $res = $this->runCommand('free', ['-m',
            new \BlueCmdBuilder('awk',[
                'NR==2 {print $4}'
            ])
        ]);
        return !$res->getReturnVar()? (int)trim($res->getLine(0)) : 0;
    }
}