<?php

/**
 * Base Class how a bitninja needed package should be handled.
 * Installning, starting, configuring should be moved to this class.
 * We started with stoping duplicated processses.
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     1.24.3
 */
class AbstractPackageManager
{
    use \TraitOsHelper;
    use \TraitCommandHelper;


    /** @var BlueLog */
    protected $log;

    /**
     * Name of the package which need to be managed
     * Like: bitninja-waf
     *
     * @var string
     */
    protected $package;

    /**
     * Name of the process which is shown in ps output
     *
     * @var string
     */
    protected $processName;

    /**
     * Where is the pid file of the running process.
     *
     * @var string
     */
    protected $pidFileLocation;
    /**
     * Content of the pid file. It holds the pid number of the running process
     *
     * @var string
     */
    protected $pidFileContent;
    /**
     * Version number of the latest released package, which should be installed on the system.
     *
     * @var string
     */
    protected $latestPackeageVersion;

    /**
     * Path where the executable located after the package installed
     *
     * @var string
     */
    protected $binaryLocation;

    /**
     * Check if is there an executable int he given path.
     * (path should be like: /opt/bitninja-waf/sbin/nginx)
     *
     * @return boolean
     */
    public function isPackageInstalled()
    {
        return $this->isExecutableFileAtPath($this->binaryLocation) && $this->checkIfVerisonMatch($this->package, $this->latestPackeageVersion);
    }

    /**
     * Install package on the system.
     *
     * @return boolean true on success
     */
    public function installPackage()
    {
        if ($this->isDeb()) {
            return $this->installDeb();
        }
        if ($this->isZypper()) {
            $this->log->warn('Zypper package manager not supported yet.');
            return false;
        }
        if ($this->isRpm()) {
            return $this->installRpm();
        }
        $this->log->warn("Could determinate Os. {$this->package} package not installed.");
        return false;
    }

    /**
     * If Debian based OS found it will install with apt-get
     *
     * @return boolean true if package installation successful
     */
    public function installDeb()
    {
        $this->log->info("Deb type OS found. Installing {$this->package} package.");
        $this->runCommand('apt-get', [
            'update'
        ]);
        return $this->install('apt-get', $this->package);
    }



    /**
     * If Rpm based OS found it will install with yum
     *
     * @return boolean true if packeg installation success
     */
    public function installRpm()
    {
        $this->log->info("Rpm type OS found. Installing {$this->package} package.");
        return $this->install('yum', $this->package);
    }

    /**
     * Real package installer. Almost every pakage manager works the same when installing a package.
     * yum install <package> -y
     * apt install <package> -y
     * apt-get install <package> -y
     * zypper install <package> -y
     *
     * @param string $packageManager which package manager to use.
     * @param string $package name of the package which need to be installed.
     * @return boolean
     */
    protected function install($packageManager, $package)
    {
        $res = $this->runCommand($packageManager, [
            'install',
            $package,
            '-y'
        ]);
        if ($res->getReturnVar() !== 0) {
            $this->log->warn("Error while install $package package.");
            $res->logEveryLine('warn', $this);
            $this->log->info("$package package maybe not available yet for you architecture.");
            return false;
        }
        return true;
    }
    /**
     * Check if the installed package version is match for what we need.
     *
     * @return boolean True if the package is at the requested version number
     */
    public function checkIfVerisonMatch($package, $version)
    {
        $res = null;
        if ($this->isDeb()) {
            $res = $this->runCommand('dpkg-query', [
                '--showformat=\'${Version}\' ',
                '--show',
                $package
            ]);
        }
        if ($this->isRpm()) {
            $res = $this->runCommand('rpm', [
                '--query',
                '--qf',
                '%{VERSION}',
                $package
            ]);
        }
        if (!is_null($res) && $res->contains($version) || is_null($version)) {
            return true;
        }

        return false;
    }
    /**
     * Count running  $processName processes
     *
     * @param mixed $runner
     *             $processName runner; 'bitninja', null: all
     *
     * @return int
     */
    public function countProcesses($runner = null)
    {
        $cmd_pipe = [
            '-C',
            $this->processName,
            '-o',
            'cmd='
        ];
        if (!is_null($runner)) {
            $cmd_pipe[] = new \BlueCmdBuilder("grep", [
                $runner
            ]);
        }
        $check_bitninja_cmd_result = $this->runCommand("ps", $cmd_pipe);
        return $check_bitninja_cmd_result->getReturnVar() !== 0 ? 0 : count($check_bitninja_cmd_result->getResult());
    }

    /**
     * Returns ids of running  $processName processes
     *
     * @param mixed $runner
     *             $processName runner; 'bitninja', null: all
     *
     * @return array
     */
    public function getProcessPids($runner = null): array
    {
        $pids = [];
        $cmd_pipe = [
            "-C",
            $this->processName,
            '-o',
            'pid=,cmd='
        ];
        if (!is_null($runner)) {
            $cmd_pipe[] = new \BlueCmdBuilder("grep", [
                $runner
            ]);
        }
        $check_bitninja_cmd_res = $this->runCommand("ps", $cmd_pipe);
        foreach ($check_bitninja_cmd_res->getResult() as $line) {
            $pids[] = intval(explode(" ", trim($line), 2)[0]);
        }
        return $pids;
    }

    /**
     * Stops every procces given in the params
     *
     * @param array $processes
     */
    public function stopProcesses($processes)
    {
        foreach ($processes as $pid) {
            if ($pid == posix_getpid()) {
                continue;
            }

            $this->log->info('Killing ' . $this->processName . ' process: [' . $pid . ']');
            posix_kill($pid, SIGTERM);
            sleep(1);
            if (posix_getpgid($pid)) {
                posix_kill($pid, SIGKILL);
            }
        }
    }

    /**
     * Loads content of the pid file.
     * Pid file stores the currently active process pids.
     *
     * @return string
     */
    public function loadPidFileContent()
    {
        $this->pidFileContent = @file_get_contents($this->pidFileLocation);
        return $this->pidFileContent;
    }
}
