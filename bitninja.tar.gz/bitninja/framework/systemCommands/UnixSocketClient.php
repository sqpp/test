<?php

/**
 * Class for handling local Unix sockets as a client
 *
 * @author      Zoltan Toma <toma.zoltan@bitninja.io>
 * @copyright   © 2021 BitNinja Inc.
 * @package     BitNinja
 * @subpackage  Framework
 * @version     1.20.2
 */
class UnixSocketClient
{

    /**
     * Path where the unix socket located
     *
     * @var string
     */
    protected $socket_path = '';

    /**
     * Resource created by stream_socket_client which we use to send and read from the stream
     *
     * @var resource
     */
    protected $handle = null;

    /**
     * Logger
     *
     * @var BlueLog
     */
    protected $log;

    public function __construct($socket_path = '')
    {
        $this->socket_path = $socket_path;
        $this->log = BlueLog::instance($this);
    }

    /**
     * Connect to a unix socket
     *
     * @return boolean true if success
     */
    public function connect()
    {
        if (!is_readable($this->socket_path)) {
            $this->log->warning("Unix socket not found at path [{$this->socket_path}]");
            return false;
        }
        $this->handle = @stream_socket_client('unix://' . $this->socket_path, $errno, $errstr);
        if (!$this->handle) {
            $this->log->warning("Unable to connect to the socket [{$this->socket_path}]");
            $this->log->warning("Error message: $errno ($errstr)");
            @\unlink($this->socket_path);
            return false;
        }
        return true;
    }

    /**
     *
     * @return boolean
     */
    public function connectLogless()
    {
        if (!is_readable($this->socket_path)) {
            return false;
        }
        $this->handle = @stream_socket_client('unix://' . $this->socket_path, $errno, $errstr);
        if (!$this->handle) {
            return [
                'errno' => $errno,
                'errstr' => $errstr
            ];
        }
        return true;
    }

    public function closeLogless()
    {
        return @fclose($this->handle);
    }
    /**
     * Write a message to a unix socket.
     * Remember to appent the massage wiht \r\n if needed.
     *
     * @param string $message
     * @return boolean|number Number of writen bytes to the stream or false on failure.
     */
    public function sendMessage($message)
    {
        if (!$this->handle && !$this->connect()) {
            $this->log->warn('Need to setup a valid socket handle before sending');
            return false;
        }
        return @fwrite($this->handle, $message);
    }

    /**
     * Reads from the stream.
     *
     * @return boolean|string
     */
    public function readRespones()
    {
        if (!$this->handle && !$this->connect()) {
            $this->log->warn('Need to setup a valid socket handle before read');
            return false;
        }
        $contents = '';
        while (!feof($this->handle)) {
            $contents .= @fread($this->handle, 8192);
        }
        return $contents;
    }

    /**
     * Close the connection
     * @return boolean
     */
    public function close()
    {
        return fclose($this->handle);
    }
}
