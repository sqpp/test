<?php
class InotifyHelper
{
    use \TraitCommandHelper;

    /**
     *
     * @var string log path
     */
    protected $inotify_log;

    /**
     *
     * @var CPU nice value
     */
    protected $scan_cpunice;

    /**
     *
     * @var IO nice value
     */
    protected $scan_ionice;

    /**
     *
     * @var string where inotify works
     */
    protected $paths_file;

    /**
     *
     * @var array list for inotify
     */
    protected $excludes;

    /**
     *
     * @var string regex used to inotify exclude
     */
    protected $excludes_file;

    protected $monitor_log_md5;
    /**
     * @return Inotify
     */
    public function getInotify_log()
    {
        return $this->inotify_log;
    }

    /**
     * @return CPU
     */
    public function getScan_cpunice()
    {
        return $this->scan_cpunice;
    }

    /**
     * @return IO
     */
    public function getScan_ionice()
    {
        return $this->scan_ionice;
    }

    /**
     * @return string
     */
    public function getPaths_file()
    {
        return $this->paths_file;
    }

    /**
     * @return array
     */
    public function getExcludes()
    {
        return $this->excludes;
    }

    /**
     * @param Inotify $inotify_log
     */
    public function setInotify_log($inotify_log)
    {
        $this->inotify_log = $inotify_log;
        return $this;
    }

    /**
     * @param CPU $scan_cpunice
     */
    public function setScan_cpunice($scan_cpunice)
    {
        $this->scan_cpunice = $scan_cpunice;
        return $this;
    }

    /**
     * @param IO $scan_ionice
     */
    public function setScan_ionice($scan_ionice)
    {
        $this->scan_ionice = $scan_ionice;
        return $this;
    }

    /**
     * @param string $paths_file
     */
    public function setPaths_file($paths_file)
    {
        $this->paths_file = $paths_file;
        return $this;
    }

    /**
     * @param array $excludes
     */
    public function setExcludes($excludes)
    {
        $this->excludes = $excludes;
        return $this;
    }

    /**
     * @return boolean
     */
    public function isMonitorLogChanged()
    {
        if (is_null($this->monitor_log_md5)) {
            $this->monitor_log_md5 = md5_file($this->inotify_log);
            return false;
        }
        return $this->monitor_log_md5 !== md5_file($this->inotify_log);
    }

    public function compareContent($file, $content)
    {
        return is_file($file) && $content == file_get_contents($file);
    }
    /**
     * Creates the content of monitor.txt. It checks if the given paths exists.
     *
     * @param array $paths
     * @return string
     */
    public function createMonitorFileContentFromFilePaths($paths)
    {
        $content = "";
        foreach ($paths as $path) {
            $directories = glob($path, GLOB_ONLYDIR);
            if (empty($directories)) {
                $this->log->info("Monitor path [$path] does not exist. Inotify-wait will not set up a watch for it.");
            }
            foreach ($directories as $directory) {
                if (!is_dir($directory) && !is_file($directory)) {
                    continue;
                }
                $content .= "$directory\n";
            }
        }
        return $content;
    }

    /**
     * @return boolean
     */
    public function install()
    {
        $sdp = \ServerDataProvider::getInstance();

        if ($sdp->isDeb()) {
            $cmd = new \BlueCmdBuilder('dpkg', [
                '--list',
                'inotify-tools',
                new \BlueCmdBuilder('grep', [
                    '^ii'
                ])
            ]);
            $res = $cmd->execute();
            if ($res->getReturnVar() != 0) {
                $cmd = new \BlueCmdBuilder('apt-get', [
                    '--assume-yes',
                    'install',
                    'inotify-tools'
                ]);
                $res = $cmd->execute();
                return ($res->getReturnVar() == 0 ? true : false);
            }
        }

        if ($sdp->isZypper()) {
            $cmd = new \BlueCmdBuilder('zypper', [
                'install',
                '-y',
                'inotify-tools'
            ]);
            $res = $cmd->execute();
            return ($res->getReturnVar() == 0 ? true : false);
        }

        if ($sdp->isRpm()) {
            $cmd = new \BlueCmdBuilder('rpm', [
                '--query',
                'inotify-tools'
            ]);
            $res = $cmd->execute();
            if ($res->getReturnVar() != 0) {
                $cmd = new \BlueCmdBuilder('yum', [
                    '-y',
                    'install',
                    'inotify-tools'
                ]);
                $res = $cmd->execute();
                return ($res->getReturnVar() == 0 ? true : false);
            }
        }

        return false;
    }

    /**
     * Count running inotify processes
     *
     * @param mixed $runner
     *            Inotify runner; 'bitninja', null: all
     *
     * @return int
     */
    public function countInotifys($runner = null)
    {
        $cmd_pipe = [
            '-C',
            'inotifywait',
            '-o',
            'cmd='
        ];
        if (!is_null($runner)) {
            $cmd_pipe[] = new \BlueCmdBuilder("grep", [
                $runner
            ]);
        }
        $check_bitninja_inotify_cmd_result = $this->runCommand("ps", $cmd_pipe);
        return $check_bitninja_inotify_cmd_result->getReturnVar() !== 0 ? 0 : count($check_bitninja_inotify_cmd_result->getResult());
    }

    /**
     * Returns ids of running inotify processes
     *
     * @param mixed $runner
     *            Inotify runner; 'bitninja', null: all
     *
     * @return array
     */
    public function getInotifys($runner = null)
    {
        $pids = [];
        $cmd_pipe = [
            "-C",
            'inotifywait',
            '-o',
            'pid=,cmd='
        ];
        if (!is_null($runner)) {
            $cmd_pipe[] = new \BlueCmdBuilder("grep", [
                $runner
            ]);
        }
        $check_bitninja_inotify_cmd_res = $this->runCommand("ps", $cmd_pipe);
        foreach ($check_bitninja_inotify_cmd_res->getResult() as $line) {
            $pids[] = intval(explode(" ", trim($line), 2)[0]);;
        }
        return $pids;
    }

    public function stopProcesses($processes)
    {
        foreach ($processes as $pid) {
            if ($pid == posix_getpid()) {
                continue;
            }

            $this->log->info('Killing inotifywait process: [' . $pid . ']');
            posix_kill($pid, SIGTERM);
            sleep(1);
            if (posix_getpgid($pid)) {
                posix_kill($pid, SIGKILL);
            }
        }
    }

    /**
     * Check if the installed Inotify-tools version is 3.14.
     * Only supported version is tha latest 3.14
     *
     * @return boolean True if Inotify version is supported
     */
    public function checkInotifyVerisonIsSupported()
    {
        $sdp = \ServerDataProvider::getInstance();
        $res = null;
        if ($sdp->isDeb()) {
            $cmd = new \BlueCmdBuilder('dpkg-query', [
                '--showformat=\'${Version}\' ',
                '--show',
                'inotify-tools'
            ]);
            $res = $cmd->execute();
        }
        if ($sdp->isRpm()) {
            $cmd = new \BlueCmdBuilder('rpm', [
                '--query',
                '--qf',
                '"%{VERSION}"',
                'inotify-tools'
            ]);
            $res = $cmd->execute();
        }
        if (!is_null($res) && $res->equalOrGreater('3.14')) {
            return true;
        }

        return false;
    }

    /**
     * Starts inotifywait
     *
     * @return void
     */
    public function run()
    {
        $cmd = new \BlueCmdBuilder("true");
        $inotifywait_cmd = $cmd->locateCommand("inotifywait");
        if (!$inotifywait_cmd) {
            $this->log->warn("Inotify-tools package is not available. Trying to install it..");
            if (!file_exists($this->inotify_log)) {
                file_put_contents($this->inotify_log, '');
            }
            if ($this->install() != true) {
                $this->log->warn("Couldn't install Inotify-tools");
                return false;
            }
            $inotifywait_cmd = $cmd->locateCommand("inotifywait");
        }
        if (!$this->checkInotifyVerisonIsSupported()) {
            $this->log->warn('inotify-tools have been already installed. Supported version is greater than 3.14. Please check the installed version.');
            return false;
        }
        $start_inotify_cmd = new \BlueCmdBuilder($cmd->locateCommand("nice"), [
            "-n",
            $this->scan_cpunice,
            $cmd->locateCommand("ionice"),
            "-c",
            "2",
            "-n",
            $this->scan_ionice,
            $inotifywait_cmd,
            "--daemon",
            "--recursive",
            "--outfile",
            $this->inotify_log,
            "--fromfile",
            $this->paths_file,
            "--exclude",
            "(" . implode("|", $this->excludes) . ")",
            "--timefmt",
            "%F %T",
            "--format",
            "%w%f %e %T",
            "--monitor",
            "--event",
            "create,move,modify"
        ]);
        $start_inotify_cmd_result = $start_inotify_cmd->execute();

        if ($start_inotify_cmd_result->getReturnVar() == 0) {
            $this->log->info('Inotifywait process has been started: ' . $start_inotify_cmd->getCommandStr());
            return true;
        }

        $this->log->error("Error while starting inotifywait");
        foreach ($start_inotify_cmd_result->getResult() as $log_row) {
            $this->log->error($log_row);
        }

        return false;
    }

    /**
     * Increase max_user_watches value if it is necessary
     *
     * @return void
     */
    public function setMaxUserWatches()
    {
        $max_user_watches_file = "/proc/sys/fs/inotify/max_user_watches";
        if (file_exists($max_user_watches_file)) {
            $max_user_watches_num = trim(file_get_contents($max_user_watches_file));

            if ($max_user_watches_num < 30000000) {
                file_put_contents($max_user_watches_file, 30000000);
                $this->log->info("max_user_watches value increased from {$max_user_watches_num} to 30 000 000");
            }
        }
    }
}
